# 📋 Hotel 2 — เอกสารข้อกำหนดและสถาปัตยกรรมระบบ (Specifications & Blueprints)

> รวบรวมเอกสารการวิเคราะห์และข้อกำหนดทางเทคนิค (System Specifications) สำหรับระบบบริหารจัดการเคสโรงแรม

---

### 📂 รายการเอกสารในโฟลเดอร์นี้

1. **[`FinalC.md`](./FinalC.md):** เอกสารสรุปฉบับสมบูรณ์ (Final Spec) ของระบบแจ้งเคสข้ามแผนก โครงสร้างสิทธิ์พนักงาน (Staff, Head, Admin, Owner)
2. **[`FinalG.md`](./FinalG.md):** แนวทางการเชื่อมต่อฐานข้อมูลและการประเมินความเป็นไปได้ทางเทคนิค (GAS / MySQL Feasibility Review)
3. **[`FinalP.md`](./FinalP.md):** แผนแม่บทการพัฒนา (Project Master Plan), ลำดับขั้นตอนการพัฒนา (Milestones), และสถาปัตยกรรมข้อมูล
