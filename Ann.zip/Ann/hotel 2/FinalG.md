# สรุปพิมพ์เขียวระบบแจ้งเคส (Case Reporting System) — Production-Ready Standard

---

## 1. การสถาปัตยกรรมและเทคโนโลยีหลัก (System Architecture)

```
[ Frontend: Single Page Application (HTML5 / Tailwind CSS / Vanilla JS) ]
                                 │
                    Short Polling (15-30 Secs) & Fetch API
                                 ▼
[ Backend Web App: Google Apps Script (GAS) ] ── (LockService Enabled)
        │                        │                        │
        ▼                        ▼                        ▼
[ Google Sheets ]        [ Google Drive ]         [ Email Notification ]
(Database System)        (Image & File Storage)   (GAS MailApp / GmailApp)
```

* **Frontend:** HTML5, JS (ES6+), Tailwind CSS (สำหรับ Responsive UI บน Mobile/Desktop), Chart.js (สำหรับ Render Dashboard)
* **Backend:** Google Apps Script (GAS) รับ-ส่งข้อมูลผ่าน `doGet` และ `doPost` 
* **Database:** Google Sheet (6 แท็บหลัก ออกแบบโครงสร้างแบบ Relational Database)
* **Storage:** Google Drive Folder สำหรับเก็บรูปแนบ/ไฟล์เอกสาร
* **Authentication:** Google Workspace / Google Account OAuth2 Pass-through (อ้างอิง User Email จากระบบ)

---

## 2. โครงสร้างตารางฐานข้อมูลสมบูรณ์ (Google Sheets Schema)

### 2.1 แท็บ `Cases` (ข้อมูลเคสหลัก)
| Column Name | Data Type | Description |
|---|---|---|
| `CaseID` | String | PK: รูปแบบ `CASE-YYYYMMDD-XXXX` (ใช้วิธี LockService + Counter กันซ้ำ) |
| `CreatedAt` | DateTime | วันเวลาที่สร้างเคส (ISO String / standard format) |
| `CreatedBy` | String | Email ของผู้แจ้งเคส |
| `DepartmentFrom` | String | แผนกต้นทางที่แจ้ง |
| `DepartmentCurrent` | String | แผนกปลายทางที่รับผิดชอบ ณ ปัจจุบัน |
| `AssignedTo` | String | Email พนักงานผู้รับผิดชอบ |
| `Location` | String | สถานที่เกิดเหตุ / อาคาร / โซน |
| `RoomNo` | String | เลขห้องพัก (ถ้ามี) |
| `Category` | String | หมวดหมู่งานซ่อม/เคส |
| `Subject` | String | หัวข้อเคส |
| `Description` | Text | รายละเอียดปัญหา |
| `Priority` | Enum | `NORMAL` (60 นาที), `URGENT` (40 นาที), `EMERGENCY` (20 นาที) |
| `DueAt` | DateTime | วันเวลา Due Date (คำนวณจาก `CreatedAt` + SLA) |
| `Status` | Enum | `NEW` ➔ `ACKNOWLEDGED` ➔ `IN_PROGRESS` ➔ `TRANSFERRED` ➔ `RESOLVED` ➔ `CLOSED` |
| `ResolvedAt` | DateTime | วันเวลาที่ซ่อม/แก้ไขเสร็จ |
| `ClosedAt` | DateTime | วันเวลาที่ปิดเคสสมบูรณ์ |
| `LastUpdated` | DateTime | วันเวลาที่มีการอัปเดตล่าสุด |
| `UpdatedBy` | String | Email ผู้แก้ไขล่าสุด |
| `UnreadFlag` | Boolean | Flag แสดงสถานะมีข้อความใหม่ยังไม่ได้อ่าน |
| `ReminderCount` | Integer | จำนวนครั้งที่แจ้งเตือนซ้ำ (0, 1, 2) |
| `AttachmentURL` | String | Direct URL รูปภาพหลักแนบเคส |
| `IsDeleted` | Boolean | Soft Delete Flag (`FALSE` = ปกติ, `TRUE` = ถูกลบ) |

### 2.2 แท็บ `CaseLog` (ประวัติการดำเนินงาน / Audit Trail)
| Column Name | Data Type | Description |
|---|---|---|
| `LogID` | String | PK: `LOG-YYYYMMDD-XXXX` |
| `CaseID` | String | FK ➔ `Cases.CaseID` |
| `EventType` | String | เช่น `CREATE`, `ASSIGN`, `TRANSFER`, `STATUS_CHANGE`, `ESCALATION` |
| `OldValue` | String | ค่าเดิมก่อนแก้ไข |
| `NewValue` | String | ค่าใหม่หลังแก้ไข |
| `Actor` | String | Email ผู้กระทำรายการ |
| `CreatedAt` | DateTime | วันเวลาที่บันทึก Log |

### 2.3 แท็บ `CaseComments` (บทสนทนาในเคส)
| Column Name | Data Type | Description |
|---|---|---|
| `CommentID` | String | PK: `CMT-YYYYMMDD-XXXX` |
| `CaseID` | String | FK ➔ `Cases.CaseID` |
| `Sender` | String | Email ผู้ส่งข้อความ |
| `Department` | String | แผนกของผู้ส่ง |
| `Message` | Text | ข้อความ |
| `AttachmentURL` | String | Direct URL รูปภาพ/ไฟล์แนบในแชท |
| `Type` | Enum | `USER` (ข้อความจากคน) / `SYSTEM` (ข้อความระบบ) |
| `CreatedAt` | DateTime | วันเวลาที่ส่งข้อความ |

### 2.4 แท็บ `Users` (รายชื่อและสิทธิ์ผู้ใช้งาน)
| Column Name | Data Type | Description |
|---|---|---|
| `UserID` | String | PK: `USR-XXXX` |
| `Email` | String | Email บัญชี Google Workspace (ใช้ยืนยันตัวตน) |
| `Name` | String | ชื่อ-นามสกุล ผู้ใช้งาน |
| `Department` | Enum | `IT`, `HK`, `ENG`, `FRONT`, `SECURITY` |
| `Role` | Enum | `STAFF`, `DEPT_HEAD`, `ADMIN`, `OWNER` |
| `Active` | Boolean | สถานะการใช้งาน (`TRUE` = Active, `FALSE` = Inactive) |

### 2.5 แท็บ `Rooms` (ข้อมูลสถานะห้องพัก)
| Column Name | Data Type | Description |
|---|---|---|
| `RoomNo` | String | PK: เลขห้องพัก (เช่น `101`, `102`) |
| `Status` | Enum | `AVAILABLE` (พร้อมใช้งาน), `CLOSED` (ปิดใช้งาน / ปิดซ่อม) |
| `Reason` | String | เหตุผลที่ปิดใช้งานห้องพัก |
| `CurrentCaseID` | String | FK ➔ `Cases.CaseID` (เคสที่สั่งปิดห้อง อัปเดตอัตโนมัติ) |
| `UpdatedAt` | DateTime | วันเวลาอัปเดตล่าสุด |
| `UpdatedBy` | String | Email ผู้จัดการสถานะ |

### 2.6 แท็บ `RoomLog` (ประวัติการเปิด-ปิดห้องพัก)
| Column Name | Data Type | Description |
|---|---|---|
| `LogID` | String | PK: `RML-YYYYMMDD-XXXX` |
| `RoomNo` | String | FK ➔ `Rooms.RoomNo` |
| `Action` | Enum | `INITIAL_SET`, `CLOSE_ROOM`, `OPEN_ROOM` |
| `Reason` | String | เหตุผลการเปลี่ยนสถานะ |
| `CaseID` | String | FK ➔ `Cases.CaseID` (ถ้ามี) |
| `Actor` | String | Email ผู้ทำรายการ |
| `CreatedAt` | DateTime | วันเวลาบันทึก |

---

## 3. SLA, Escalation Rule & Auto-Link Flow

```
[แจ้งเคสหมวดซ่อมหนัก (Out of Order)]
       │
       ├─► บันทึกข้อมูลลงแท็บ Cases (ตั้ง Priority & SLA)
       └─► Auto-Link Status ──► ปรับสถานะในแท็บ Rooms เป็น "CLOSED" 
                                บันทึก CaseID ลงใน RoomLog อัตโนมัติ

[ติดตาม SLA & Escalation Flow]
       │
       ▼ (Time-driven Trigger รันทุก 1 นาที)
 เปรียบเทียบ Current Time กับ DueAt
       │
       ├─► เลย DueAt ครั้งที่ 1 ──► แจ้งเตือน ผู้รับผิดชอบ (ReminderCount = 1)
       ├─► เลย DueAt ครั้งที่ 2 ──► แจ้งเตือน ผู้รับผิดชอบ (ReminderCount = 2)
       └─► เลย DueAt ครั้งที่ 3 ──► ส่ง Email Escalation หา Admin ของแผนกนั้นๆ
```

### 3.1 การคำนวณ SLA (Service Level Agreement)
* **ฉุกเฉิน (EMERGENCY):** Due Time = `CreatedAt` + 20 นาที
* **ด่วน (URGENT):** Due Time = `CreatedAt` + 40 นาที
* **ปกติ (NORMAL):** Due Time = `CreatedAt` + 60 นาที

### 3.2 กฎการ Escalation
1. **Trigger:** ตั้งค่า Time-Driven Trigger ใน Apps Script ทำงานทุก **1 นาที** เพื่อค้นหาเคสที่ `Status` ไม่ใช่ `RESOLVED` หรือ `CLOSED` และ `Current Time > DueAt`
2. **การเตือนครั้งที่ 1 & 2:** ส่ง Web Notification / Email หาผู้รับผิดชอบ และอัปเดต `ReminderCount`
3. **Escalation ขั้นสูงสุด:** หากเตือนซ้ำครบ 2 ครั้งแล้วยังไม่มีการแก้ไข ระบบจะส่งอีเมลหา **Department Admin** ของแผนกที่รับผิดชอบ พร้อมลงบันทึก Event ใน `CaseLog`

### 3.3 การเชื่อมโยงสถานะห้องอัตโนมัติ (Auto-Link Room Status)
เมื่อมีการแจ้งเคสหมวดงานซ่อมหนักที่ส่งผลให้ห้องพักไม่สามารถขายได้ (Out of Order):
* ระบบ Backend จะอัปเดตแท็บ `Rooms` ของห้องนั้นเป็น `CLOSED` อัตโนมัติ
* ผูก `CaseID` ลงใน `Rooms.CurrentCaseID` และสร้าง Record ใหม่ใน `RoomLog` โดยผู้ใช้ไม่ต้องเสียเวลาคีย์ข้อมูลซ้ำ

---

## 4. แนวทางการจัดการเทคนิคประสิทธิภาพสูง (Technical Solutions)

### 4.1 การป้องกันข้อมูลชนกัน (Data Collision Prevention)
ใช้ `LockService` ของ Apps Script ครอบจุดเขียนข้อมูลทุกจุดเพื่อป้องกัน Race Conditions:

```javascript
function createCase(formData) {
  const lock = LockService.getScriptLock();
  if (lock.tryLock(10000)) {
    try {
      // 1. อ่านคอลัมน์เพื่อสร้าง Auto ID ถัดไป
      // 2. บบันทึกข้อมูลลงใน Sheet Cases
      // 3. บันทึก Log ลงใน CaseLog
      // 4. คืนค่าผลลัพธ์กลับ Frontend
    } finally {
      lock.releaseLock();
    }
  } else {
    throw new Error("ระบบกำลังมีการบันทึกข้อมูลพร้อมกัน กรุณาลองใหม่อีกครั้ง");
  }
}
```

### 4.2 ระบบอัปโหลดรูปภาพ (Image Optimization Architecture)
1. **Frontend:** ทำ Image Compression ย่อขนาดไฟล์ภาพ และแปลงเป็น Base64
2. **Backend:** Apps Script รับ Base64 สร้างเป็นไฟล์ภาพลงโฟลเดอร์ใน Google Drive
3. **Permission:** ตั้งโฟลเดอร์ Google Drive เป็น *"Anyone with the link can view"*
4. **Data Entry:** นำ Direct URL มาบันทึกลงในคอลัมน์ `AttachmentURL` ของ Sheet

### 4.3 Real-time & Web Notification
* **Short Polling:** Frontend ใช้ `setInterval` ดึง API ทุก 15-30 วินาที เพื่อเช็คค่า `LastUpdated` หรือ `UnreadFlag`
* **Performance:** ดึงเฉพาะ Delta (เคสที่มีการเคลื่อนไหว) ไม่ดึงแชททั้งหมดใน `CaseComments` ทุกรอบ

---

## 5. Dashboard และการรองรับภาษา (Dashboard & i18n)

### 5.1 Dashboard UI
* **Case Dashboard (สำหรับ Staff / Dept Head / Admin):** แสดงกราฟจำนวนเคสแยกตามแผนก, สถานะ (`NEW`, `IN_PROGRESS`, `RESOLVED`, `CLOSED`), SLA Violations, และเวลารวมเฉลี่ยในการปิดเคส
* **Room Status Dashboard (สำหรับ Owner):**
    * ตัวเลขสรุป: ห้องทั้งหมด / พร้อมใช้งาน (`AVAILABLE`) / ปิดใช้งาน (`CLOSED`) และ % ความพร้อมขาย
    * ตารางรายการห้องพักพร้อม Status Tag และกดดูประวัติย้อนหลัง (`RoomLog`) รายห้องได้

### 5.2 ระบบ 2 ภาษา (TH / EN)
* **UI Labels:** เก็บข้อความสลับภาษาไว้ในไฟล์ `dictionary.js` บน Frontend
* **Dynamic Data:** ข้อมูลที่พนักงานคีย์จะถูกบันทึกตามภาษาจริงที่พิมพ์
* **Reports / Emails:** เลือกภาษาที่จะส่งออกได้จากหน้าสร้างรายงาน

---

## 6. แผนการดำเนินงานพัฒนา (Implementation Roadmap)

| ระยะเวลา (Phase) | รายละเอียดงาน | ผลลัพธ์ (Deliverables) |
|---|---|---|
| **Phase 1: Setup & Data Schema** | • สร้าง Google Sheet ตาม 6 แท็บ Schema<br>• จัดเตรียมโฟลเดอร์ Google Drive สำหรับเก็บไฟล์แนบ<br>• ออกแบบ Wireframe / UI Draft | โครงสร้าง Database และ UI Prototype |
| **Phase 2: Core Development** | • เขียน Apps Script CRUD Functions ร่วมกับ `LockService`<br>• พัฒนา Form แจ้งเคส + แนบรูปบีบอัดฝั่ง Client<br>• พัฒนาระบบแชท `CaseComments` และระบบส่งต่อเคส | Web App สามารถเปิดเคส ตอบแชท และส่งต่อได้ |
| **Phase 3: Automation & SLA** | • ตั้ง Time-driven Trigger เช็ค SLA และ Escalation Rules<br>• พัฒนา Auto-Link Status ระหว่างเคสซ่อมหนักกับสถานะห้องพัก<br>• พัฒนาระบบแจ้งเตือนทาง Email และ Web Short Polling | ระบบแจ้งเตือนและระบบอัตโนมัติทำงานสมบูรณ์ |
| **Phase 4: Dashboards & Reports** | • พัฒนา Case Dashboard และ Owner Room Dashboard (Chart.js)<br>• พัฒนาระบบ Filter และ Export Report (PDF/Excel) | Dashboard และรายงานพร้อมใช้งาน |
| **Phase 5: Security & Testing** | • ทดสอบการชนกันของข้อมูล (Concurrency Testing)<br>• ตั้งค่า Google Account Authentication & Permission<br>• ทดสอบระบบจริง (User Acceptance Testing - UAT) | ระบบพร้อม Deploy ขึ้น Production |
