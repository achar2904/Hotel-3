# ระบบแจ้งเคส (Case Reporting System) — เอกสารสรุปฉบับสมบูรณ์ (Final Spec)

> เอกสารนี้รวมและปรับปรุงจาก 3 ฉบับ: แนวคิดตั้งต้น, ฉบับตรวจสอบ (Reviewed), และฉบับประเมินความเป็นไปได้ทางเทคนิค (Feasibility) ให้เป็นเวอร์ชันเดียวที่พร้อมใช้เริ่มพัฒนาจริง

## 0. สรุปภาพรวม

ระบบแจ้งเคสสำหรับองค์กร (โรงแรม) รองรับ **5 แผนก**: IT / HK (Housekeeping) / ENG (Engineering) / Front (Front Office) / Security ใช้งานได้ทั้งมือถือและคอมพิวเตอร์ (Responsive Web App)

**Stack ที่ยืนยัน:** Google Apps Script (Backend) + Google Sheet (Database) + Google Drive (File Storage)
**ความเหมาะสม:** เหมาะกับองค์กรขนาดเล็ก–กลาง deploy ง่าย ไม่ต้องมี server แยก แต่ต้องออกแบบระบบป้องกัน **Data Collision**, **Notification Delay** และ **Performance** ล่วงหน้า เพราะเป็นข้อจำกัดโดยธรรมชาติของ GAS + Sheet

---

## 1. โครงสร้างผู้ใช้งาน (User & Role)

| ระดับ | สิทธิ์การเข้าถึง |
|---|---|
| Staff (พนักงานแผนก) | แจ้งเคสของแผนกตัวเอง, ดูสถานะเคสที่ตัวเองแจ้ง/รับผิดชอบ, ตอบกลับในเคส |
| Department Head | เห็นเคสทั้งหมดของแผนกตัวเอง, ปิดเคส/อัปเดตสถานะ, ตอบกลับในเคส |
| Admin/Manager | เห็นเคสทุกแผนก, ดูรายงานรวม, ส่งออกรีพอร์ต, รับแจ้งเตือนเมื่อเคส escalate |
| **Owner** | เห็นภาพรวมทั้งหมด + **Dashboard สถานะห้องพัก** (แยกจาก Dashboard เคส) |

### Login
- แนะนำใช้ **Google Account / Google Workspace Login** (ถ้าองค์กรมีอยู่แล้ว) — ปลอดภัยกว่าเก็บ Username/Password เองใน Sheet
- ถ้าไม่มี Workspace ต้องเข้ารหัส Password หรือใช้ Token ยืนยันตัวตน ไม่เก็บ Plain Text
- ตาราง `Users` กำหนด Department / Role / Active Status
- พนักงานลาออก → เปลี่ยน `Active = FALSE` เท่านั้น ห้ามลบแถวข้อมูล (รักษา Audit Trail)

### การเข้าถึงข้อมูล
- Staff เห็นเฉพาะเคสที่แจ้งเอง หรือที่ตนรับผิดชอบ
- Department Head เห็นเคสของแผนกตัวเองทั้งหมด
- Admin/Manager เห็นทุกแผนก
- Owner เห็นภาพรวมทั้งหมด + Room Dashboard

---

## 2. Flow การทำงานของเคส

```text
[แจ้งเคส] → [รับทราบ] → [กำลังดำเนินการ] → (เลือกได้) → [ส่งต่อแผนกอื่น] → [แก้ไขแล้ว] → [ปิดเคส]
```

**สถานะเคส (State Machine):**

```text
NEW → ACKNOWLEDGED → IN_PROGRESS → TRANSFERRED (ถ้ามี) → RESOLVED → CLOSED
```

| สถานะ | ความหมาย |
|---|---|
| NEW | แจ้งเคสแล้ว รอผู้รับเรื่อง |
| ACKNOWLEDGED | แผนก/ผู้รับผิดชอบรับทราบแล้ว |
| IN_PROGRESS | กำลังดำเนินการ |
| TRANSFERRED | ส่งต่อไปยังแผนกอื่น |
| RESOLVED | ผู้รับผิดชอบแจ้งว่าแก้ไขแล้ว (รอผู้แจ้งยืนยัน) |
| CLOSED | ปิดเคสสมบูรณ์ |

> แยก `RESOLVED` ออกจาก `CLOSED` เพื่อตรวจสอบได้ว่า "แก้ปัญหาแล้ว" กับ "ปิดเคสอย่างเป็นทางการ" เกิดขึ้นเมื่อไหร่ — การปิดเคสทำได้ทั้ง 2 ฝ่าย (ผู้รับเคสปิดเองได้ หรือผู้แจ้งกดยืนยันปิด)

---

## 3. ฟิลด์ข้อมูลเคสและโครงสร้าง Google Sheet

โครงสร้าง 6 แท็บ: `Cases`, `CaseLog`, `CaseComments`, `Users`, `Rooms`, `RoomLog`

### Users
`UserID, Email, Name, Department, Role, Active`

### Cases
`CaseID, CreatedAt, CreatedBy, DepartmentFrom, DepartmentCurrent, Location, RoomNo, Category, Subject, Description, Priority, DueAt, Status, AssignedTo, ResolvedAt, ClosedAt, UpdatedAt, UpdatedBy, ReminderCount, LastCommentAt, HasUnread, IsDeleted`

- **Category** (Dropdown ต่อแผนก): IT (Internet/Computer/Printer/Software/Network), ENG (Air/Water/Electricity/Plumbing), HK (Cleaning/Linen/Amenity) — ปรับตามการใช้งานจริง
- **LastCommentAt / HasUnread**: เพิ่มเพื่อ optimize การดึงข้อมูล (ดูข้อ 6.4)

### CaseLog (Audit Trail)
`LogID, CaseID, EventType, OldValue, NewValue, Actor, CreatedAt`
บันทึกทุกการเปลี่ยนสถานะ/ส่งต่อ/แจ้งเตือน/escalation

### CaseComments
`CommentID, CaseID, Sender, Department, Message, Type (User/System), AttachmentID, AttachmentURL, CreatedAt`

### Rooms
`RoomNo, Status (AVAILABLE/CLOSED), Reason, CurrentCaseID, UpdatedAt, UpdatedBy`

### RoomLog
`LogID, RoomNo, Action, Reason, CaseID, Actor, CreatedAt`

---

## 4. แนวทางเทคนิคและการป้องกันปัญหาเฉพาะของ GAS

### 4.1 Concurrency & Data Collision
เมื่อหลายคนเปิดเคส/ตอบแชท/อัปเดตห้องพร้อมกัน ข้อมูลใน Sheet อาจเขียนทับกันหรืออ่านผิดพลาด
**แนวทาง:** บังคับใช้ `LockService` ทุกครั้งที่เขียนข้อมูลลง `Cases`, `CaseLog`, `CaseComments`, `Rooms`, `RoomLog` เพื่อจัดคิว Transaction ทีละรายการ

### 4.2 Real-time Notification → Near Real-time
GAS ไม่รองรับ WebSocket จึงไม่สามารถ push แจ้งเตือนทันทีแบบแอปทั่วไปได้ ต้องใช้คำว่า **Near Real-time** แทน

**Flow:**
```text
มีข้อมูลใหม่ → บันทึกลง Sheet → หน้าเว็บ Polling เช็คเป็นระยะ (10–30 วินาที) → เล่นเสียง/แสดง Popup/อัปเดต UI
```

**ช่องทางแจ้งเตือน:**
- Web (เสียง + popup): Case ใหม่ / Comment ใหม่ / Status Change / Transfer
- Email: Case ใหม่, Transfer, SLA Warning, Escalation — ต้องคุม Quota การส่งอีเมลของ Workspace ไม่ให้ถี่เกินไป (โดยเฉพาะแจ้งเตือนแชท ควรรวมยอดแทนส่งทุกข้อความ)

### 4.3 SLA & Escalation (Time-Based Trigger)
Time-driven Trigger ของ GAS รันได้ถี่สุดทุก 1 นาที (แนะนำ 1–5 นาที) เพื่อเทียบ `Current Time` กับ `DueAt`

**SLA (ตัวเลขเดียว ชัดเจน):**

| ความเร่งด่วน | เวลาที่ต้องปิดเคส |
|---|---:|
| ฉุกเฉิน | 20 นาที |
| ด่วน | 40 นาที |
| ปกติ | 60 นาที |

คำนวณ: `DueAt = CreatedAt + SLA` (คำนวณเวลาโดยอ้างอิง GMT+7 ให้แม่นยำ)
Version แรก: นับ SLA แบบต่อเนื่อง 24 ชม. ไม่แยกเวลาทำการ เพื่อลดความซับซ้อน

**กฎแจ้งเตือนซ้ำ:**
```text
เลย DueAt → Reminder #1 → ยังไม่ปิด → Reminder #2 → ยังไม่ปิด → แจ้ง Admin ของแผนกที่รับผิดชอบ (ไม่ใช่ Admin รวมทุกแผนก)
```
ทุกการแจ้งเตือนบันทึกลง `CaseLog`

### 4.4 Auto-Link เคส ↔ สถานะห้องพัก
เมื่อแจ้งเคสหมวดซ่อมหนักที่ทำให้ห้องขายไม่ได้ (Out of Order) → ระบบอัปเดต `Rooms.Status = CLOSED` และบันทึก `CaseID` ลง `RoomLog` อัตโนมัติ ลดการคีย์ซ้ำ 2 รอบ

### 4.5 การจัดเก็บรูปภาพ (Image Storage)
1. บีบอัดรูป (Compress) ที่ฝั่ง Frontend ก่อนแปลงเป็น Base64 — ลดขนาดโหลดหน้าเว็บและพื้นที่ Drive
2. ส่ง Base64 ให้ Apps Script สร้างไฟล์ใน Google Drive Folder ที่เตรียมไว้
3. ตั้ง Permission โฟลเดอร์เป็น "Anyone with the link can view"
4. บันทึกทั้ง **Drive File ID, File URL, File Name, Uploaded By, Uploaded At** ลง Sheet (ไม่ใช่แค่ URL เฉยๆ เผื่อต้องจัดการไฟล์ภายหลัง)
5. `CaseComments` ก็รองรับแนบรูป/ไฟล์ได้เช่นกัน (เช่น ขอรูปเพิ่มระหว่างดำเนินการ)

### 4.6 Optimize การโหลดแชท (CaseComments)
เพิ่มคอลัมน์ `LastCommentAt` และ `HasUnread` ใน `Cases` เพื่อให้หน้าเว็บดึงเฉพาะเคสที่มีความเคลื่อนไหวใหม่มาแสดง โดยไม่ต้องอ่าน `CaseComments` ทั้งหมดทุกครั้งที่เปิดหน้าเว็บ

### 4.7 Auto Case ID
ห้ามสร้าง ID จากการนับจำนวน Row ตรงๆ (เสี่ยงซ้ำเมื่อมีผู้ใช้พร้อมกัน) แนะนำรูปแบบ:
```text
CASE-20260818-0001
```
หรือใช้ UUID เป็น ID ภายใน และแสดง Case Number แบบอ่านง่ายให้ผู้ใช้เห็น

### 4.8 Soft Delete
ห้ามลบ Case/User/Room ออกจาก Sheet จริง ใช้ flag แทน: `IsDeleted = TRUE`, `Active = FALSE` เพื่อรักษา Audit Trail ครบถ้วน

---

## 5. Case Conversation (แชทในเคส)

รองรับสนทนาไปกลับระหว่างผู้แจ้งเคสและผู้รับเคส ในไทม์ไลน์เดียวกัน ใช้กรณีเช่น:
- ขอข้อมูล/รูปเพิ่มเติม ("ห้องไหน", "ขอรูปเพิ่ม")
- แจ้งความคืบหน้า ("กำลังไปดูหน้างาน")
- ตีกลับเคสว่าไม่ใช่แผนกตน (ส่งต่อ)
- ผู้แจ้งยืนยัน/ปฏิเสธว่าแก้ไขแล้วจริงก่อนปิดเคส
- ข้อความระบบอัตโนมัติ (เช่น "ส่งต่อจาก Front ไป ENG", "แจ้งเตือนซ้ำครั้งที่ 1") แสดงร่วมไทม์ไลน์เดียวกับข้อความคน

**ประเภทข้อความ:** User Message / System Message
**Notification:** มีข้อความใหม่ → แจ้งเตือนอีกฝั่งทันที (กลไกเดียวกับข้อ 4.2)

---

## 6. Dashboard สถานะห้องพัก (สำหรับ Owner)

แยกต่างหากจาก Dashboard เคส ใช้ติดตามภาพรวมห้องพักทั้งหมด

### Setup ครั้งแรก
- Owner/Admin คีย์จำนวนห้องทั้งหมด (เช่น 200 ห้อง) + ระบุห้องที่ปิดอยู่ตอนเริ่มระบบพร้อมเหตุผล
- ระบบสร้างข้อมูล 1 ห้อง = 1 แถวใน `Rooms` พร้อมสถานะเริ่มต้น

### การอัปเดตหลังจากนั้น (คีย์เฉพาะรายการที่เปลี่ยน)
```text
ห้องซ่อมเสร็จ → เลือกห้อง → เปลี่ยนเป็น AVAILABLE → บันทึก RoomLog → คำนวณยอดรวมใหม่อัตโนมัติ
ห้องมีปัญหา → เลือกห้อง → เปลี่ยนเป็น CLOSED → ระบุเหตุผล → บันทึก RoomLog → คำนวณยอดรวมใหม่อัตโนมัติ
```

### สถานะห้อง
Version แรก: `AVAILABLE`, `CLOSED`
อนาคต (ถ้าต่อยอดเป็นระบบโรงแรมเต็มรูปแบบ) อาจเพิ่ม: `OCCUPIED`, `OUT_OF_ORDER`, `OUT_OF_SERVICE`

### หน้าจอ Dashboard
- ตัวเลขสรุป: ห้องทั้งหมด / พร้อมใช้งาน / ปิดใช้งาน / % พร้อมใช้งาน
- รายการห้องทั้งหมด → ดูรายละเอียดรายห้อง (ประวัติปิด-เปิด, เหตุผล, ใครทำ, Case ID ที่เกี่ยวข้อง)
- เชื่อมกับเคสอัตโนมัติผ่านข้อ 4.4

---

## 7. Dashboard เคส

- จำนวนเคสทั้งหมด / ต่อแผนก / ตามสถานะ / ตามความเร่งด่วน / ตาม Category
- แนวโน้มจำนวนเคสรายวัน/รายสัปดาห์ (กราฟเส้น)
- เคสที่เกินกำหนดเวลา (ไฮไลต์แยก)
- ค่าเฉลี่ยเวลาในการแก้ไข (Resolve) และเวลาในการปิดเคส (Close)
- ใช้ Chart.js หรือ Google Charts, คำนวณสรุปยอดฝั่ง Apps Script

---

## 8. ระบบรายงาน (Reporting)

- **รายวัน:** สรุปเคสวันนี้แยกตามแผนก/สถานะ ดูในเว็บ
- **รายเดือน/กำหนดเอง:** เลือกช่วงวันที่ → ดูตาราง หรือ export PDF/Excel ส่งอีเมล
- กรองได้ตาม: แผนก / สถานะ / ความเร่งด่วน / Category / Room No. / ผู้รับผิดชอบ / ช่วงวันที่
- Room Dashboard: export สรุปสถานะห้อง/ประวัติปิด-เปิด รูปแบบเดียวกัน

---

## 9. ระบบสองภาษา (Thai/English)

- UI ทั้งหมด (label, ปุ่ม, ข้อความแจ้งเตือน) มี 2 ชุด พร้อมปุ่มสลับภาษา — เก็บเป็นชุดกลาง (Dictionary/JSON) เพื่อแก้ไขง่ายในอนาคต
- ข้อความที่พนักงานพิมพ์เอง (รายละเอียดเคส, คอมเมนต์) **ไม่แปล** เก็บตามภาษาที่พิมพ์จริง
- รายงาน/Email เลือกภาษาได้ตอนสร้าง

---

## 10. ตารางสรุปความเป็นไปได้รายฟังก์ชัน

| ฟังก์ชัน | ความเป็นไปได้ | เทคโนโลยี/วิธีที่แนะนำ | ข้อควรระวัง |
|---|---|---|---|
| Multi-role Login | 100% | Google Workspace Login + แท็บ `Users` | ตั้งค่า Active/Role ให้ครบ |
| Form แจ้งเคส + แนบรูป | 100% | HTML5 Form + Google Drive API | บีบอัดรูปฝั่ง Client ก่อนส่ง |
| SLA & Reminder | 100% | GAS Time-Driven Trigger (1–5 นาที) | คำนวณเวลาอ้างอิง GMT+7 |
| Near Real-time Web Notification | 85% | Short Polling (`setInterval`) | ล่าช้ากว่าจริง ~10–30 วินาที |
| Case Conversation | 90% | Sheet `CaseComments` + Polling | ใช้ `LockService` กันข้อความสลับคิว |
| Dashboard ห้องพัก | 100% | `Rooms` + `RoomLog` + Chart.js | คำนวณยอดสรุปใน Apps Script |
| ระบบ 2 ภาษา | 100% | Frontend Dictionary (JSON) | แปลเฉพาะ UI ไม่แปลเนื้อหาที่คีย์ |

---

## 11. แผนพัฒนาแนะนำ (Phased Roadmap)

### Phase 1 — Prototype / Flow (ยังไม่มี Login)
Wireframe → Case Form → Case List → Case Detail → Case Conversation → Transfer → Change Status → Close Case → ยืนยัน Google Sheet Schema ทั้ง 6 แท็บ

### Phase 2 — User & Permission
Google Login → Users/Department/Role/Permission → Active/Inactive

### Phase 3 — ระบบอัตโนมัติ
SLA/DueAt → Escalation → Email → Web Notification (Polling) → CaseLog → Attachment (Drive) → Dashboard เคส → Report → PDF/Excel Export

### Phase 4 — Room Dashboard
Rooms/RoomLog → เปลี่ยนสถานะห้อง → Dashboard ห้องพัก → Auto-Link Case↔Room → ประวัติห้อง

### POC ก่อนเริ่ม Phase 1 เต็มรูปแบบ
ทดสอบความเสถียรของ 3 ฟังก์ชันพื้นฐานก่อน: `LockService`, อัปโหลดรูปขึ้น Drive, Time-driven Trigger

---

## 12. Checklist ยืนยันก่อนเริ่มพัฒนา

- [x] แนบรูปภาพได้แบบ Optional, เก็บใน Google Drive
- [x] Login ผ่าน Google Account/Workspace (ถ้ามี)
- [x] รองรับ 5 แผนก, Role 4 ระดับ (Staff/Dept Head/Admin/Owner)
- [x] รองรับส่งต่อข้ามแผนก + Case Conversation
- [x] CaseLog / Audit Trail ครบทุกเหตุการณ์สำคัญ
- [x] Dashboard เคส + Dashboard ห้องพัก แยกกัน
- [x] รองรับไทย/อังกฤษ
- [x] SLA: ฉุกเฉิน 20 / ด่วน 40 / ปกติ 60 นาที, Escalation หลังเตือนครบ 2 ครั้ง
- [x] นับ SLA ต่อเนื่อง 24 ชม. ใน Version แรก
- [x] `LockService` ทุกจุดที่เขียนข้อมูล
- [x] Soft Delete (`IsDeleted`/`Active`) ไม่ลบข้อมูลจริง
- [x] Auto Case ID แบบไม่ซ้ำ (`CASE-YYYYMMDD-####`)
- [x] Auto-Link เคสซ่อมหนัก ↔ สถานะห้อง (Out of Order)
- [x] `LastCommentAt`/`HasUnread` เพื่อ optimize การโหลดแชท
- [x] คุม Quota อีเมลไม่ให้ส่งถี่เกินไป

**สรุป:** โครงสร้างนี้พร้อมล็อกเป็น Requirement ฉบับสุดท้ายก่อนเริ่มเขียนโค้ดจริง เพื่อป้องกันการรื้อ Schema และ Backend ภายหลัง เริ่มจาก **Wireframe + Google Sheet Schema + POC (LockService/Drive Upload/Trigger)** ก่อน แล้วค่อยไล่ตาม Phase 1–4
