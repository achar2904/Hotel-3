# ระบบแจ้งเคส (Case Reporting System)
## ฉบับรวมข้อคิดเห็นและปรับปรุงสำหรับใช้งานจริง — Final Requirement v1.0

> **สถานะเอกสาร:** Requirement Baseline ก่อนเริ่มพัฒนา  
> **แนวทางหลัก:** Google Apps Script + Google Sheets + Google Drive + Responsive Web App  
> **กลุ่มผู้ใช้งาน:** IT / HK / ENG / Front / Security  
> **ภาษา:** ไทย / อังกฤษ  
> **เป้าหมาย:** ใช้งานจริงในองค์กรขนาดเล็ก–กลาง และสามารถขยายต่อได้ในอนาคต

---

## 1. สรุปภาพรวม

ระบบนี้เป็น Web Application สำหรับรับแจ้ง ติดตาม ส่งต่อ ดำเนินการ และปิดเคสภายในองค์กร โดยออกแบบให้ใช้ได้ทั้งโทรศัพท์ แท็บเล็ต และคอมพิวเตอร์

ระบบแบ่งออกเป็น 4 ส่วนหลัก:

1. **Case Management** — แจ้งและติดตามเคส
2. **Case Conversation & Audit Trail** — สนทนาและเก็บประวัติทุกเหตุการณ์
3. **SLA / Notification / Escalation** — ควบคุมเวลาและแจ้งเตือน
4. **Room Status Dashboard** — Dashboard สถานะห้องพักสำหรับ Owner

ข้อมูลหลักจัดเก็บใน Google Sheets และไฟล์แนบจัดเก็บใน Google Drive โดย Google Apps Script ทำหน้าที่เป็น Backend/API ระหว่างหน้าเว็บกับข้อมูล

### ข้อสรุปความเป็นไปได้

แนวทางนี้ **สามารถพัฒนาและใช้งานจริงได้** สำหรับขนาดองค์กรขนาดเล็กถึงกลาง แต่ต้องออกแบบเรื่อง Concurrency, Permission, Audit Trail, Attachment และ SLA ตั้งแต่ต้น ไม่ควรทำเป็นเพียง Google Form + Sheet แบบตรง ๆ

---

# 2. ขอบเขตระบบ

## 2.1 แผนกที่รองรับ

- IT — Information Technology
- HK — Housekeeping
- ENG — Engineering
- Front — Front Office
- Security — Security

ระบบใช้ฟอร์มแจ้งเคสกลางร่วมกันทุกแผนก แต่สามารถกำหนด Category ตามแผนกได้

ตัวอย่าง:

- IT: Internet / Computer / Printer / Software / Network
- ENG: Air Conditioner / Water / Electricity / Plumbing
- HK: Cleaning / Linen / Amenity
- Front: Guest Service / Reservation / Billing / General
- Security: Access / Incident / CCTV / Safety

รายการ Category ควรแก้ไขได้จาก Configuration โดยไม่ต้องแก้โค้ด

---

# 3. User / Role / Permission

## 3.1 Role

| Role | สิทธิ์หลัก |
|---|---|
| Staff | แจ้งเคส, ดูเคสที่ตนแจ้ง, ตอบกลับในเคส, ดูความคืบหน้าที่เกี่ยวข้อง |
| Department Head | ดูเคสของแผนก, รับผิดชอบ/มอบหมาย, เปลี่ยนสถานะ, ส่งต่อ, ปิดเคส |
| Admin / Manager | ดูทุกแผนก, รายงานรวม, Dashboard, Export, รับ Escalation |
| Owner | ดูภาพรวมทั้งหมด + Dashboard สถานะห้องพัก + รายงาน |

## 3.2 Authentication

**แนะนำให้ใช้ Google Account / Google Workspace Login**

ไม่ควรเก็บ Username/Password เองใน Google Sheet

ตาราง Users ต้องมีอย่างน้อย:

- UserID
- Email
- Name
- Department
- Role
- Active

เมื่อพนักงานออกหรือไม่ใช้งาน ให้เปลี่ยน `Active = FALSE` แทนการลบข้อมูล

## 3.3 หลักการ Permission

- Staff เห็นเฉพาะเคสที่ตนแจ้ง หรือเคสที่ได้รับมอบหมาย/เกี่ยวข้องตามสิทธิ์
- Department Head เห็นเคสของแผนกตน
- Admin/Manager เห็นทุกแผนก
- Owner เห็นข้อมูลภาพรวมทั้งหมด
- ผู้ใช้ทั่วไปต้องไม่สามารถเรียกข้อมูลจาก Google Sheet โดยตรงเพื่อข้าม Permission ของระบบ

---

# 4. Case Workflow

## 4.1 Flow หลัก

```text
NEW
 ↓
ACKNOWLEDGED
 ↓
IN_PROGRESS
 ↓
TRANSFERRED (ถ้ามี)
 ↓
RESOLVED
 ↓
CLOSED
```

## 4.2 ความหมายของสถานะ

| Status | ความหมาย |
|---|---|
| NEW | แจ้งเคสแล้ว รอผู้รับเรื่อง |
| ACKNOWLEDGED | แผนก/ผู้รับผิดชอบรับทราบแล้ว |
| IN_PROGRESS | กำลังดำเนินการ |
| TRANSFERRED | ส่งต่อไปยังแผนกอื่น |
| RESOLVED | ผู้รับผิดชอบแจ้งว่าแก้ไขแล้ว |
| CLOSED | เคสปิดสมบูรณ์ |

### เหตุผลที่แยก RESOLVED และ CLOSED

เพื่อให้ระบบทราบว่า:

- ใครเป็นผู้แก้ไขเสร็จ
- แก้ไขเสร็จเมื่อใด
- ใครเป็นผู้ปิดเคส
- เคสถูกปิดหลังการแก้ไขจริงหรือไม่

ผู้รับผิดชอบสามารถกด RESOLVED และปิดเคสได้ตามสิทธิ์ที่กำหนด หรือผู้แจ้งสามารถยืนยันการปิดได้

---

# 5. การส่งต่อเคส (Transfer)

รองรับการส่งต่อข้ามแผนก เช่น:

```text
Front
 ↓
ENG
 ↓
IT
```

เมื่อ Transfer ต้องบันทึก:

- CaseID
- Department เดิม
- Department ใหม่
- ผู้ส่งต่อ
- เหตุผล
- วันเวลา
- ผู้รับผิดชอบใหม่ (ถ้ามี)

ระบบต้องสร้าง System Message ใน Case Timeline เช่น:

```text
System: Case transferred from Front to ENG
```

การ Transfer ไม่ควรลบประวัติเดิม

---

# 6. Case Form

## 6.1 ข้อมูลหลัก

- CaseID — Auto Generated
- CreatedAt
- CreatedBy
- DepartmentFrom
- DepartmentCurrent
- AssignedTo
- Location
- RoomNo — Optional
- Category
- Subject
- Description
- Priority
- DueAt
- Status
- ResolvedAt
- ClosedAt
- ReminderCount
- LastUpdatedAt
- LastUpdatedBy
- IsDeleted

## 6.2 Priority

กำหนด 3 ระดับ:

| Priority | SLA |
|---|---:|
| ฉุกเฉิน (URGENT) | 20 นาที |
| ด่วน (HIGH) | 40 นาที |
| ปกติ (NORMAL) | 60 นาที |

**กำหนดเป็นตัวเลขเดียว** เพื่อให้ระบบคำนวณได้แน่นอน

```text
DueAt = CreatedAt + SLA
```

ตัวอย่าง:

```text
CreatedAt = 09:00
Priority = HIGH
SLA = 40 นาที
DueAt = 09:40
```

### SLA Version 1

ให้นับแบบต่อเนื่อง 24 ชั่วโมงก่อน เพื่อให้ระบบง่ายและเสถียร

หากองค์กรต้องการนับเฉพาะเวลาทำงานในอนาคต จึงค่อยเพิ่ม Business Hours / Holiday Calendar

---

# 7. SLA / Reminder / Escalation

## 7.1 หลักการ

เมื่อถึง DueAt และเคสยังไม่ปิด:

1. Reminder #1
2. Reminder #2
3. หากยังไม่ปิด → Escalate ไปยัง Admin ของแผนกที่รับผิดชอบ

ทุกเหตุการณ์ต้องบันทึกใน `CaseLog`

## 7.2 ตัวอย่าง

```text
10:00 Case Created
10:01 Case Assigned
10:40 SLA Exceeded
10:40 Reminder #1
10:50 Reminder #2
11:00 Escalated to Department Admin
```

> **ข้อกำหนดสำคัญ:** Reminder ต้องไม่ส่งซ้ำจาก Trigger หลายตัว หากมีการรันซ้อนกัน ต้องตรวจ `ReminderCount` และสถานะก่อนส่งทุกครั้ง

## 7.3 Time-driven Trigger

Apps Script ไม่ได้ทำงานแบบ WebSocket และ Trigger มีข้อจำกัดด้านความถี่

ดังนั้นให้ใช้ Time-driven Trigger ตรวจ SLA ทุกประมาณ 1–5 นาที

ระบบต้องตรวจ:

- Status
- DueAt
- ReminderCount
- LastReminderAt
- EscalationAt

---

# 8. Case Conversation

แต่ละเคสมี Conversation แบบ Thread

รองรับ:

- ผู้แจ้งถามข้อมูล
- ผู้รับเคสขอข้อมูลเพิ่มเติม
- แจ้งความคืบหน้า
- ขอรูปเพิ่มเติม
- แจ้งว่าไม่ใช่แผนกตน
- ส่งต่อ
- ยืนยันการแก้ไข
- System Message

## 8.1 Message Type

- `USER_MESSAGE`
- `SYSTEM_MESSAGE`

## 8.2 ตัวอย่าง Timeline

```text
09:00 Staff: Internet ห้อง 301 ใช้งานไม่ได้

09:02 ENG: ปัญหานี้น่าจะเกี่ยวกับ Network ขอส่งต่อ IT

09:02 System: Case transferred from ENG to IT

09:05 IT: รับเรื่องแล้ว กำลังตรวจสอบ

09:18 IT: แก้ไข Access Point เรียบร้อย

09:19 System: Case status changed to RESOLVED

09:20 Staff: ยืนยันว่าใช้งานได้แล้ว

09:20 System: Case CLOSED
```

---

# 9. Notification

## 9.1 แนวทางที่ใช้จริง

ไม่เรียกว่า Real-time แบบ WebSocket แต่ใช้ **Near Real-time**

```text
มีข้อมูลใหม่
 ↓
Backend บันทึกข้อมูล
 ↓
หน้าเว็บ Polling ทุก 10–30 วินาที
 ↓
ตรวจพบข้อมูลใหม่
 ↓
Popup + เสียง + Update UI
```

## 9.2 Notification Event

แจ้งเตือนเมื่อ:

- Case ใหม่
- Transfer
- Assignment
- Comment ใหม่
- Status Change ที่สำคัญ
- SLA Warning
- SLA Exceeded
- Escalation

## 9.3 Email

ใช้ Email สำหรับเหตุการณ์สำคัญ เช่น:

- Case ใหม่
- Transfer
- SLA Exceeded
- Escalation
- Report

ไม่ควรส่ง Email ทุก Comment เพราะอาจใช้ Quota สูงเกินจำเป็น

---

# 10. Attachment / รูปภาพ

## 10.1 หลักการ

- แนบได้ แต่ไม่บังคับ
- เก็บไฟล์ใน Google Drive
- ไม่ควรเก็บ Base64 ลง Google Sheet
- Sheet เก็บ Metadata ของไฟล์

Metadata:

- AttachmentID
- CaseID / CommentID
- DriveFileID
- FileURL
- FileName
- MimeType
- UploadedBy
- UploadedAt

## 10.2 Image Compression

ก่อน Upload ควรลดขนาดรูปจากฝั่ง Browser เช่น:

```text
Camera Photo
 ↓
Resize / Compress
 ↓
Upload
 ↓
Google Drive
```

ช่วยลด:

- เวลา Upload
- พื้นที่ Drive
- Bandwidth
- เวลาโหลดหน้า Case Detail

## 10.3 Security

ไม่ควรตั้งไฟล์ทุกไฟล์เป็น Public โดยอัตโนมัติ

ให้ใช้สิทธิ์ของ Google Drive / Domain ตามนโยบายองค์กร และให้ระบบเปิดไฟล์เฉพาะผู้มีสิทธิ์

---

# 11. Database / Google Sheets Schema

## 11.1 Tables หลัก

ระบบใช้ 6 Sheet หลัก:

1. Users
2. Cases
3. CaseLog
4. CaseComments
5. Rooms
6. RoomLog

สามารถเพิ่ม Configuration และ Attachments ในอนาคตได้

---

## 11.2 Users

| Field |
|---|
| UserID |
| Email |
| Name |
| Department |
| Role |
| Active |
| CreatedAt |
| UpdatedAt |

---

## 11.3 Cases

| Field |
|---|
| CaseID |
| CreatedAt |
| CreatedBy |
| DepartmentFrom |
| DepartmentCurrent |
| AssignedTo |
| Location |
| RoomNo |
| Category |
| Subject |
| Description |
| Priority |
| SLA_Minutes |
| DueAt |
| Status |
| ResolvedAt |
| ClosedAt |
| ReminderCount |
| LastReminderAt |
| EscalatedAt |
| LastUpdatedAt |
| LastUpdatedBy |
| IsDeleted |

---

## 11.4 CaseLog

| Field |
|---|
| LogID |
| CaseID |
| EventType |
| OldValue |
| NewValue |
| Actor |
| CreatedAt |
| Metadata |

ตัวอย่าง EventType:

- CASE_CREATED
- ACKNOWLEDGED
- STATUS_CHANGED
- ASSIGNED
- TRANSFERRED
- COMMENT_ADDED
- RESOLVED
- CLOSED
- REMINDER_SENT
- ESCALATED
- ATTACHMENT_ADDED

---

## 11.5 CaseComments

| Field |
|---|
| CommentID |
| CaseID |
| Sender |
| Department |
| Message |
| Type |
| AttachmentID |
| CreatedAt |

---

## 11.6 Rooms

| Field |
|---|
| RoomNo |
| Status |
| Reason |
| CurrentCaseID |
| UpdatedAt |
| UpdatedBy |

Version 1 ใช้:

- `AVAILABLE`
- `CLOSED`

อนาคตสามารถเพิ่ม:

- `OCCUPIED`
- `OUT_OF_ORDER`
- `OUT_OF_SERVICE`

---

## 11.7 RoomLog

| Field |
|---|
| LogID |
| RoomNo |
| Action |
| Reason |
| CaseID |
| Actor |
| CreatedAt |

---

# 12. Case ID

ไม่ควรสร้าง Case ID จากจำนวน Row เช่น `ROW-1001` เพราะเสี่ยง ID ซ้ำเมื่อมีผู้ใช้หลายคนบันทึกพร้อมกัน

แนะนำ:

```text
CASE-20260818-0001
```

โดยระบบต้องใช้ Lock ตอนสร้างเลข Running Number

หรือใช้ UUID เป็น Primary Key ภายใน และแสดง Case Number สำหรับผู้ใช้งาน

**แนวทางที่แนะนำที่สุด:**

```text
Internal ID = UUID
Display ID = CASE-YYYYMMDD-XXXX
```

---

# 13. Concurrency / Data Collision

นี่เป็นส่วนสำคัญที่สุดของระบบ Google Sheets + Apps Script

หากมีผู้ใช้งานหลายคนพร้อมกัน เช่น:

```text
Front เปิด Case
ENG รับ Case
IT ส่งต่อ Case
Owner เปิด Dashboard
```

อาจเกิด Race Condition ได้

## 13.1 แนวทางแก้

ทุก Function ที่เขียนข้อมูลสำคัญต้องใช้:

```javascript
LockService
```

โดยเฉพาะ:

- Create Case
- Update Case
- Transfer
- Assign
- Add Comment
- Update Room
- Generate Case Number
- Update Reminder Count
- Escalation

หลักการ:

```text
Acquire Lock
 ↓
Validate Current Data
 ↓
Write
 ↓
Log Event
 ↓
Release Lock
```

---

# 14. Soft Delete / Audit Trail

ไม่ควรลบข้อมูลจริงออกจาก Sheet

ใช้:

```text
IsDeleted = TRUE
```

หรือ:

```text
Active = FALSE
```

เพื่อรักษาประวัติ

ทุกการเปลี่ยนแปลงสำคัญต้องรู้:

- ใครทำ
- ทำอะไร
- ค่าเดิม
- ค่าใหม่
- เมื่อไหร่

---

# 15. Room Dashboard

Dashboard ห้องพักแยกจาก Case Dashboard และเน้นสำหรับ Owner

## 15.1 Initial Setup

ครั้งแรก:

```text
จำนวนห้องทั้งหมด = 200
ปิดใช้งาน = 20
พร้อมใช้งาน = 180
```

ระบบสร้างข้อมูลใน `Rooms`

## 15.2 การเปลี่ยนสถานะ

### เปิดใช้งาน

```text
เลือกห้อง
 ↓
AVAILABLE
 ↓
บันทึก RoomLog
 ↓
คำนวณยอดใหม่
```

### ปิดใช้งาน

```text
เลือกห้อง
 ↓
CLOSED
 ↓
ระบุเหตุผล
 ↓
ระบุ CaseID ถ้ามี
 ↓
บันทึก RoomLog
 ↓
คำนวณยอดใหม่
```

## 15.3 Auto-Link Case ↔ Room

เมื่อเคสเกี่ยวข้องกับห้องและทำให้ห้องไม่สามารถขาย/ใช้งานได้ ระบบสามารถเชื่อม:

```text
Case
 ↓
RoomNo
 ↓
Room Status = CLOSED
 ↓
CurrentCaseID = CASE-XXXX
 ↓
RoomLog
```

เมื่อแก้ไขเสร็จ สามารถเปิดห้องกลับเป็น AVAILABLE ได้

**ข้อเสนอ:** การเปลี่ยนสถานะห้องโดยอัตโนมัติควรเปิด/ปิดได้จาก Configuration และต้องมี Audit Log ทุกครั้ง

---

# 16. Dashboard เคส

ควรมีอย่างน้อย:

### KPI

- เคสทั้งหมด
- เคสใหม่
- กำลังดำเนินการ
- รอการรับเรื่อง
- เกิน SLA
- Resolved
- Closed

### วิเคราะห์

- จำนวนเคสต่อแผนก
- จำนวนเคสตาม Status
- จำนวนเคสตาม Priority
- จำนวนเคสตาม Category
- แนวโน้มรายวัน/รายสัปดาห์
- Top Category ที่เกิดปัญหา
- ค่าเฉลี่ยเวลาแก้ไข
- ค่าเฉลี่ยเวลาปิดเคส
- จำนวน Escalation

### Filter

- วันที่
- แผนก
- Status
- Priority
- Category
- Room
- AssignedTo

---

# 17. Reporting / Export

## รายวัน

สรุป:

- จำนวนเคส
- แยกแผนก
- แยก Status
- เคสที่เกิน SLA
- เคสที่ยังเปิดอยู่

## รายเดือน / Custom Range

เลือก:

```text
วันที่เริ่มต้น
วันที่สิ้นสุด
แผนก
Status
Priority
Category
Room
ผู้รับผิดชอบ
```

Output:

- Web View
- PDF
- Excel
- Email

รายงานสามารถเลือกภาษา:

- Thai
- English

---

# 18. Thai / English

UI ทั้งหมดรองรับ 2 ภาษา:

- Label
- Button
- Menu
- Status
- Notification
- Dashboard
- Report
- Email

ข้อความที่พนักงานพิมพ์เอง **ไม่ต้องแปล**

ควรเก็บ Dictionary กลาง เช่น:

```text
TH:
"สร้างเคส"

EN:
"Create Case"
```

เพื่อให้เปลี่ยนข้อความในอนาคตได้ง่าย

---

# 19. Security

## 19.1 หลักการ

- ใช้ Google Authentication
- ตรวจสอบ Email กับ Users
- ตรวจสอบ Active
- ตรวจสอบ Role
- ตรวจสอบ Department ก่อนอ่าน/เขียนข้อมูล
- ไม่เปิด Google Sheet ให้ User ทั่วไปโดยตรง
- Backend ต้องตรวจ Permission ซ้ำ ไม่พึ่งเฉพาะ UI
- ใช้ Soft Delete
- เก็บ Audit Trail

## 19.2 สำคัญ

การซ่อนปุ่มใน Frontend **ไม่ถือว่าเป็น Security**

ตัวอย่าง:

```text
Staff ไม่เห็นปุ่ม Delete
```

ไม่เพียงพอ

Backend ต้องปฏิเสธ Request ด้วยหาก Staff พยายามเรียก Function โดยตรง

---

# 20. Architecture

```text
┌─────────────────────────────┐
│ Responsive Web App          │
│ Mobile / Tablet / Desktop   │
└──────────────┬──────────────┘
               │
               ▼
┌─────────────────────────────┐
│ Google Apps Script          │
│ - Authentication            │
│ - Permission                │
│ - Case API                  │
│ - SLA                       │
│ - Notification              │
│ - Report                    │
│ - Attachment                │
└───────┬───────────┬─────────┘
        │           │
        ▼           ▼
┌─────────────┐  ┌─────────────┐
│ Google Sheet│  │ Google Drive │
│ Data / Log  │  │ Attachments  │
└─────────────┘  └─────────────┘
```

---

# 21. โครงสร้าง Frontend

## หน้า Login

- Google Login
- แสดงชื่อผู้ใช้
- แสดง Department / Role

## Dashboard

- KPI
- Chart
- Open Cases
- SLA Breach

## Create Case

- Location
- Room
- Category
- Subject
- Description
- Priority
- Attachment
- Submit

## Case List

- Case ID
- Subject
- Department
- Priority
- Status
- Due Time
- Updated
- Filter/Search

## Case Detail

- ข้อมูลเคส
- Timeline
- Conversation
- Attachment
- Transfer
- Assignment
- Status
- SLA
- Audit

## Room Dashboard

- Total
- Available
- Closed
- %
- Room List
- Room History

## Reports

- Filter
- Preview
- PDF
- Excel
- Email

---

# 22. หลักการ UX ที่ควรใช้

เนื่องจากระบบถูกใช้หน้างาน ควรออกแบบให้:

- เปิดหน้าแจ้งเคสเร็ว
- จำนวนช่องกรอกไม่มากเกินไป
- Priority เลือกง่าย
- ปุ่ม Submit เด่น
- ใช้สี/Badge แยก Status และ Priority
- Case ที่ใกล้เกิน SLA ต้องเห็นชัด
- Mobile ต้องใช้งานด้วยมือเดียวได้ในระดับหนึ่ง
- Case Detail ต้องเห็นสถานะและผู้รับผิดชอบทันที
- Conversation ต้องอ่านเหมือน Chat
- ไม่ต้อง Refresh หน้าเอง

---

# 23. Performance

เนื่องจาก Google Sheet ไม่ใช่ Database โดยตรง ต้องออกแบบไม่ให้หน้าเว็บอ่านข้อมูลทั้ง Sheet ทุกครั้ง

## หลักการ

- อ่านเฉพาะข้อมูลที่จำเป็น
- ใช้ Filter/Query ฝั่ง Backend
- Dashboard ใช้ข้อมูล Aggregate
- Case List ใช้ Pagination
- Conversation โหลดเฉพาะ CaseID
- Polling ตรวจเฉพาะ `LastUpdatedAt` / Version ที่เปลี่ยน
- ไม่โหลด Attachment ทั้งหมดในหน้า List
- ใช้ CacheService เมื่อเหมาะสมกับข้อมูลที่ไม่เปลี่ยนบ่อย

---

# 24. ข้อจำกัดของ Google Apps Script ที่ต้องยอมรับ

ระบบนี้เหมาะกับองค์กรขนาดเล็กถึงกลาง แต่ไม่ควรออกแบบโดยคิดว่า Google Sheet มีความสามารถเทียบเท่า Database Server

ข้อจำกัดสำคัญ:

1. Concurrent Write
2. Execution Time
3. Trigger Frequency
4. Email Quota
5. Drive Storage
6. Near Real-time แทน WebSocket
7. Google Sheet อาจช้าหากข้อมูลโตมาก

### แนวทางรองรับ

- LockService
- Batch Read/Write
- CacheService
- Pagination
- Archive ข้อมูลเก่า
- ลดการอ่าน Sheet
- จำกัดขนาด Attachment
- เก็บ Log แบบมีโครงสร้าง

---

# 25. Archive Strategy

เมื่อข้อมูลโตขึ้น ควรมีแผน Archive

ตัวอย่าง:

```text
Active Cases
    ↓
12 เดือน
    ↓
Archive
```

ไม่ควรปล่อยให้ `Cases` และ `CaseComments` โตไม่จำกัดโดยไม่วางแผน

Version แรกสามารถยังไม่ทำระบบ Archive อัตโนมัติ แต่ Schema ควรรองรับไว้ตั้งแต่ต้น

---

# 26. Configuration

เพื่อไม่ให้ต้องแก้ Code เมื่อมีการเปลี่ยนกฎ แนะนำให้มี Configuration Sheet ใน Phase ถัดไป

ตัวอย่าง:

| Setting | Value |
|---|---|
| URGENT_SLA | 20 |
| HIGH_SLA | 40 |
| NORMAL_SLA | 60 |
| POLLING_INTERVAL | 15000 |
| MAX_REMINDER | 2 |
| DEFAULT_LANGUAGE | TH |
| AUTO_ROOM_CLOSE | TRUE/FALSE |

รายการที่เป็น Business Rule ควรดึงจาก Configuration แทนการ Hard-code

---

# 27. Error Handling

ทุก API สำคัญต้องคืนผลลัพธ์ที่มีโครงสร้าง เช่น:

```text
SUCCESS
ERROR
UNAUTHORIZED
FORBIDDEN
NOT_FOUND
VALIDATION_ERROR
SYSTEM_ERROR
```

เมื่อเกิด Error:

- ไม่แสดง Error ภายในให้ User เห็นทั้งหมด
- บันทึก Error Log ฝั่งระบบ
- แสดงข้อความที่เข้าใจง่าย
- ไม่เขียนข้อมูลบางส่วนแล้วปล่อย Transaction ค้าง

---

# 28. Backup / Recovery

Google Sheet มี Version History แต่ไม่ควรพึ่งอย่างเดียว

ควรวางแผน:

- Backup Spreadsheet
- Backup Drive Folder
- จำกัดผู้มีสิทธิ์แก้ Schema
- แยก Production กับ Test
- มีสำเนา Test สำหรับทดลอง Code

---

# 29. Environment

ควรแยก:

```text
DEV / TEST
     ↓
PRODUCTION
```

ไม่ควรทดลอง Code ที่เขียนข้อมูลจริงโดยตรง

ก่อน Deploy Production ต้องทดสอบ:

- Login
- Permission
- Create Case
- Concurrent Create
- Transfer
- Comment
- Attachment
- SLA
- Reminder
- Escalation
- Room Update
- Report
- Export

---

# 30. Development Plan

## Phase 0 — Requirement Freeze

ล็อก:

- Role
- Permission
- Workflow
- Status
- Priority
- SLA
- Department
- Category
- Room Rule
- Notification

## Phase 1 — Prototype

พัฒนา:

1. Wireframe
2. Google Sheet Schema
3. Case Form
4. Case List
5. Case Detail
6. Conversation
7. Transfer
8. Status
9. Close Case

เป้าหมาย: ทดสอบ Workflow ก่อน

## Phase 2 — Authentication & Permission

1. Google Login
2. Users
3. Department
4. Role
5. Permission
6. Active/Inactive

## Phase 3 — Production Core

1. LockService
2. Case ID
3. CaseLog
4. Attachment
5. SLA
6. Reminder
7. Escalation
8. Notification
9. Error Handling
10. Security

## Phase 4 — Dashboard & Report

1. Case Dashboard
2. Room Dashboard
3. Report
4. PDF
5. Excel
6. Email

## Phase 5 — Room Integration

1. Rooms
2. RoomLog
3. Case ↔ Room
4. Auto-Link
5. Room History

## Phase 6 — Optimization

1. Cache
2. Pagination
3. Archive
4. Performance Test
5. Security Test
6. Backup
7. Production Hardening

---

# 31. Test Case ที่ต้องผ่านก่อน Production

## Case Management

- [ ] Staff สร้าง Case ได้
- [ ] Case ID ไม่ซ้ำ
- [ ] Case ถูกบันทึกครบทุก Field
- [ ] Department เห็นเฉพาะข้อมูลตามสิทธิ์
- [ ] Transfer ได้
- [ ] Assignment ได้
- [ ] Status เปลี่ยนได้ตาม Workflow
- [ ] Resolved ได้
- [ ] Closed ได้
- [ ] Soft Delete ทำงาน

## Conversation

- [ ] เพิ่ม Comment ได้
- [ ] Comment ไม่หายเมื่อมีหลายคนส่งพร้อมกัน
- [ ] System Message ถูกบันทึก
- [ ] Attachment ใน Comment ใช้งานได้

## SLA

- [ ] DueAt ถูกคำนวณถูกต้อง
- [ ] Reminder #1 ถูกส่ง
- [ ] Reminder #2 ถูกส่ง
- [ ] Escalation ทำงาน
- [ ] ไม่ส่งซ้ำ
- [ ] ทุก Event ลง CaseLog

## Room

- [ ] เปลี่ยน AVAILABLE → CLOSED
- [ ] CLOSED → AVAILABLE
- [ ] บันทึกเหตุผล
- [ ] RoomLog ครบ
- [ ] CaseID เชื่อมได้
- [ ] Dashboard คำนวณยอดถูกต้อง

## Security

- [ ] User ที่ไม่อยู่ใน Users เข้าไม่ได้
- [ ] Active = FALSE เข้าไม่ได้
- [ ] Staff ไม่สามารถดูข้อมูลที่ไม่ได้รับสิทธิ์
- [ ] Backend ตรวจ Permission
- [ ] ไม่มี Password เก็บใน Sheet
- [ ] Attachment ไม่เปิด Public โดยไม่จำเป็น

## Performance

- [ ] ทดสอบผู้ใช้พร้อมกันหลายคน
- [ ] ทดสอบการสร้าง Case พร้อมกัน
- [ ] ทดสอบ Comment พร้อมกัน
- [ ] ทดสอบ Dashboard เมื่อข้อมูลเพิ่มขึ้น
- [ ] ทดสอบ Attachment ขนาดสูงสุด

---

# 32. สิ่งที่ควรทำก่อนเริ่มเขียนระบบจริง

ต้องจัดทำ 3 อย่างก่อน:

### 1. Wireframe

ออกแบบ:

- Login
- Dashboard
- Create Case
- Case List
- Case Detail
- Conversation
- Report
- Room Dashboard

### 2. Google Sheet Schema

สร้าง Header ของทุก Sheet ให้ตรงกับ Requirement นี้

### 3. POC

ทดสอบเฉพาะจุดเสี่ยงก่อน:

- LockService
- Auto Case ID
- Concurrent Write
- Google Login
- Upload Drive
- SLA Trigger
- Notification
- Permission

ถ้า POC ผ่าน จึงเริ่มพัฒนา UI เต็มรูปแบบ

---

# 33. ข้อกำหนดที่ถือว่า "ล็อกแล้ว" สำหรับ Version 1.0

- [x] Responsive Web App
- [x] Google Apps Script
- [x] Google Sheets
- [x] Google Drive
- [x] Google Account / Workspace Login
- [x] 5 Departments
- [x] Staff / Department Head / Admin-Manager / Owner
- [x] Case Workflow
- [x] Transfer ข้ามแผนก
- [x] Case Conversation
- [x] CaseLog / Audit Trail
- [x] Attachment
- [x] Case Dashboard
- [x] Room Dashboard
- [x] Thai / English
- [x] SLA 20 / 40 / 60 นาที
- [x] Reminder 2 ครั้ง
- [x] Escalation ไปยัง Admin แผนก
- [x] Near Real-time Notification
- [x] LockService
- [x] Soft Delete
- [x] Auto Case ID
- [x] Room ↔ Case Link
- [x] PDF / Excel Report
- [x] SLA แบบ 24 ชั่วโมงใน Version 1

---

# 34. จุดที่ปรับปรุงจากเอกสารเดิม

เอกสารรวมฉบับนี้ปรับแนวคิดสำคัญให้พร้อมสำหรับการพัฒนาจริงดังนี้:

1. เปลี่ยน Real-time เป็น Near Real-time ให้ตรงกับข้อจำกัดของ Apps Script
2. กำหนด SLA เป็น 20 / 40 / 60 นาทีแบบตัวเลขเดียว
3. แยก `RESOLVED` และ `CLOSED`
4. เพิ่ม `CreatedBy / UpdatedBy / LastUpdatedAt`
5. เพิ่ม `ReminderCount / LastReminderAt / EscalatedAt`
6. เพิ่ม `Assignment`
7. เพิ่ม `Location / RoomNo / Category`
8. เพิ่ม Attachment Metadata
9. เพิ่ม System Message ใน Timeline
10. เพิ่ม LockService ในทุก Transaction สำคัญ
11. เพิ่ม Soft Delete
12. ป้องกัน Case ID ซ้ำ
13. เพิ่ม Backend Permission Check
14. เพิ่ม Error Handling
15. เพิ่ม Performance Strategy
16. เพิ่ม Archive Strategy
17. เพิ่ม DEV / TEST / PRODUCTION
18. เพิ่ม Backup / Recovery
19. เพิ่ม Configuration สำหรับ Business Rules
20. เพิ่ม Production Test Checklist

---

# 35. ข้อสรุปสุดท้าย

**ระบบสามารถพัฒนาได้จริง และแนวทาง Google Apps Script + Google Sheets + Google Drive เหมาะสำหรับ Version 1 ขององค์กรขนาดเล็กถึงกลาง**

โครงสร้างที่ควรยึดเป็นฐานคือ:

```text
Responsive Web App
        ↓
Google Apps Script
        ↓
┌───────────────┬───────────────┐
│ Google Sheets │ Google Drive  │
│ Data + Logs   │ Attachments   │
└───────────────┴───────────────┘
```

จุดที่สำคัญที่สุดก่อนเริ่ม Production คือ:

1. **Permission ต้องถูกต้อง**
2. **ข้อมูลต้องไม่ชนกันเมื่อหลายคนใช้งานพร้อมกัน**
3. **Case ID ต้องไม่ซ้ำ**
4. **ทุกการเปลี่ยนแปลงต้องมี Audit Trail**
5. **SLA / Reminder / Escalation ต้องไม่แจ้งซ้ำ**
6. **Attachment ต้องมีการควบคุมสิทธิ์**
7. **ระบบต้องไม่อ่าน Google Sheet ทั้งหมดทุกครั้ง**
8. **ต้องมี DEV/TEST ก่อน Production**
9. **ต้องมี Backup และแผนรองรับข้อมูลโต**
10. **ต้องทำ POC จุดเสี่ยงก่อนเริ่มพัฒนาเต็มระบบ**

### สถานะความพร้อม

| รายการ | สถานะ |
|---|---|
| แนวคิดระบบ | ✅ พร้อม |
| Workflow | ✅ พร้อม |
| User / Role | ✅ พร้อม |
| Schema | ✅ พร้อมเป็น Baseline |
| SLA | ✅ พร้อม |
| Notification | ✅ แนวทางชัดเจน |
| Attachment | ✅ แนวทางชัดเจน |
| Security | 🟡 ต้องทดสอบจริง |
| Dashboard | 🟡 ทำ Wireframe ต่อ |
| Report | 🟡 ทำ Template ต่อ |
| POC | 🟢 ควรเริ่มทันที |
| Production | 🔴 ยังไม่ควร Deploy จนผ่าน Test |

## ข้อเสนอสุดท้าย

**ไม่ควรเริ่มจากการเขียนระบบเต็มทันที**

ให้เริ่มตามลำดับ:

```text
Requirement Freeze
      ↓
Google Sheet Schema
      ↓
Wireframe
      ↓
POC จุดเสี่ยง
      ↓
Prototype Flow
      ↓
Login + Permission
      ↓
SLA + Notification
      ↓
Dashboard + Report
      ↓
Room Integration
      ↓
Security / Performance Test
      ↓
Production
```

เมื่อผ่านขั้นตอน POC และ Test แล้ว จึงถือว่าเป็น Version ที่พร้อมใช้งานจริง ไม่ใช่เพียง Prototype
