# 🏢 D:\Ann — ศูนย์รวมโปรเจกต์และระบบปฏิบัติการโรงแรม (Workspace Master Guide)

> **ศูนย์รวมซอร์สโค้ด เอกสารสถาปัตยกรรมระบบ และเครื่องมือเซิร์ฟเวอร์สำหรับระบบบริหารจัดการโรงแรม**  
> จัดทำสำหรับ: **คุณเอก** • พัฒนาและดูแลโดย: **แอน (AI Pair Programmer)**

---

## 📂 ผังโครงสร้างโฟลเดอร์ใน `D:\Ann\`

```text
D:\Ann\
│
├── 🏨 hotel 3\               ➔ 🌟 [ระบบหลักเวอร์ชันล่าสุด] Hotel Operations Enterprise Edition
│   ├── 👑 admin\             ➔ ศูนย์ควบคุมแอดมินและผู้บริหาร (Modular: Tabs, KPIs, Rooms, Users)
│   ├── 📱 user\              ➔ ระบบรับ-ส่งงานพนักงาน 4 แผนก (Create Case, Queue, Front Room View)
│   ├── 🎨 css\               ➔ ระบบ Modular CSS ตามมาตรฐานสากล (Base, Components, Layout)
│   ├── ⚡ server.js          ➔ Node.js HTTP Server พร้อม Session Tokens และ Route Guards
│   ├── 🗄️ db.js             ➔ MySQL Connection Pool
│   ├── 📜 init-mysql.sql     ➔ สคริปต์สร้างฐานข้อมูล hotel_case_db และ Schema
│   ├── 🌱 seed-all.js        ➔ สคริปต์นำเข้าข้อมูลตั้งต้นและห้องพัก 422 ห้อง
│   ├── ⚙️ open-demo.bat      ➔ สคริปต์คลิกเปิดระบบและเข้าเว็บทันที
│   ├── 📦 package.json       ➔ รายการโมดูลและคำสั่ง (npm start, npm run seed)
│   ├── 📄 README.md          ➔ คู่มือระบบ Hotel 3 อย่างละเอียด
│   └── 🌐 Git Repo           ➔ https://github.com/achar2904/Hotel-3.git
│
├── 🗄️ hotel 1\               ➔ 🛠️ [โครงสร้างพื้นฐาน & ฐานข้อมูล] Infrastructure & Services
│   ├── 📁 mysql\             ➔ โปรแกรม Portable MySQL 10.11 Server (Port 3306)
│   ├── 📁 tunnel\            ➔ โปรแกรม Cloudflare Tunnel (cloudflared.exe)
│   ├── 📁 app\               ➔ โค้ดระบบเวอร์ชัน 1.0 เดิม
│   ├── 📁 database\          ➔ โครงสร้าง SQL Schema และ Seed Data v1
│   ├── ⚙️ open-database.bat  ➔ สคริปต์เปิดฐานข้อมูล
│   └── ⚙️ start-all.bat      ➔ สคริปต์เริ่มการทำงานบริการทั้งหมด
│
├── 📋 hotel 2\               ➔ 📑 [เอกสารข้อกำหนด & แผนงาน] Specs & Blueprints
│   ├── 📄 FinalC.md          ➔ เอกสารสรุปข้อกำหนดระบบแจ้งเคสข้ามแผนกและบทบาทผู้ใช้
│   ├── 📄 FinalG.md          ➔ แนวทางการเชื่อมต่อฐานข้อมูลและการประเมินทางเทคนิค
│   ├── 📄 FinalP.md          ➔ แผนแม่บทการพัฒนา (Master Plan) และลำดับขั้นตอน (Milestones)
│   └── 📄 README.md          ➔ คำอธิบายเอกสารในโฟลเดอร์ hotel 2
│
├── 📱 hotel-demo\            ➔ 🧪 [ตัวต้นแบบทดลองด่วน] Standalone Prototype
│   ├── 📱 user.html          ➔ หน้าจอพนักงานทดสอบแบบ Standalone (localStorage)
│   ├── 👑 admin.html         ➔ หน้าจอแอดมินทดสอบแบบ Standalone
│   ├── ⚡ server.js          ➔ เซิร์ฟเวอร์ Express สำหรับทดลอง UI
│   └── 📄 README.md          ➔ คู่มือสำหรับตัวทดสอบ Standalone
│
├── 🎨 design-md\             ➔ 🎨 คลังดีไซน์และแนวทางการออกแบบ UI จากแบรนด์ชั้นนำระดับโลก
├── 📄 DESIGN.md              ➔ สรุปแนวคิดการออกแบบ UI/UX สำหรับระบบโรงแรม
│
├── 🤖 .agents\               ➔ โฟลเดอร์ตั้งค่าระบบ AI Agent
├── 📄 AGENTS.md              ➔ ข้อกำหนดและกฎการทำงานเชิงรุกของ AI Pair Programmer (แอน)
├── 📄 GEMINI.md              ➔ แนวทางการพัฒนาและข้อตกลงร่วมกัน
│
├── 🎮 CatDog\                ➔ 🐾 โปรเจกต์โมเดล AI จำแนกภาพสัตว์ (Cat vs Dog Classifier)
├── 🎲 chill-board-game\      ➔ ♟️ โปรเจกต์เว็บแอปพลิเคชันเกมกระดาน (Chill Board Game)
│
├── 📄 .gitignore             ➔ การกรองไฟล์ระบบ ไม่นำ node_modules และไฟล์ชั่วคราวขึ้น Git
└── 📄 README.md              ➔ เอกสารคู่มือภาพรวมฉบับนี้
```

---

## 🚀 สรุปขั้นตอนการเปิด-ปิดระบบ Hotel 3 (Operation Guide)

ระบบหลักที่ใช้งานจริงคือ **`hotel 3`** ซึ่งใช้ฐานข้อมูล MySQL จาก **`hotel 1/mysql`**

### 1. วิธีเปิดระบบ (Start System)
เปิดบริการตามลำดับดังนี้:
1. **เปิดฐานข้อมูล MySQL (Port 3306):**
   ```powershell
   & "D:\Ann\hotel 1\mysql\bin\mysqld.exe" --defaults-file="D:\Ann\hotel 1\mysql\my.ini"
   ```
2. **เปิดเว็บเซิร์ฟเวอร์ Hotel 3 (Port 8080):**
   ```powershell
   cd "D:\Ann\hotel 3"
   node server.js
   ```
   *(หรือดับเบิลคลิกไฟล์ `D:\Ann\hotel 3\open-demo.bat`)*
3. **เปิดออนไลน์ผ่าน Cloudflare Tunnel (อุปกรณ์นอกสถานที่/มือถือ):**
   ```powershell
   & "D:\Ann\hotel 1\tunnel\cloudflared.exe" tunnel --url http://localhost:8080
   ```

### 2. วิธีปิดระบบ (Graceful Shutdown)
เมื่อต้องการยุติการทำงานของระบบ:
1. ปิดโพรเซส `node server.js` และ `cloudflared.exe`
2. ปิด MySQL อย่างปลอดภัยผ่านคำสั่ง:
   ```powershell
   & "D:\Ann\hotel 1\mysql\bin\mysqladmin.exe" -u root shutdown
   ```

---

## 👥 ตารางบัญชีผู้ใช้งานสำหรับทดสอบ (Demo Credentials)

เข้าสู่ระบบที่: **[http://localhost:8080/](http://localhost:8080/)**

| รหัสพนักงาน (ID) | รหัส PIN | ชื่อพนักงาน | แผนกสังกัด | สิทธิ์ (Role) | หน้าที่และสิทธิ์การเข้าถึง |
|:---:|:---:|---|---|:---:|---|
| **`900001`** | `123456` | คุณเอก (Admin) | บริหารส่วนกลาง | **ADMIN** | สิทธิ์สูงสุด ควบคุมเคส ผังห้อง 422 ห้อง และจัดการผู้ใช้งาน |
| **`900002`** | `123456` | คุณประธาน (Owner) | คณะผู้บริหาร | **OWNER** | ดูแดชบอร์ด รายงานเคส 4 แผนก และสถานะห้อง (โหมดอ่านอย่างเดียว) |
| **`100101`** | `123456` | คุณน้ำหวาน (Front) | ฟร้อนท์ (FRONT) | **STAFF** | แจ้งเคส, คิวงาน, และ **สิทธิ์จัดการสถานะห้องพัก 422 ห้องเหมือนแอดมิน** |
| **`100201`** | `123456` | พี่บัวผัน (HK) | แม่บ้าน (HK) | **STAFF** | รับงานทำความสะอาด ตรวจสอบห้อง และปิดงานเคส |
| **`100301`** | `123456` | ช่างสมศักดิ์ (ENG) | ช่าง (ENG) | **STAFF** | รับงานซ่อมบำรุง พักงานรออะไหล่ และปิดงาน |
| **`100401`** | `123456` | นายวิชัย (IT) | ไอที (IT) | **STAFF** | รับงานบริการระบบไอที Wi-Fi และโทรศัพท์ภายใน |

---

## 🌐 Git Repositories

| โฟลเดอร์ | Remote Repository URL | รายละเอียด |
|---|---|---|
| **`D:\Ann\hotel 3`** | [https://github.com/achar2904/Hotel-3.git](https://github.com/achar2904/Hotel-3.git) | โปรเจกต์หลักเวอร์ชันสมบูรณ์ (Production) |
| **`D:\Ann`** | [https://github.com/achar2904/Hotel-test1.git](https://github.com/achar2904/Hotel-test1.git) | เวิร์กสเปซภาพรวมและเวอร์ชันก่อนหน้า |
