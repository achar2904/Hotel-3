// ==========================================================================
// CatDog: Battle of Paws - Bot AI (Single Player Mode)
// Simulates thinking, gacha spin, and funny taunts
// ==========================================================================

const BOT_TAUNTS = [
  '🐶: เดี๋ยวเจอหมัดเด็ดของเจ้าตูบ!',
  '🐶: ขอของเรทตำนานทีเถอะ สาธุ!',
  '🐶: เหมียวซ่า วันนี้แหละจะโดนสั่งสอน!',
  '🐶: สุ่มของดีมาฟาดแล้วจะหนาว!',
  '🐶: ฮ่าๆๆๆ เกราะนายหนาแค่ไหนก็ไม่รอด!',
  '🐶: ขอนมกล่องมาเพิ่มพลังด่วนๆ!',
  '🐶: ทุเรียนจ๋า จงออกมาหาฉัน!'
];

class BotAI {
  constructor(playerId = 'dog', name = 'บอทตูบจอมป่วน') {
    this.playerId = playerId;
    this.name = name;
    this.isThinking = false;
  }

  getRandomTaunt() {
    return BOT_TAUNTS[Math.floor(Math.random() * BOT_TAUNTS.length)];
  }

  // Schedule bot turn with natural delay
  takeTurn(engine, onRollStart, onActionExecute) {
    if (this.isThinking) return;
    if (engine.winner || engine.currentTurn !== this.playerId) return;

    this.isThinking = true;

    // 1. Bot starts thinking / spinning
    setTimeout(() => {
      if (engine.winner || engine.currentTurn !== this.playerId) {
        this.isThinking = false;
        return;
      }

      if (typeof onRollStart === 'function') {
        onRollStart({
          taunt: this.getRandomTaunt(),
          botName: this.name
        });
      }

      // 2. Bot draws item
      setTimeout(() => {
        if (engine.winner || engine.currentTurn !== this.playerId) {
          this.isThinking = false;
          return;
        }

        const gachaResult = rollGachaItem();
        const actionResult = engine.executeAction(this.playerId, gachaResult.item);

        this.isThinking = false;

        if (actionResult && typeof onActionExecute === 'function') {
          actionResult.gacha = gachaResult;
          onActionExecute(actionResult);
        }
      }, 1500);

    }, 800);
  }
}

const botAI = new BotAI('dog', 'บอทตูบจอมป่วน');

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { botAI, BotAI };
}
