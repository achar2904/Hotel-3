// ==========================================================================
// CatDog: Battle of Paws - Main Application Controller
// Orchestrates UI, Animations, Bot AI, and LAN Multiplayer
// ==========================================================================

document.addEventListener('DOMContentLoaded', () => {
  // ------------------------------------------------------------------------
  // State
  // ------------------------------------------------------------------------
  let gameMode = 'bot'; // 'bot', 'hotseat', 'lan'
  let localEngine = new BattleEngine();
  let isAnimating = false;
  let lanRoomCode = null;
  let lanPlayerId = null; // 'cat' or 'dog'

  // ------------------------------------------------------------------------
  // DOM Elements
  // ------------------------------------------------------------------------
  const catCard = document.getElementById('catCard');
  const dogCard = document.getElementById('dogCard');
  const catSprite = document.getElementById('catSprite');
  const dogSprite = document.getElementById('dogSprite');
  const catHpFill = document.getElementById('catHpFill');
  const catHpText = document.getElementById('catHpText');
  const catArmorFill = document.getElementById('catArmorFill');
  const catArmorText = document.getElementById('catArmorText');
  const dogHpFill = document.getElementById('dogHpFill');
  const dogHpText = document.getElementById('dogHpText');
  const dogArmorFill = document.getElementById('dogArmorFill');
  const dogArmorText = document.getElementById('dogArmorText');

  const roundIndicator = document.getElementById('roundIndicator');
  const turnTitle = document.getElementById('turnTitle');
  const turnSubtitle = document.getElementById('turnSubtitle');
  const btnRollGacha = document.getElementById('btnRollGacha');
  const btnRollText = document.getElementById('btnRollText');
  const combatLogList = document.getElementById('combatLogList');
  const lanStatusBadge = document.getElementById('lanStatusBadge');
  const lanRoomCodeDisplay = document.getElementById('lanRoomCodeDisplay');
  const currentModeLabel = document.getElementById('currentModeLabel');

  // Gacha 2D Wheel & Overlay
  const gachaOverlay = document.getElementById('gachaOverlay');
  const wheelStage = document.getElementById('wheelStage');
  const wheelCanvas = document.getElementById('wheelCanvas');
  const wheelPointer = document.getElementById('wheelPointer');
  const wheelActionHint = document.getElementById('wheelActionHint');
  const wheelCtx = wheelCanvas ? wheelCanvas.getContext('2d') : null;
  const gachaCard = document.getElementById('gachaCard');
  const gachaTierBadge = document.getElementById('gachaTierBadge');
  const gachaItemIcon = document.getElementById('gachaItemIcon');
  const gachaItemName = document.getElementById('gachaItemName');
  const gachaItemDesc = document.getElementById('gachaItemDesc');
  const gachaItemStat = document.getElementById('gachaItemStat');

  // Modals
  const modeSelectModal = document.getElementById('modeSelectModal');
  const lanModal = document.getElementById('lanModal');
  const encyclopediaModal = document.getElementById('encyclopediaModal');
  const victoryModal = document.getElementById('victoryModal');
  const encyclopediaGrid = document.getElementById('encyclopediaGrid');

  // LAN Elements
  const lanUrlInput = document.getElementById('lanUrlInput');
  const btnCopyLanUrl = document.getElementById('btnCopyLanUrl');
  const hostNameInput = document.getElementById('hostNameInput');
  const guestNameInput = document.getElementById('guestNameInput');
  const btnCreateRoom = document.getElementById('btnCreateRoom');
  const joinRoomCodeInput = document.getElementById('joinRoomCodeInput');
  const btnJoinRoom = document.getElementById('btnJoinRoom');
  const activeRoomsList = document.getElementById('activeRoomsList');
  const btnRefreshRooms = document.getElementById('btnRefreshRooms');

  // LAN Lobby Elements
  const lanLobbyModal = document.getElementById('lanLobbyModal');
  const lobbyRoomBadge = document.getElementById('lobbyRoomBadge');
  const btnCopyRoomCode = document.getElementById('btnCopyRoomCode');
  const btnCopyRoomLink = document.getElementById('btnCopyRoomLink');
  const lobbyCatCard = document.getElementById('lobbyCatCard');
  const lobbyCatName = document.getElementById('lobbyCatName');
  const lobbyCatStatus = document.getElementById('lobbyCatStatus');
  const lobbyCatReadyBadge = document.getElementById('lobbyCatReadyBadge');
  const btnCatToggleReady = document.getElementById('btnCatToggleReady');
  const btnCatReadyText = document.getElementById('btnCatReadyText');
  const lobbyDogCard = document.getElementById('lobbyDogCard');
  const lobbyDogName = document.getElementById('lobbyDogName');
  const lobbyDogStatus = document.getElementById('lobbyDogStatus');
  const lobbyDogReadyBadge = document.getElementById('lobbyDogReadyBadge');
  const btnDogToggleReady = document.getElementById('btnDogToggleReady');
  const btnDogReadyText = document.getElementById('btnDogReadyText');
  const lobbyStatusBanner = document.getElementById('lobbyStatusBanner');
  const btnStartGame = document.getElementById('btnStartGame');
  const btnStartGameText = document.getElementById('btnStartGameText');
  const btnLeaveRoom = document.getElementById('btnLeaveRoom');

  // Buttons
  const btnModeSelect = document.getElementById('btnModeSelect');
  const btnEncyclopedia = document.getElementById('btnEncyclopedia');
  const btnSoundToggle = document.getElementById('btnSoundToggle');
  const soundIcon = document.getElementById('soundIcon');
  const btnRematch = document.getElementById('btnRematch');
  const btnBackToLobby = document.getElementById('btnBackToLobby');

  // ------------------------------------------------------------------------
  // Initialize Encyclopedia
  // ------------------------------------------------------------------------
  function renderEncyclopedia() {
    encyclopediaGrid.innerHTML = '';
    ITEMS.forEach(item => {
      const tier = TIERS[item.tier];
      const card = document.createElement('div');
      card.className = 'encyclopedia-card';
      card.style.borderColor = tier.border;

      let statText = '';
      if (item.type === 'attack') statText = `💥 ดาเมจ ${item.damage}`;
      else if (item.type === 'heal') statText = `❤️ เลือด +${item.heal}`;
      else if (item.type === 'shield') statText = `🛡️ เกราะ +${item.shield}`;
      else if (item.type === 'hybrid') statText = `🌟 +${item.heal} HP & +${item.shield} เกราะ`;

      card.innerHTML = `
        <div class="encyclopedia-icon">${item.icon}</div>
        <div class="encyclopedia-details">
          <div class="encyclopedia-header">
            <span class="encyclopedia-name">${item.name}</span>
            <span class="encyclopedia-badge" style="background:${tier.color}; color:#fff;">${tier.badge}</span>
          </div>
          <div style="font-size:0.8rem; font-weight:700; color:${tier.color};">${statText}</div>
          <div class="encyclopedia-desc">${item.desc}</div>
        </div>
      `;
      encyclopediaGrid.appendChild(card);
    });
  }
  renderEncyclopedia();

  // ------------------------------------------------------------------------
  // UI Helpers: Modals & Toasts
  // ------------------------------------------------------------------------
  function openModal(modal) {
    modal.classList.add('active');
  }

  function closeModal(modal) {
    modal.classList.remove('active');
  }

  document.querySelectorAll('.modal-close').forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-close');
      const target = document.getElementById(targetId);
      if (target) closeModal(target);
    });
  });

  function showToast(msg, icon = '🐾') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<span>${icon}</span> <span>${msg}</span>`;
    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(15px)';
      setTimeout(() => toast.remove(), 300);
    }, 2800);
  }

  // Floating Combat Numbers
  function spawnFloatingNumber(targetCard, text, type = 'damage') {
    const rect = targetCard.getBoundingClientRect();
    const el = document.createElement('div');
    el.className = `floating-text ${type}`;
    el.textContent = text;
    el.style.left = `${rect.left + rect.width / 2 - 30}px`;
    el.style.top = `${rect.top + rect.height / 3}px`;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 1200);
  }

  // Screen Shake
  function triggerScreenShake() {
    document.body.classList.remove('screen-shake');
    void document.body.offsetWidth;
    document.body.classList.add('screen-shake');
    setTimeout(() => document.body.classList.remove('screen-shake'), 400);
  }

  // ------------------------------------------------------------------------
  // Sound Controls
  // ------------------------------------------------------------------------
  btnSoundToggle.addEventListener('click', () => {
    sound.ensureContext();
    const muted = sound.toggleMute();
    soundIcon.textContent = muted ? '🔇' : '🔊';
    showToast(muted ? 'ปิดเสียงแล้ว' : 'เปิดเสียงแล้ว', muted ? '🔇' : '🔊');
  });

  // ------------------------------------------------------------------------
  // HUD Status & Gauges Update
  // ------------------------------------------------------------------------
  function updateHUD(engineState) {
    const { players, currentTurn, round, winner } = engineState;
    const cat = players.cat;
    const dog = players.dog;

    // Cat Gauges
    const catHpPct = Math.max(0, Math.min(100, (cat.hp / cat.maxHp) * 100));
    catHpFill.style.width = `${catHpPct}%`;
    catHpText.textContent = `${cat.hp} / ${cat.maxHp}`;
    if (catHpPct <= 30) catHpFill.classList.add('danger');
    else catHpFill.classList.remove('danger');

    const catArmorPct = Math.max(0, Math.min(100, (cat.armor / cat.maxArmor) * 100));
    catArmorFill.style.width = `${catArmorPct}%`;
    catArmorText.textContent = `${cat.armor} / ${cat.maxArmor}`;
    if (cat.armor > 0) catCard.classList.add('has-armor');
    else catCard.classList.remove('has-armor');

    // Dog Gauges
    const dogHpPct = Math.max(0, Math.min(100, (dog.hp / dog.maxHp) * 100));
    dogHpFill.style.width = `${dogHpPct}%`;
    dogHpText.textContent = `${dog.hp} / ${dog.maxHp}`;
    if (dogHpPct <= 30) dogHpFill.classList.add('danger');
    else dogHpFill.classList.remove('danger');

    const dogArmorPct = Math.max(0, Math.min(100, (dog.armor / dog.maxArmor) * 100));
    dogArmorFill.style.width = `${dogArmorPct}%`;
    dogArmorText.textContent = `${dog.armor} / ${dog.maxArmor}`;
    if (dog.armor > 0) dogCard.classList.add('has-armor');
    else dogCard.classList.remove('has-armor');

    // Turn & Round Display
    roundIndicator.textContent = `รอบที่ ${round}`;

    if (currentTurn === 'cat') {
      catCard.classList.add('active-turn');
      dogCard.classList.remove('active-turn');
      turnTitle.textContent = `เทิร์นของ ${cat.name}!`;
      turnTitle.style.background = 'linear-gradient(135deg, #fb923c, #f97316)';
      turnTitle.style.webkitBackgroundClip = 'text';
      turnSubtitle.textContent = 'กดปุ่มเพื่อสุ่มของใช้ในบ้านมาต่อสู้!';
    } else {
      dogCard.classList.add('active-turn');
      catCard.classList.remove('active-turn');
      turnTitle.textContent = `เทิร์นของ ${dog.name}!`;
      turnTitle.style.background = 'linear-gradient(135deg, #60a5fa, #3b82f6)';
      turnTitle.style.webkitBackgroundClip = 'text';
      turnSubtitle.textContent = gameMode === 'bot' ? 'บอทกำลังคิดและสุ่มของ...' : 'กดปุ่มเพื่อสุ่มของใช้ในบ้านมาต่อสู้!';
    }

    // Button Enabled / Disabled State
    if (isAnimating || winner) {
      btnRollGacha.disabled = true;
    } else if (gameMode === 'lan') {
      btnRollGacha.disabled = (currentTurn !== lanPlayerId);
      btnRollText.textContent = (currentTurn === lanPlayerId) ? 'สุ่มของโจมตี!' : 'รอคู่ต่อสู้สุ่มของ...';
    } else if (gameMode === 'bot') {
      btnRollGacha.disabled = (currentTurn !== 'cat');
      btnRollText.textContent = (currentTurn === 'cat') ? 'สุ่มของโจมตี!' : 'บอทกำลังสุ่ม...';
    } else {
      // Hotseat
      btnRollGacha.disabled = false;
      btnRollText.textContent = `สุ่มของ (${currentTurn === 'cat' ? cat.name : dog.name})`;
    }
  }

  // Append Combat Log
  function addCombatLog(text, isHighlight = false) {
    const entry = document.createElement('div');
    entry.className = `log-entry ${isHighlight ? 'highlight' : ''}`;
    entry.innerHTML = text;
    combatLogList.prepend(entry);
    if (combatLogList.children.length > 25) {
      combatLogList.removeChild(combatLogList.lastChild);
    }
  }

  // ------------------------------------------------------------------------
  // 2D Lucky Wheel Rendering & Animation
  // ------------------------------------------------------------------------
  let wheelCurrentAngle = 0; // Current rotation in radians

  function drawWheel(angle, highlightedIndex = -1, pulse = 0) {
    if (!wheelCtx || !wheelCanvas) return;
    const width = wheelCanvas.width;
    const height = wheelCanvas.height;
    const cx = width / 2;
    const cy = height / 2;
    const R = width / 2 - 10;
    const totalSlices = ITEMS.length; // 20
    const arc = (2 * Math.PI) / totalSlices;

    wheelCtx.clearRect(0, 0, width, height);

    // Save context for rotating the wheel
    wheelCtx.save();
    wheelCtx.translate(cx, cy);
    wheelCtx.rotate(angle);

    // Color palettes for alternating slices per tier
    const getSliceColor = (item, idx) => {
      if (item.tier === 'common') {
        return idx % 2 === 0 ? '#10b981' : '#059669';
      } else if (item.tier === 'uncommon') {
        return idx % 2 === 0 ? '#3b82f6' : '#2563eb';
      } else if (item.tier === 'rare') {
        return idx % 2 === 0 ? '#a855f7' : '#9333ea';
      } else { // legendary
        return idx % 2 === 0 ? '#f59e0b' : '#ea580c';
      }
    };

    // Draw all 20 slices
    for (let i = 0; i < totalSlices; i++) {
      const item = ITEMS[i];
      const startA = i * arc;
      const endA = (i + 1) * arc;

      // Slice wedge
      wheelCtx.beginPath();
      wheelCtx.moveTo(0, 0);
      wheelCtx.arc(0, 0, R, startA, endA);
      wheelCtx.closePath();
      wheelCtx.fillStyle = getSliceColor(item, i);
      wheelCtx.fill();

      // Divider line
      wheelCtx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
      wheelCtx.lineWidth = 1.5;
      wheelCtx.stroke();

      // Highlight winning slice
      if (i === highlightedIndex) {
        wheelCtx.fillStyle = `rgba(255, 255, 255, ${0.35 + 0.35 * Math.sin(pulse)})`;
        wheelCtx.fill();
        wheelCtx.strokeStyle = '#fef08a';
        wheelCtx.lineWidth = 3;
        wheelCtx.stroke();
      }

      // Draw Item Icon & Stat Badge
      wheelCtx.save();
      wheelCtx.rotate(startA + arc / 2);
      wheelCtx.textAlign = 'center';
      wheelCtx.textBaseline = 'middle';

      // Emoji Icon
      wheelCtx.font = '22px "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", sans-serif';
      wheelCtx.fillText(item.icon, R * 0.70, 0);

      // Stat Badge near rim
      wheelCtx.font = 'bold 9px "Kanit", sans-serif';
      wheelCtx.fillStyle = '#ffffff';
      wheelCtx.shadowColor = 'rgba(0, 0, 0, 0.9)';
      wheelCtx.shadowBlur = 3;
      let badge = '';
      if (item.type === 'attack') badge = `💥${item.damage}`;
      else if (item.type === 'heal') badge = `+${item.heal} HP`;
      else if (item.type === 'shield') badge = `+${item.shield}`;
      else if (item.type === 'hybrid') badge = `⭐ตำนาน`;
      wheelCtx.fillText(badge, R * 0.90, 0);

      wheelCtx.restore();
    }

    // Outer Bezel / Golden Rim
    wheelCtx.beginPath();
    wheelCtx.arc(0, 0, R - 1, 0, 2 * Math.PI);
    wheelCtx.lineWidth = 6;
    wheelCtx.strokeStyle = '#f59e0b';
    wheelCtx.stroke();

    // 20 Golden Studs / Rivets around the rim
    for (let i = 0; i < totalSlices; i++) {
      const studA = i * arc;
      const sx = (R - 3) * Math.cos(studA);
      const sy = (R - 3) * Math.sin(studA);
      wheelCtx.beginPath();
      wheelCtx.arc(sx, sy, 2.5, 0, 2 * Math.PI);
      wheelCtx.fillStyle = '#fef08a';
      wheelCtx.shadowColor = 'rgba(0,0,0,0.5)';
      wheelCtx.shadowBlur = 2;
      wheelCtx.fill();
    }

    wheelCtx.restore();
  }

  function playGachaSequence(gachaResult, onComplete) {
    const item = gachaResult.item;
    const tier = gachaResult.tier;

    // Find target index in ITEMS
    let targetIndex = ITEMS.findIndex(it => it.id === item.id);
    if (targetIndex === -1) targetIndex = 0;

    gachaOverlay.classList.remove('revealed');
    gachaOverlay.classList.add('active');
    wheelStage.style.display = 'flex';
    gachaCard.style.display = 'none';

    if (wheelActionHint) {
      wheelActionHint.textContent = '🎲 วงล้อกำลังหมุนเลือกของใช้...';
    }

    let hasCompleted = false;
    let autoTimer = null;
    let animFrameId = null;

    const finalize = () => {
      if (hasCompleted) return;
      hasCompleted = true;
      if (autoTimer) clearTimeout(autoTimer);
      if (animFrameId) cancelAnimationFrame(animFrameId);
      gachaOverlay.onclick = null;
      gachaOverlay.classList.remove('active');
      gachaOverlay.classList.remove('revealed');
      if (typeof onComplete === 'function') onComplete();
    };

    // Calculate rotation angle
    const totalSlices = ITEMS.length; // 20
    const arc = (2 * Math.PI) / totalSlices;
    const TWO_PI = 2 * Math.PI;

    // Top pointer is at -PI/2
    // For slice targetIndex center to land at -PI/2:
    // angle + (targetIndex + 0.5) * arc = -PI/2 (mod 2PI)
    const targetBase = -Math.PI / 2 - (targetIndex + 0.5) * arc;
    const normTarget = ((targetBase % TWO_PI) + TWO_PI) % TWO_PI;
    const normStart = ((wheelCurrentAngle % TWO_PI) + TWO_PI) % TWO_PI;

    let forwardDiff = normTarget - normStart;
    if (forwardDiff <= 0) forwardDiff += TWO_PI;

    // Spin 6 full revolutions + forward distance to reach target
    const fullSpins = 6 * TWO_PI;
    // Tiny organic jitter (+- 15% of slice)
    const jitter = (Math.random() - 0.5) * (arc * 0.3);
    const startAngle = wheelCurrentAngle;
    const finalAngle = wheelCurrentAngle + fullSpins + forwardDiff + jitter;

    const spinDuration = 2600; // 2.6 seconds
    const spinStartTime = performance.now();

    let lastTickSector = Math.floor((startAngle + Math.PI / 2) / arc);
    let lastTickAudioTime = 0;

    // Quartic ease-out for dramatic suspenseful deceleration
    const easeOutQuart = (t) => 1 - Math.pow(1 - t, 4);

    function revealFinalCard() {
      if (hasCompleted) return;
      wheelStage.style.display = 'none';
      gachaCard.style.display = 'flex';
      gachaCard.className = `gacha-card tier-${item.tier}`;

      gachaTierBadge.textContent = `${tier.name.split(' ')[0]} ${tier.rate}%`;
      gachaItemIcon.textContent = item.icon;
      gachaItemName.textContent = item.name;
      gachaItemDesc.textContent = item.desc;

      if (item.type === 'attack') {
        gachaItemStat.className = 'gacha-item-stat stat-attack';
        gachaItemStat.innerHTML = `💥 ดาเมจ ${item.damage}`;
      } else if (item.type === 'heal') {
        gachaItemStat.className = 'gacha-item-stat stat-heal';
        gachaItemStat.innerHTML = `❤️ ปั๊มเลือด +${item.heal} HP`;
      } else if (item.type === 'shield') {
        gachaItemStat.className = 'gacha-item-stat stat-shield';
        gachaItemStat.innerHTML = `🛡️ เพิ่มเกราะ +${item.shield}`;
      } else if (item.type === 'hybrid') {
        gachaItemStat.className = 'gacha-item-stat stat-hybrid';
        gachaItemStat.innerHTML = `🌟 +${item.heal} HP & +${item.shield} เกราะ`;
      }

      gachaOverlay.classList.add('revealed');

      // User tap or auto-proceed after 1.3s
      gachaOverlay.onclick = finalize;
      autoTimer = setTimeout(finalize, 1300);
    }

    // Tapping while spinning fast-forwards immediately to the card reveal
    gachaOverlay.onclick = () => {
      if (animFrameId) cancelAnimationFrame(animFrameId);
      wheelCurrentAngle = finalAngle;
      drawWheel(finalAngle, targetIndex);
      revealFinalCard();
    };

    function animateSpin(currentTime) {
      if (hasCompleted) return;
      const elapsed = currentTime - spinStartTime;
      const progress = Math.min(1, elapsed / spinDuration);
      const easedProgress = easeOutQuart(progress);

      const curAngle = startAngle + (finalAngle - startAngle) * easedProgress;
      wheelCurrentAngle = curAngle;

      // Check boundary crossings for pointer tick & sound
      const curTickSector = Math.floor((curAngle + Math.PI / 2) / arc);
      if (curTickSector !== lastTickSector) {
        lastTickSector = curTickSector;
        if (currentTime - lastTickAudioTime > 35) {
          sound.play('gacha_roll');
          lastTickAudioTime = currentTime;
        }
        if (wheelPointer) {
          wheelPointer.classList.add('tick');
          setTimeout(() => {
            if (wheelPointer) wheelPointer.classList.remove('tick');
          }, 50);
        }
      }

      drawWheel(curAngle);

      if (progress < 1) {
        animFrameId = requestAnimationFrame(animateSpin);
      } else {
        // Finished spinning! Land on exact item
        wheelCurrentAngle = finalAngle;
        drawWheel(finalAngle, targetIndex);

        if (wheelActionHint) {
          wheelActionHint.textContent = `🎯 ได้รับ: ${item.name}!`;
        }

        if (item.tier === 'legendary') {
          sound.play('legendary_buff');
          triggerScreenShake();
        } else {
          sound.play('gacha_reveal');
        }

        // Brief winning slice pulse before showing card
        const pulseStart = performance.now();
        function animateWinningSlice(pTime) {
          if (hasCompleted) return;
          const pElapsed = pTime - pulseStart;
          const pulse = pElapsed / 80;
          drawWheel(finalAngle, targetIndex, pulse);

          if (pElapsed < 380) {
            animFrameId = requestAnimationFrame(animateWinningSlice);
          } else {
            revealFinalCard();
          }
        }
        animFrameId = requestAnimationFrame(animateWinningSlice);
      }
    }

    animFrameId = requestAnimationFrame(animateSpin);
  }

  // ------------------------------------------------------------------------
  // Combat Action Animation (Arc Flying Projectile, Damage, Heals)
  // ------------------------------------------------------------------------
  function animateCombatAction(actionResult, onDone) {
    const isCatActor = actionResult.actorId === 'cat';
    const actorSprite = isCatActor ? catSprite : dogSprite;
    const targetSprite = isCatActor ? dogSprite : catSprite;
    const targetCardEl = isCatActor ? dogCard : catCard;
    const actorCardEl = isCatActor ? catCard : dogCard;
    const item = actionResult.item;

    addCombatLog(actionResult.logText, item.tier === 'legendary');

    // 1. Attack Animation: Arc Flying Projectile
    if (actionResult.type === 'attack') {
      actorSprite.className = isCatActor ? 'fighter-sprite attacking-left' : 'fighter-sprite attacking-right';
      sound.play(item.sfx || 'swoosh');

      const startRect = actorSprite.getBoundingClientRect();
      const targetRect = targetSprite.getBoundingClientRect();

      const projectile = document.createElement('div');
      projectile.className = `projectile ${isCatActor ? 'fly-left-to-right' : 'fly-right-to-left'}`;
      projectile.textContent = item.projectile || item.icon;
      projectile.style.setProperty('--startX', `${startRect.left + startRect.width / 4}px`);
      projectile.style.setProperty('--startY', `${startRect.top}px`);
      projectile.style.setProperty('--targetX', `${targetRect.left + targetRect.width / 4}px`);
      projectile.style.setProperty('--targetY', `${targetRect.top}px`);

      document.body.appendChild(projectile);

      // When projectile hits target
      setTimeout(() => {
        projectile.remove();
        actorSprite.className = 'fighter-sprite idle';

        // Impact FX
        const burst = document.createElement('div');
        burst.className = 'impact-burst';
        burst.style.left = `${targetRect.left + targetRect.width / 2}px`;
        burst.style.top = `${targetRect.top + targetRect.height / 2}px`;
        burst.style.background = (item.tier === 'legendary')
          ? 'radial-gradient(circle, rgba(239, 68, 68, 0.8), rgba(245, 158, 11, 0.4), transparent)'
          : 'radial-gradient(circle, rgba(255, 255, 255, 0.9), rgba(239, 68, 68, 0.4), transparent)';
        document.body.appendChild(burst);
        setTimeout(() => burst.remove(), 450);

        // Sound impact
        sound.play(item.sfx || 'hit');
        if (actionResult.armorBroken) {
          setTimeout(() => sound.play('shield_break'), 100);
        }
        if (actionResult.dmgDealt >= 20) {
          triggerScreenShake();
        }

        // Target reacts
        targetSprite.className = 'fighter-sprite hurt';
        setTimeout(() => { targetSprite.className = 'fighter-sprite idle'; }, 400);

        // Floating Damage Numbers
        if (actionResult.armorAbsorbed > 0) {
          spawnFloatingNumber(targetCardEl, `🛡️ -${actionResult.armorAbsorbed}`, 'shield');
        }
        if (actionResult.hpDamage > 0) {
          setTimeout(() => {
            spawnFloatingNumber(targetCardEl, `-${actionResult.hpDamage}`, 'damage');
          }, actionResult.armorAbsorbed > 0 ? 250 : 0);
        }

        finishAction();
      }, 650);
    }

    // 2. Heal Action
    else if (actionResult.type === 'heal') {
      actorSprite.className = 'fighter-sprite healing';
      sound.play('heal');
      spawnFloatingNumber(actorCardEl, `+${actionResult.healAmount} HP`, 'heal');
      setTimeout(() => {
        actorSprite.className = 'fighter-sprite idle';
        finishAction();
      }, 800);
    }

    // 3. Shield Action
    else if (actionResult.type === 'shield') {
      actorSprite.className = 'fighter-sprite healing';
      sound.play('shield');
      spawnFloatingNumber(actorCardEl, `+${actionResult.shieldAmount} เกราะ`, 'shield');
      setTimeout(() => {
        actorSprite.className = 'fighter-sprite idle';
        finishAction();
      }, 800);
    }

    // 4. Hybrid Action (Legendary)
    else if (actionResult.type === 'hybrid') {
      actorSprite.className = 'fighter-sprite healing';
      sound.play('legendary_buff');
      spawnFloatingNumber(actorCardEl, `+${actionResult.healAmount} HP`, 'heal');
      setTimeout(() => {
        spawnFloatingNumber(actorCardEl, `+${actionResult.shieldAmount} เกราะ`, 'shield');
      }, 300);
      triggerScreenShake();
      setTimeout(() => {
        actorSprite.className = 'fighter-sprite idle';
        finishAction();
      }, 1000);
    }

    function finishAction() {
      // Check Victory
      if (actionResult.isGameOver) {
        showVictoryScreen(actionResult.winner);
      }
      if (typeof onDone === 'function') onDone();
    }
  }

  // ------------------------------------------------------------------------
  // Victory Screen
  // ------------------------------------------------------------------------
  function showVictoryScreen(winnerId) {
    const isCat = winnerId === 'cat';
    const winnerName = isCat ? 'เจ้าเหมียวซ่า 🐱' : 'เจ้าตูบแสบ 🐶';
    const victoryAvatar = document.getElementById('victoryAvatar');
    const victoryTitle = document.getElementById('victoryTitle');
    const victoryDesc = document.getElementById('victoryDesc');
    const victoryStats = document.getElementById('victoryStats');

    victoryAvatar.textContent = isCat ? '🐱' : '🐶';
    victoryTitle.textContent = `${winnerName} ชนะเลิศ!`;
    victoryDesc.textContent = `เอาชนะการประลองสุ่มของปาใส่กันในรอบที่ ${localEngine.round}!`;

    const catStats = localEngine.players.cat;
    const dogStats = localEngine.players.dog;

    victoryStats.innerHTML = `
      <div><strong>สถิติการต่อสู้:</strong></div>
      <div>🐱 <strong>เหมียวซ่า:</strong> ทำดาเมจรวม ${catStats.totalDamageDealt} | ปั๊มเลือดรวม ${catStats.totalHealed} | เติมเกราะ ${catStats.totalShieldGained}</div>
      <div>🐶 <strong>ตูบแสบ:</strong> ทำดาเมจรวม ${dogStats.totalDamageDealt} | ปั๊มเลือดรวม ${dogStats.totalHealed} | เติมเกราะ ${dogStats.totalShieldGained}</div>
    `;

    if (gameMode === 'lan') {
      if (winnerId === lanPlayerId) sound.play('victory');
      else sound.play('defeat');
    } else if (gameMode === 'bot') {
      if (winnerId === 'cat') sound.play('victory');
      else sound.play('defeat');
    } else {
      sound.play('victory');
    }

    openModal(victoryModal);
  }

  // ------------------------------------------------------------------------
  // Turn Action Trigger (Button Click)
  // ------------------------------------------------------------------------
  btnRollGacha.addEventListener('click', () => {
    sound.ensureContext();
    if (isAnimating) return;

    // 1. LAN Mode
    if (gameMode === 'lan') {
      if (localEngine.currentTurn !== lanPlayerId) return;
      isAnimating = true;
      btnRollGacha.disabled = true;

      network.sendAction().catch(err => {
        isAnimating = false;
        showToast(err.message, '⚠️');
        updateHUD(localEngine.getState());
      });
      return;
    }

    // 2. Local Modes (Bot & Hotseat)
    isAnimating = true;
    btnRollGacha.disabled = true;

    const currentActor = localEngine.currentTurn;
    const gachaResult = rollGachaItem();

    playGachaSequence(gachaResult, () => {
      const actionResult = localEngine.executeAction(currentActor, gachaResult.item);
      actionResult.gacha = gachaResult;

      animateCombatAction(actionResult, () => {
        isAnimating = false;
        updateHUD(localEngine.getState());

        // If Bot's turn in Bot mode, trigger Bot AI
        if (gameMode === 'bot' && localEngine.currentTurn === 'dog' && !localEngine.winner) {
          triggerBotTurn();
        }
      });
    });
  });

  // Bot Turn Handler
  function triggerBotTurn() {
    isAnimating = true;
    updateHUD(localEngine.getState());

    botAI.takeTurn(localEngine,
      // onRollStart
      ({ taunt, botName }) => {
        showToast(taunt, '🐶');
      },
      // onActionExecute
      actionResult => {
        playGachaSequence(actionResult.gacha, () => {
          animateCombatAction(actionResult, () => {
            isAnimating = false;
            updateHUD(localEngine.getState());
          });
        });
      }
    );
  }

  // ------------------------------------------------------------------------
  // Rematch & Lobby Controls
  // ------------------------------------------------------------------------
  btnRematch.addEventListener('click', () => {
    sound.ensureContext();
    closeModal(victoryModal);

    if (gameMode === 'lan') {
      network.sendRestart().catch(e => showToast(e.message, '⚠️'));
    } else {
      localEngine.reset();
      updateHUD(localEngine.getState());
      addCombatLog('🔁 เริ่มต้นการประลองรอบใหม่!', true);
    }
  });

  btnBackToLobby.addEventListener('click', () => {
    closeModal(victoryModal);
    openModal(modeSelectModal);
  });

  // ------------------------------------------------------------------------
  // Game Mode Selection
  // ------------------------------------------------------------------------
  btnModeSelect.addEventListener('click', () => {
    openModal(modeSelectModal);
  });

  document.getElementById('btnSelectBot').addEventListener('click', () => {
    gameMode = 'bot';
    currentModeLabel.textContent = 'เล่นกับบอท (AI)';
    lanStatusBadge.style.display = 'none';
    closeModal(modeSelectModal);
    network.disconnect();

    localEngine.reset();
    document.getElementById('catName').textContent = 'เจ้าเหมียวซ่า (คุณ)';
    document.getElementById('dogName').textContent = 'เจ้าตูบแสบ (AI)';
    updateHUD(localEngine.getState());
    showToast('เข้าสู่โหมดเล่นคนเดียว VS บอท AI', '🤖');
  });

  document.getElementById('btnSelectHotseat').addEventListener('click', () => {
    gameMode = 'hotseat';
    currentModeLabel.textContent = 'เล่น 2 คน (Hotseat)';
    lanStatusBadge.style.display = 'none';
    closeModal(modeSelectModal);
    network.disconnect();

    localEngine.reset();
    document.getElementById('catName').textContent = 'เจ้าเหมียวซ่า (P1)';
    document.getElementById('dogName').textContent = 'เจ้าตูบแสบ (P2)';
    updateHUD(localEngine.getState());
    showToast('เข้าสู่โหมดเล่น 2 คนบนเครื่องเดียวกัน', '👥');
  });

  document.getElementById('btnSelectLan').addEventListener('click', async () => {
    closeModal(modeSelectModal);
    openModal(lanModal);
    await refreshLanInfoAndRooms();
  });

  btnEncyclopedia.addEventListener('click', () => {
    openModal(encyclopediaModal);
  });

  // ------------------------------------------------------------------------
  // LAN Multiplayer Features
  // ------------------------------------------------------------------------
  let currentRoomState = null;

  async function refreshLanInfoAndRooms() {
    try {
      const info = await network.getLanInfo();
      lanUrlInput.value = info.lanUrl;

      const rooms = await network.getRoomsList();
      activeRoomsList.innerHTML = '';

      if (rooms.length === 0) {
        activeRoomsList.innerHTML = '<div style="font-size:0.85rem; color:var(--text-muted); text-align:center; padding:12px;">ยังไม่มีห้องที่เปิดอยู่ กดสร้างห้องเพื่อเริ่มได้เลย!</div>';
      } else {
        rooms.forEach(r => {
          const item = document.createElement('div');
          item.style.display = 'flex';
          item.style.justifyContent = 'space-between';
          item.style.alignItems = 'center';
          item.style.background = 'rgba(15, 23, 42, 0.5)';
          item.style.padding = '8px 12px';
          item.style.borderRadius = 'var(--radius-sm)';
          item.style.border = '1px solid rgba(255,255,255,0.05)';

          item.innerHTML = `
            <div>
              <strong style="color:#f59e0b;">${r.code}</strong>
              <span style="font-size:0.8rem; color:var(--text-muted); margin-left:8px;">โฮสต์: ${r.hostName}</span>
              ${r.guestName ? `<span style="font-size:0.8rem; color:#60a5fa; margin-left:4px;">vs ${r.guestName}</span>` : ''}
            </div>
            <button class="btn btn-primary" style="padding:4px 10px; font-size:0.8rem;" ${r.playerCount >= 2 ? 'disabled' : ''}>
              ${r.playerCount >= 2 ? 'ห้องเต็ม' : 'เข้าร่วม'}
            </button>
          `;

          const joinBtn = item.querySelector('button');
          if (r.playerCount < 2) {
            joinBtn.addEventListener('click', () => {
              joinRoomByCode(r.code);
            });
          }

          activeRoomsList.appendChild(item);
        });
      }
    } catch (e) {
      console.warn(e);
    }
  }

  btnRefreshRooms.addEventListener('click', refreshLanInfoAndRooms);

  btnCopyLanUrl.addEventListener('click', () => {
    if (lanUrlInput.value) {
      navigator.clipboard.writeText(lanUrlInput.value).then(() => {
        showToast('คัดลอกที่อยู่ LAN เรียบร้อย ส่งให้เพื่อนได้เลย!', '📋');
      }).catch(() => {
        lanUrlInput.select();
        document.execCommand('copy');
        showToast('คัดลอกที่อยู่ LAN แล้ว!', '📋');
      });
    }
  });

  btnCopyRoomCode.addEventListener('click', () => {
    if (lanRoomCode) {
      navigator.clipboard.writeText(lanRoomCode).then(() => {
        showToast(`คัดลอกรหัสห้อง ${lanRoomCode} แล้ว!`, '📋');
      });
    }
  });

  btnCopyRoomLink.addEventListener('click', () => {
    const url = `${window.location.origin}/?room=${lanRoomCode}`;
    navigator.clipboard.writeText(url).then(() => {
      showToast('คัดลอกลิงก์ห้องให้เพื่อนเรียบร้อย!', '🔗');
    });
  });

  // Create LAN Room (Host)
  btnCreateRoom.addEventListener('click', async () => {
    sound.ensureContext();
    const hName = hostNameInput.value.trim() || 'เจ้าเหมียวซ่า';
    try {
      const data = await network.createRoom(hName);
      lanRoomCode = data.roomCode;
      lanPlayerId = data.assignedPlayerId; // 'cat'
      gameMode = 'lan';

      currentModeLabel.textContent = `วงแลน (${lanRoomCode})`;
      lanRoomCodeDisplay.textContent = lanRoomCode;
      lanStatusBadge.style.display = 'block';

      closeModal(lanModal);
      openModal(lanLobbyModal);

      setupNetworkListeners();
      updateLobbyUI(data.roomState);
      showToast(`สร้างห้อง ${lanRoomCode} เรียบร้อย!`, '🎉');
    } catch (e) {
      showToast(e.message, '⚠️');
    }
  });

  // Join LAN Room (Guest)
  function joinRoomByCode(code) {
    sound.ensureContext();
    const gName = guestNameInput.value.trim() || 'เจ้าตูบแสบ';
    network.joinRoom(code, gName).then(data => {
      lanRoomCode = data.roomCode;
      lanPlayerId = data.assignedPlayerId; // 'dog'
      gameMode = 'lan';

      currentModeLabel.textContent = `วงแลน (${lanRoomCode})`;
      lanRoomCodeDisplay.textContent = lanRoomCode;
      lanStatusBadge.style.display = 'block';

      closeModal(lanModal);
      openModal(lanLobbyModal);

      setupNetworkListeners();
      updateLobbyUI(data.roomState);
      showToast(`เข้าร่วมห้อง ${lanRoomCode} สำเร็จ!`, '🎮');
    }).catch(e => showToast(e.message, '⚠️'));
  }

  btnJoinRoom.addEventListener('click', () => {
    const code = joinRoomCodeInput.value.trim().toUpperCase();
    if (!code) {
      showToast('กรุณากรอกรหัสห้อง', '⚠️');
      return;
    }
    joinRoomByCode(code);
  });

  // Update Lobby UI with Room State
  function updateLobbyUI(roomState) {
    if (!roomState || !roomState.players) return;
    currentRoomState = roomState;
    const players = roomState.players;

    lobbyRoomBadge.textContent = lanRoomCode;

    // Cat (Host)
    lobbyCatName.textContent = players.cat.name + (lanPlayerId === 'cat' ? ' (คุณ)' : '');
    lobbyCatStatus.textContent = players.cat.connected ? '🟢 เชื่อมต่อแล้ว' : '⏳ รอเชื่อมต่อ';
    lobbyCatStatus.style.color = players.cat.connected ? '#4ade80' : 'var(--text-muted)';

    if (players.cat.ready) {
      lobbyCatCard.classList.add('is-ready');
      lobbyCatReadyBadge.className = 'ready-badge ready';
      lobbyCatReadyBadge.textContent = '✅ พร้อมแล้ว!';
    } else {
      lobbyCatCard.classList.remove('is-ready');
      lobbyCatReadyBadge.className = 'ready-badge not-ready';
      lobbyCatReadyBadge.textContent = '⏳ ยังไม่พร้อม';
    }

    if (lanPlayerId === 'cat') {
      btnCatToggleReady.disabled = false;
      btnCatReadyText.textContent = players.cat.ready ? 'ยกเลิกพร้อม' : 'กดพร้อมเล่น';
      btnCatToggleReady.className = players.cat.ready ? 'btn-toggle-ready ready' : 'btn-toggle-ready not-ready';
    } else {
      btnCatToggleReady.disabled = true;
      btnCatReadyText.textContent = 'สำหรับผู้เปิดห้อง';
      btnCatToggleReady.className = 'btn-toggle-ready ready';
    }

    // Dog (Guest)
    const dogConnected = players.dog.connected;
    lobbyDogName.textContent = (dogConnected ? players.dog.name : 'รอผู้เล่นเข้าร่วม...') + (lanPlayerId === 'dog' ? ' (คุณ)' : '');
    lobbyDogStatus.textContent = dogConnected ? '🟢 เชื่อมต่อแล้ว' : '⏳ กำลังรอเชื่อมต่อ...';
    lobbyDogStatus.style.color = dogConnected ? '#4ade80' : 'var(--text-muted)';

    if (players.dog.ready) {
      lobbyDogCard.classList.add('is-ready');
      lobbyDogReadyBadge.className = 'ready-badge ready';
      lobbyDogReadyBadge.textContent = '✅ พร้อมแล้ว!';
    } else {
      lobbyDogCard.classList.remove('is-ready');
      lobbyDogReadyBadge.className = 'ready-badge not-ready';
      lobbyDogReadyBadge.textContent = '⏳ ยังไม่พร้อม';
    }

    if (lanPlayerId === 'dog') {
      btnDogToggleReady.disabled = !dogConnected;
      btnDogReadyText.textContent = players.dog.ready ? 'ยกเลิกพร้อม' : 'กดพร้อมเล่น';
      btnDogToggleReady.className = players.dog.ready ? 'btn-toggle-ready ready' : 'btn-toggle-ready not-ready';
    } else {
      btnDogToggleReady.disabled = true;
      btnDogReadyText.textContent = dogConnected ? 'สำหรับผู้เข้าร่วม' : 'รอผู้เล่นเข้าร่วม';
      btnDogToggleReady.className = 'btn-toggle-ready ready';
    }

    const bothReady = (players.cat.ready && players.dog.ready);

    if (lanPlayerId === 'cat') {
      btnStartGame.disabled = !bothReady;
      if (bothReady) {
        btnStartGameText.textContent = '🎮 เริ่มเกมเลย! (ทั้ง 2 ฝ่ายพร้อมแล้ว)';
        lobbyStatusBanner.innerHTML = '🎉 ทั้งสองฝ่ายพร้อมแล้ว! ผู้เปิดห้องกด "เริ่มเกม!" ด้านล่างได้เลยค่ะ';
        lobbyStatusBanner.style.color = '#34d399';
      } else {
        btnStartGameText.textContent = 'เริ่มเกม! (ต้องพร้อมทั้ง 2 ฝ่าย)';
        lobbyStatusBanner.innerHTML = dogConnected
          ? '⏳ รอให้ผู้เล่นทั้งสองฝ่ายกด "กดพร้อมเล่น" ก่อนเริ่มเกมค่ะ'
          : '⏳ กำลังรอผู้เล่นอีก 1 คนเข้าร่วมห้อง...';
        lobbyStatusBanner.style.color = '#fbbf24';
      }
    } else {
      // Guest
      btnStartGame.disabled = true;
      if (bothReady) {
        btnStartGameText.textContent = '⏳ รอผู้เปิดห้องกดเริ่มเกม...';
        lobbyStatusBanner.innerHTML = '🎉 คุณและผู้เปิดห้องพร้อมแล้ว! รอผู้เปิดห้องกดเริ่มเกมค่ะ';
        lobbyStatusBanner.style.color = '#34d399';
      } else {
        btnStartGameText.textContent = 'เริ่มเกม! (ต้องพร้อมทั้ง 2 ฝ่าย)';
        lobbyStatusBanner.innerHTML = players.dog.ready
          ? '⏳ คุณพร้อมแล้ว รอผู้เปิดห้องกดพร้อม...'
          : '⏳ กรุณากด "กดพร้อมเล่น" เพื่อเตรียมตัวเข้าสู่การต่อสู้';
        lobbyStatusBanner.style.color = '#fbbf24';
      }
    }
  }

  // Ready Toggle Click Handlers
  btnCatToggleReady.addEventListener('click', () => {
    if (lanPlayerId !== 'cat' || !currentRoomState) return;
    sound.ensureContext();
    const nextState = !currentRoomState.players.cat.ready;
    network.setReady(nextState).then(() => {
      sound.play(nextState ? 'shield' : 'clink');
    }).catch(e => showToast(e.message, '⚠️'));
  });

  btnDogToggleReady.addEventListener('click', () => {
    if (lanPlayerId !== 'dog' || !currentRoomState) return;
    sound.ensureContext();
    const nextState = !currentRoomState.players.dog.ready;
    network.setReady(nextState).then(() => {
      sound.play(nextState ? 'shield' : 'clink');
    }).catch(e => showToast(e.message, '⚠️'));
  });

  // Start Game Button Click (Host)
  btnStartGame.addEventListener('click', () => {
    if (lanPlayerId !== 'cat') return;
    sound.ensureContext();
    network.startGame().catch(e => showToast(e.message, '⚠️'));
  });

  // Leave Room Button Click
  btnLeaveRoom.addEventListener('click', () => {
    sound.ensureContext();
    network.leaveRoom();
    closeModal(lanLobbyModal);
    gameMode = 'bot';
    currentModeLabel.textContent = 'เล่นกับบอท (AI)';
    lanStatusBadge.style.display = 'none';
    showToast('ออกจากห้องเรียบร้อย', '🚪');
  });

  // Setup SSE Listeners
  function setupNetworkListeners() {
    network.on('room_sync', data => {
      updateLobbyUI({ players: data.players, status: data.status });
      if (data.status === 'playing') {
        closeModal(lanLobbyModal);
        document.getElementById('catName').textContent = data.players.cat.name + (lanPlayerId === 'cat' ? ' (คุณ)' : '');
        document.getElementById('dogName').textContent = data.players.dog.name + (lanPlayerId === 'dog' ? ' (คุณ)' : '');
        localEngine.setState(data.battle);
        updateHUD(localEngine.getState());
      }
    });

    network.on('player_joined', data => {
      sound.play('gacha_reveal');
      showToast(`${data.playerName} เข้าร่วมห้องแล้ว!`, '🐾');
      updateLobbyUI(data.roomState);
    });

    network.on('status_change', data => {
      updateLobbyUI({ players: data.players, status: data.status });
    });

    network.on('ready_changed', data => {
      sound.play(data.ready ? 'shield' : 'clink');
      const p = data.players[data.playerId];
      showToast(`${p.name} ${data.ready ? '✅ พร้อมแล้ว!' : 'ยกเลิกพร้อม'}`, data.ready ? '👍' : '⏳');
      updateLobbyUI({ players: data.players });
    });

    network.on('game_started', data => {
      sound.play('victory');
      closeModal(lanLobbyModal);
      closeModal(lanModal);

      document.getElementById('catName').textContent = data.roomState.players.cat.name + (lanPlayerId === 'cat' ? ' (คุณ)' : '');
      document.getElementById('dogName').textContent = data.roomState.players.dog.name + (lanPlayerId === 'dog' ? ' (คุณ)' : '');
      localEngine.setState(data.roomState.battle);
      updateHUD(localEngine.getState());
      showToast('⚔️ การประลองเริ่มต้นขึ้นแล้ว! ทุกฝ่ายเข้าสู่สนามรบ!', '🐾');
    });

    network.on('turn_action', data => {
      const { actionResult, roomState } = data;
      localEngine.setState(roomState.battle);
      isAnimating = true;

      playGachaSequence(actionResult.gacha, () => {
        animateCombatAction(actionResult, () => {
          isAnimating = false;
          updateHUD(localEngine.getState());
        });
      });
    });

    network.on('match_restarted', data => {
      closeModal(victoryModal);
      localEngine.setState(data.roomState.battle);
      updateHUD(localEngine.getState());
      showToast('รีแมตช์! การประลองรอบใหม่เริ่มต้นขึ้นแล้ว!', '🔁');
    });

    network.on('player_left', data => {
      showToast('มีผู้เล่นออกจากห้อง', '🚪');
      if (currentRoomState) {
        currentRoomState.players = data.players;
        updateLobbyUI(currentRoomState);
      }
    });

    network.on('player_disconnected', data => {
      showToast('ผู้เล่นอีกคนหลุดจากการเชื่อมต่อ', '⚠️');
      if (currentRoomState) {
        currentRoomState.players = data.players;
        updateLobbyUI(currentRoomState);
      }
    });
  }

  // Initial HUD & 2D Wheel Render
  updateHUD(localEngine.getState());
  drawWheel(0);
});

