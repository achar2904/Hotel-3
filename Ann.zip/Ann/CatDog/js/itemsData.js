// ==========================================================================
// CatDog: Battle of Paws - Everyday Items & Gacha Data
// 20 Items: 50% (5 items), 25% (5 items), 15% (7 items), 10% (3 items)
// Damage scale 5 to 25 | HP Heal & Armor Shield Included
// ==========================================================================

const TIERS = {
  common: {
    id: 'common',
    name: 'ของใช้ทั่วไป (Common)',
    rate: 50,
    color: '#10b981',
    bgColor: 'rgba(16, 185, 129, 0.15)',
    border: '#059669',
    badge: 'ธรรมดา 50%'
  },
  uncommon: {
    id: 'uncommon',
    name: 'ของใช้หายาก (Uncommon)',
    rate: 25,
    color: '#3b82f6',
    bgColor: 'rgba(59, 130, 246, 0.15)',
    border: '#2563eb',
    badge: 'หายาก 25%'
  },
  rare: {
    id: 'rare',
    name: 'ของใช้ชั้นดี (Rare)',
    rate: 15,
    color: '#a855f7',
    bgColor: 'rgba(168, 85, 247, 0.15)',
    border: '#9333ea',
    badge: 'แรร์ 15%'
  },
  legendary: {
    id: 'legendary',
    name: 'ของใช้ในตำนาน (Legendary)',
    rate: 10,
    color: '#f59e0b',
    bgColor: 'rgba(245, 158, 11, 0.2)',
    border: '#d97706',
    badge: 'ตำนาน 10%'
  }
};

const ITEMS = [
  // --------------------------------------------------------------------------
  // TIER 1: เรท 50% (5 ชิ้น) - ดาเมจ 5-7, ปั๊มเลือด 8, เกราะ 8
  // --------------------------------------------------------------------------
  {
    id: 'toilet_paper',
    name: 'ม้วนกระดาษทิชชู่',
    enName: 'Toilet Paper Roll',
    icon: '🧻',
    tier: 'common',
    type: 'attack',
    damage: 5,
    heal: 0,
    shield: 0,
    desc: 'ปาม้วนทิชชู่ใส่หน้ากระจายฟุ้ง นุ่มนิ่มแต่แสบตา!',
    projectile: '🧻',
    sfx: 'swoosh'
  },
  {
    id: 'rubber_slipper',
    name: 'รองเท้าแตะช้างดาว',
    enName: 'Rubber Slipper',
    icon: '🩴',
    tier: 'common',
    type: 'attack',
    damage: 6,
    heal: 0,
    shield: 0,
    desc: 'อาวุธคู่บ้านระดับคลาสสิก ปาลอยละลิ่วเข้าเป้าแปะ!',
    projectile: '🩴',
    sfx: 'slap'
  },
  {
    id: 'metal_spoon',
    name: 'ช้อนแกงสแตนเลส',
    enName: 'Soup Spoon',
    icon: '🥄',
    tier: 'common',
    type: 'attack',
    damage: 7,
    heal: 0,
    shield: 0,
    desc: 'เคาะหัวเสียงดังโป๊กกิ๊ง มึนไปเสี้ยววินาที!',
    projectile: '🥄',
    sfx: 'clink'
  },
  {
    id: 'band_aid',
    name: 'พลาสเตอร์ยาแก้ฟกช้ำ',
    enName: 'First-Aid Bandage',
    icon: '🩹',
    tier: 'common',
    type: 'heal',
    damage: 0,
    heal: 8,
    shield: 0,
    desc: '[ปั๊มเลือด] แปะแผลห้ามเลือด ฟื้นฟูพลังชีวิต +8 HP!',
    projectile: '🩹',
    sfx: 'heal'
  },
  {
    id: 'pot_lid',
    name: 'ฝาหม้อกันกระแทก',
    enName: 'Cooking Pot Lid',
    icon: '🥘',
    tier: 'common',
    type: 'shield',
    damage: 0,
    heal: 0,
    shield: 8,
    desc: '[เพิ่มเกราะ] ยกฝาหม้อขึ้นมากันหน้า เพิ่มเกราะ +8!',
    projectile: '🛡️',
    sfx: 'shield'
  },

  // --------------------------------------------------------------------------
  // TIER 2: เรท 25% (5 ชิ้น) - ดาเมจ 10-12, ปั๊มเลือด 13, เกราะ 13
  // --------------------------------------------------------------------------
  {
    id: 'plunger',
    name: 'ไม้ปั๊มส้วมสูญญากาศ',
    enName: 'Toilet Plunger',
    icon: '🪠',
    tier: 'uncommon',
    type: 'attack',
    damage: 10,
    heal: 0,
    shield: 0,
    desc: 'ดูดติดหน้าปั๊บดังจ๊วบ ดึงออกแทบไม่ออก!',
    projectile: '🪠',
    sfx: 'pop'
  },
  {
    id: 'broom',
    name: 'ไม้กวาดดอกหญ้า',
    enName: 'Grass Broom',
    icon: '🧹',
    tier: 'uncommon',
    type: 'attack',
    damage: 11,
    heal: 0,
    shield: 0,
    desc: 'ฟาดกวาดสะบัดฝุ่นเข้าตา ฝุ่นตลบอบอวล!',
    projectile: '🧹',
    sfx: 'woosh'
  },
  {
    id: 'frying_pan',
    name: 'กระทะเทฟลอนทอดไข่',
    enName: 'Frying Pan',
    icon: '🍳',
    tier: 'uncommon',
    type: 'attack',
    damage: 12,
    heal: 0,
    shield: 0,
    desc: 'ตบหน้าดังเปรี้ยงสะท้าน สะเทือนถึงแก้วหู!',
    projectile: '🍳',
    sfx: 'bong'
  },
  {
    id: 'milk_carton',
    name: 'นมกล่องยูเอชที',
    enName: 'UHT Milk Carton',
    icon: '🥛',
    tier: 'uncommon',
    type: 'heal',
    damage: 0,
    heal: 13,
    shield: 0,
    desc: '[ปั๊มเลือด] ดื่มนมเสริมแคลเซียม กระดูกแข็งแรง ฟื้นฟู +13 HP!',
    projectile: '🥛',
    sfx: 'heal'
  },
  {
    id: 'cardboard_box',
    name: 'ลังกระดาษพัสดุ',
    enName: 'Delivery Box',
    icon: '📦',
    tier: 'uncommon',
    type: 'shield',
    damage: 0,
    heal: 0,
    shield: 13,
    desc: '[เพิ่มเกราะ] มุดเข้ากล่องพัสดุเป็นเกราะหนา เพิ่มเกราะ +13!',
    projectile: '📦',
    sfx: 'shield'
  },

  // --------------------------------------------------------------------------
  // TIER 3: เรท 15% (7 ชิ้น) - ดาเมจ 15-19, ปั๊มเลือด 18, เกราะ 18
  // --------------------------------------------------------------------------
  {
    id: 'steam_iron',
    name: 'เตารีดไอน้ำร้อนฉ่า',
    enName: 'Steam Iron',
    icon: '♨️',
    tier: 'rare',
    type: 'attack',
    damage: 15,
    heal: 0,
    shield: 0,
    desc: 'พ่นไอน้ำร้อนจี๊ด ลบรอยยับและสร้างความเจ็บปวด!',
    projectile: '♨️',
    sfx: 'steam'
  },
  {
    id: 'retro_radio',
    name: 'วิทยุทรานซิสเตอร์',
    enName: 'Retro Radio',
    icon: '📻',
    tier: 'rare',
    type: 'attack',
    damage: 16,
    heal: 0,
    shield: 0,
    desc: 'ปาวิทยุเปิดคลื่นเสียงความถี่สูง แสบสะท้านรูหู!',
    projectile: '📻',
    sfx: 'zap'
  },
  {
    id: 'cactus_pot',
    name: 'กระถางกระบองเพชร',
    enName: 'Cactus Pot',
    icon: '🌵',
    tier: 'rare',
    type: 'attack',
    damage: 17,
    heal: 0,
    shield: 0,
    desc: 'ปาพุ่มหนามแหลมทิ่มพรึ่บ ดึงหนามออกเจ็บกว่าเดิม!',
    projectile: '🌵',
    sfx: 'hit'
  },
  {
    id: 'fire_extinguisher',
    name: 'ถังดับเพลิงสีแดง',
    enName: 'Fire Extinguisher',
    icon: '🧯',
    tier: 'rare',
    type: 'attack',
    damage: 18,
    heal: 0,
    shield: 0,
    desc: 'ปลดสลักฉีดโฟมดับเพลิงขาวโพลนอัดเต็มอก!',
    projectile: '🧯',
    sfx: 'blast'
  },
  {
    id: 'heavy_iron_pot',
    name: 'หม้อหุงข้าวไฟฟ้าอุ่นทิพย์',
    enName: 'Electric Rice Cooker',
    icon: '🍲',
    tier: 'rare',
    type: 'attack',
    damage: 19,
    heal: 0,
    shield: 0,
    desc: 'ปาหม้อหุงข้าวเหล็กหนักแน่น ลอยกระแทกจังๆ!',
    projectile: '🍲',
    sfx: 'heavy_hit'
  },
  {
    id: 'energy_bento',
    name: 'ข้าวกล่องเบนโตะพรีเมียม',
    enName: 'Premium Bento Meal',
    icon: '🍱',
    tier: 'rare',
    type: 'heal',
    damage: 0,
    heal: 18,
    shield: 0,
    desc: '[ปั๊มเลือด] อาหารอร่อยครบ 5 หมู่ ฟื้นฟูพลังชีวิตอย่างแรง +18 HP!',
    projectile: '🍱',
    sfx: 'heal'
  },
  {
    id: 'trash_can_shield',
    name: 'ฝาถังขยะสแตนเลสหนา',
    enName: 'Metal Trash Lid Shield',
    icon: '🛡️',
    tier: 'rare',
    type: 'shield',
    damage: 0,
    heal: 0,
    shield: 18,
    desc: '[เพิ่มเกราะ] โล่เหล็กถังขยะกันกระสุน เพิ่มความหนาเกราะ +18!',
    projectile: '🛡️',
    sfx: 'shield'
  },

  // --------------------------------------------------------------------------
  // TIER 4: เรท 10% (3 ชิ้น) - ดาเมจ 22-25 / ไฮบริด ปั๊มเลือด + เกราะ 20
  // --------------------------------------------------------------------------
  {
    id: 'robot_vacuum',
    name: 'หุ่นยนต์ดูดฝุ่นติดเจ็ท',
    enName: 'Jet Robot Vacuum',
    icon: '🤖',
    tier: 'legendary',
    type: 'attack',
    damage: 22,
    heal: 0,
    shield: 0,
    desc: 'หุ่นยนต์ดูดฝุ่นคลั่ง พุ่งชนด้วยความเร็วสูงทะลวงเกราะ!',
    projectile: '🤖',
    sfx: 'rocket'
  },
  {
    id: 'king_durian',
    name: 'ทุเรียนหมอนทองหนามมรณะ',
    enName: 'Deadly King Durian',
    icon: '🍈',
    tier: 'legendary',
    type: 'attack',
    damage: 25,
    heal: 0,
    shield: 0,
    desc: 'ราชาผลไม้หนามเหล็กแหลมคม กลิ่นและหนามดาเมจสูงสุด 25!',
    projectile: '🍈',
    sfx: 'nuke'
  },
  {
    id: 'legendary_medkit',
    name: 'ตู้ยาและเกราะทองคำในบ้าน',
    enName: 'Home Mega Care & Armor',
    icon: '🏆',
    tier: 'legendary',
    type: 'hybrid',
    damage: 0,
    heal: 20,
    shield: 20,
    desc: '[ปั๊มเลือด + เสริมเกราะ] สุดยอดการฟื้นฟู! เพิ่มเลือด +20 HP และ เพิ่มเกราะ +20 ทันที!',
    projectile: '✨',
    sfx: 'legendary_buff'
  }
];

function rollGachaItem() {
  const rand = Math.random() * 100;
  let targetTier = 'common';

  if (rand < 50) {
    targetTier = 'common';       // 0 - 50 (50%)
  } else if (rand < 75) {
    targetTier = 'uncommon';     // 50 - 75 (25%)
  } else if (rand < 90) {
    targetTier = 'rare';         // 75 - 90 (15%)
  } else {
    targetTier = 'legendary';    // 90 - 100 (10%)
  }

  const pool = ITEMS.filter(item => item.tier === targetTier);
  const pickedItem = pool[Math.floor(Math.random() * pool.length)];

  return {
    item: pickedItem,
    tier: TIERS[targetTier],
    rollScore: parseFloat(rand.toFixed(2))
  };
}

function getItemById(id) {
  return ITEMS.find(item => item.id === id) || null;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { TIERS, ITEMS, rollGachaItem, getItemById };
}
