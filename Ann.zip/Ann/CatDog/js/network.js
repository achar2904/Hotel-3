// ==========================================================================
// CatDog: Battle of Paws - Network Client (LAN Multiplayer)
// Server-Sent Events (SSE) & REST API Integration
// Host/Guest names, Ready Check, and Game Start
// ==========================================================================

class NetworkManager {
  constructor() {
    this.eventSource = null;
    this.roomCode = null;
    this.myPlayerId = null; // 'cat' or 'dog'
    this.myPlayerName = '';
    this.lanInfo = null;
    this.callbacks = {};
  }

  on(event, callback) {
    this.callbacks[event] = callback;
  }

  emit(event, data) {
    if (this.callbacks[event]) {
      this.callbacks[event](data);
    }
  }

  // Fetch LAN IP info for sharing
  async getLanInfo() {
    try {
      const res = await fetch('/api/info');
      this.lanInfo = await res.json();
      return this.lanInfo;
    } catch (e) {
      console.warn('Could not fetch LAN info:', e);
      return { lanIp: window.location.hostname, port: window.location.port || '8081', lanUrl: window.location.origin };
    }
  }

  // List Active Rooms
  async getRoomsList() {
    try {
      const res = await fetch('/api/rooms');
      const data = await res.json();
      return data.rooms || [];
    } catch (e) {
      console.warn('Failed to fetch rooms list:', e);
      return [];
    }
  }

  // Create Room (Host creates room with hostName)
  async createRoom(hostName) {
    this.myPlayerName = (hostName || 'เจ้าเหมียวซ่า').trim();
    const res = await fetch('/api/room/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ hostName: this.myPlayerName })
    });
    const data = await res.json();
    if (!data.success) {
      throw new Error(data.error || 'สร้างห้องไม่สำเร็จ');
    }

    this.roomCode = data.roomCode;
    this.myPlayerId = data.assignedPlayerId; // 'cat'
    this.connectSSE(this.roomCode, this.myPlayerId);
    return data;
  }

  // Join Room (Guest joins room with guestName)
  async joinRoom(roomCode, guestName) {
    this.myPlayerName = (guestName || 'เจ้าตูบแสบ').trim();
    const res = await fetch('/api/room/join', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ roomCode, guestName: this.myPlayerName })
    });
    const data = await res.json();
    if (!data.success) {
      throw new Error(data.error || 'เข้าร่วมห้องไม่สำเร็จ');
    }

    this.roomCode = data.roomCode;
    this.myPlayerId = data.assignedPlayerId; // 'dog'
    this.connectSSE(this.roomCode, this.myPlayerId);
    return data;
  }

  // Connect to SSE Stream
  connectSSE(roomCode, playerId) {
    if (this.eventSource) {
      this.eventSource.close();
    }

    const url = `/api/room/${roomCode}/events?playerId=${playerId}`;
    this.eventSource = new EventSource(url);

    this.eventSource.addEventListener('room_sync', e => {
      const data = JSON.parse(e.data);
      this.emit('room_sync', data);
    });

    this.eventSource.addEventListener('player_joined', e => {
      const data = JSON.parse(e.data);
      this.emit('player_joined', data);
    });

    this.eventSource.addEventListener('status_change', e => {
      const data = JSON.parse(e.data);
      this.emit('status_change', data);
    });

    this.eventSource.addEventListener('ready_changed', e => {
      const data = JSON.parse(e.data);
      this.emit('ready_changed', data);
    });

    this.eventSource.addEventListener('game_started', e => {
      const data = JSON.parse(e.data);
      this.emit('game_started', data);
    });

    this.eventSource.addEventListener('turn_action', e => {
      const data = JSON.parse(e.data);
      this.emit('turn_action', data);
    });

    this.eventSource.addEventListener('match_restarted', e => {
      const data = JSON.parse(e.data);
      this.emit('match_restarted', data);
    });

    this.eventSource.addEventListener('player_left', e => {
      const data = JSON.parse(e.data);
      this.emit('player_left', data);
    });

    this.eventSource.addEventListener('player_disconnected', e => {
      const data = JSON.parse(e.data);
      this.emit('player_disconnected', data);
    });

    this.eventSource.onerror = err => {
      console.warn('SSE connection error:', err);
      this.emit('connection_error', err);
    };
  }

  // Toggle Ready Status
  async setReady(ready) {
    if (!this.roomCode || !this.myPlayerId) return;
    const res = await fetch(`/api/room/${this.roomCode}/ready`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ playerId: this.myPlayerId, ready })
    });
    const data = await res.json();
    if (!data.success) {
      throw new Error(data.error || 'เปลี่ยนสถานะพร้อมไม่สำเร็จ');
    }
    return data;
  }

  // Start Game (Host only)
  async startGame() {
    if (!this.roomCode || this.myPlayerId !== 'cat') return;
    const res = await fetch(`/api/room/${this.roomCode}/start`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ playerId: this.myPlayerId })
    });
    const data = await res.json();
    if (!data.success) {
      throw new Error(data.error || 'เริ่มเกมไม่สำเร็จ');
    }
    return data;
  }

  // Leave Room
  async leaveRoom() {
    if (!this.roomCode || !this.myPlayerId) return;
    try {
      await fetch(`/api/room/${this.roomCode}/leave`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ playerId: this.myPlayerId })
      });
    } catch (e) {
      console.warn('Leave room error:', e);
    }
    this.disconnect();
  }

  // Send Roll & Use Item Action
  async sendAction() {
    if (!this.roomCode || !this.myPlayerId) return;

    const res = await fetch(`/api/room/${this.roomCode}/action`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ playerId: this.myPlayerId })
    });

    const data = await res.json();
    if (!data.success) {
      throw new Error(data.error || 'ทำแอ็กชันไม่สำเร็จ');
    }
    return data.actionResult;
  }

  // Request Rematch
  async sendRestart() {
    if (!this.roomCode) return;
    const res = await fetch(`/api/room/${this.roomCode}/restart`, {
      method: 'POST'
    });
    return await res.json();
  }

  // Disconnect
  disconnect() {
    if (this.eventSource) {
      this.eventSource.close();
      this.eventSource = null;
    }
    this.roomCode = null;
    this.myPlayerId = null;
  }
}

const network = new NetworkManager();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { network, NetworkManager };
}
