// ==========================================================================
// CatDog: Battle of Paws - Core Game Logic
// Initial HP: 100 | Initial Armor: 25 | Max HP: 100 | Max Armor: 60
// Shield absorption & armor break mechanics
// ==========================================================================

const INITIAL_HP = 100;
const INITIAL_ARMOR = 25;
const MAX_HP = 100;
const MAX_ARMOR = 60;

class BattleEngine {
  constructor() {
    this.players = {
      cat: this.createPlayer('cat', 'เจ้าเหมียวซ่า', '🐱'),
      dog: this.createPlayer('dog', 'เจ้าตูบแสบ', '🐶')
    };
    this.currentTurn = 'cat';
    this.round = 1;
    this.winner = null;
    this.history = [];
  }

  createPlayer(id, name, avatar) {
    return {
      id,
      name,
      avatar,
      hp: INITIAL_HP,
      maxHp: MAX_HP,
      armor: INITIAL_ARMOR,
      maxArmor: MAX_ARMOR,
      totalDamageDealt: 0,
      totalDamageReceived: 0,
      totalHealed: 0,
      totalShieldGained: 0,
      itemsUsedCount: 0
    };
  }

  reset(startingPlayer = 'cat') {
    this.players.cat = this.createPlayer('cat', 'เจ้าเหมียวซ่า', '🐱');
    this.players.dog = this.createPlayer('dog', 'เจ้าตูบแสบ', '🐶');
    this.currentTurn = startingPlayer;
    this.round = 1;
    this.winner = null;
    this.history = [];
    return this.getState();
  }

  getState() {
    return {
      players: {
        cat: { ...this.players.cat },
        dog: { ...this.players.dog }
      },
      currentTurn: this.currentTurn,
      round: this.round,
      winner: this.winner,
      history: [...this.history]
    };
  }

  setState(state) {
    if (!state) return;
    this.players.cat = { ...state.players.cat };
    this.players.dog = { ...state.players.dog };
    this.currentTurn = state.currentTurn;
    this.round = state.round;
    this.winner = state.winner;
    this.history = [...(state.history || [])];
  }

  getOpponentId(playerId) {
    return playerId === 'cat' ? 'dog' : 'cat';
  }

  // Execute an item action by the active player
  executeAction(actorId, item) {
    if (this.winner) return null;
    if (actorId !== this.currentTurn) return null;

    const actor = this.players[actorId];
    const opponentId = this.getOpponentId(actorId);
    const target = this.players[opponentId];

    actor.itemsUsedCount++;

    let result = {
      actorId,
      actorName: actor.name,
      targetId: opponentId,
      targetName: target.name,
      item,
      type: item.type,
      dmgDealt: 0,
      armorAbsorbed: 0,
      hpDamage: 0,
      armorBroken: false,
      healAmount: 0,
      shieldAmount: 0,
      logText: '',
      isGameOver: false,
      winner: null
    };

    // 1. Attack action
    if (item.type === 'attack') {
      const damage = item.damage;
      result.dmgDealt = damage;
      actor.totalDamageDealt += damage;
      target.totalDamageReceived += damage;

      if (target.armor > 0) {
        if (target.armor >= damage) {
          result.armorAbsorbed = damage;
          result.hpDamage = 0;
          target.armor -= damage;
        } else {
          result.armorAbsorbed = target.armor;
          result.hpDamage = damage - target.armor;
          target.armor = 0;
          result.armorBroken = true;
          target.hp = Math.max(0, target.hp - result.hpDamage);
        }
      } else {
        result.armorAbsorbed = 0;
        result.hpDamage = damage;
        target.hp = Math.max(0, target.hp - damage);
      }

      if (result.armorAbsorbed > 0 && result.hpDamage > 0) {
        result.logText = `${actor.name} ใช้ ${item.icon} ${item.name} โจมตีใส่ ${target.name} (เกราะรับได้ ${result.armorAbsorbed}, ทะลวงเลือด ${result.hpDamage}!)`;
      } else if (result.armorAbsorbed > 0) {
        result.logText = `${actor.name} ใช้ ${item.icon} ${item.name} โจมตีใส่ ${target.name} (เกราะดูดซับดาเมจทั้งหมด ${result.armorAbsorbed}!)`;
      } else {
        result.logText = `${actor.name} ใช้ ${item.icon} ${item.name} โจมตีใส่ ${target.name} เต็มๆ ดาเมจ ${result.hpDamage}!`;
      }
    }

    // 2. Heal action (ปั๊มเลือด)
    else if (item.type === 'heal') {
      const oldHp = actor.hp;
      actor.hp = Math.min(actor.maxHp, actor.hp + item.heal);
      result.healAmount = actor.hp - oldHp;
      actor.totalHealed += result.healAmount;

      result.logText = `${actor.name} ใช้ ${item.icon} ${item.name} ปั๊มเลือดฟื้นฟูพลังชีวิต +${result.healAmount} HP! (เลือดรวม ${actor.hp}/${actor.maxHp})`;
    }

    // 3. Shield action (เสริมเกราะ)
    else if (item.type === 'shield') {
      const oldArmor = actor.armor;
      actor.armor = Math.min(actor.maxArmor, actor.armor + item.shield);
      result.shieldAmount = actor.armor - oldArmor;
      actor.totalShieldGained += result.shieldAmount;

      result.logText = `${actor.name} ใช้ ${item.icon} ${item.name} เสริมเกราะป้องกัน +${result.shieldAmount}! (เกราะรวม ${actor.armor}/${actor.maxArmor})`;
    }

    // 4. Hybrid action (ปั๊มเลือด + เสริมเกราะ ระดับตำนาน)
    else if (item.type === 'hybrid') {
      const oldHp = actor.hp;
      const oldArmor = actor.armor;
      actor.hp = Math.min(actor.maxHp, actor.hp + (item.heal || 0));
      actor.armor = Math.min(actor.maxArmor, actor.armor + (item.shield || 0));

      result.healAmount = actor.hp - oldHp;
      result.shieldAmount = actor.armor - oldArmor;
      actor.totalHealed += result.healAmount;
      actor.totalShieldGained += result.shieldAmount;

      result.logText = `🌟 ${actor.name} ปลดปล่อยไอเทมระดับตำนาน ${item.icon} ${item.name}! ปั๊มเลือด +${result.healAmount} HP และ เสริมเกราะ +${result.shieldAmount}!`;
    }

    // Check Victory
    if (target.hp <= 0) {
      target.hp = 0;
      this.winner = actorId;
      result.isGameOver = true;
      result.winner = actorId;
      result.logText += ` 🏆 ${actor.name} ชนะการประลองอย่างสมศักดิ์ศรี!`;
    } else {
      // Switch turn
      this.currentTurn = opponentId;
      if (this.currentTurn === 'cat') {
        this.round++;
      }
    }

    result.actorHp = actor.hp;
    result.actorArmor = actor.armor;
    result.targetHp = target.hp;
    result.targetArmor = target.armor;
    result.nextTurn = this.currentTurn;
    result.round = this.round;

    this.history.unshift(result);
    if (this.history.length > 30) {
      this.history.pop();
    }

    return result;
  }
}

// Export for Node.js and Browser
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    INITIAL_HP,
    INITIAL_ARMOR,
    MAX_HP,
    MAX_ARMOR,
    BattleEngine
  };
}
