// ==========================================================================
// CatDog: Battle of Paws - LAN Multiplayer Server
// Zero External Dependencies (Pure Node.js http, fs, os, path)
// Port 8081 | 0.0.0.0 | Server-Sent Events (SSE) Sync
// Host/Guest names, Ready Check, and Host Start Game
// ==========================================================================

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { rollGachaItem, getItemById, ITEMS, TIERS } = require('./js/itemsData');
const { BattleEngine } = require('./js/gameLogic');

const PORT = process.env.PORT || 8081;
const PUBLIC_DIR = __dirname;

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

// Rooms Map
const rooms = new Map();

// Helper: Get LAN IPv4 Address
function getLanIp() {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const net of interfaces[name]) {
      if (net.family === 'IPv4' && !net.internal && !net.address.startsWith('169.254')) {
        return net.address;
      }
    }
  }
  return '127.0.0.1';
}

// Generate friendly 4-letter room code
function generateRoomCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 4; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `PAW-${code}`;
}

// Read JSON Body
function readJson(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 1e6) {
        req.destroy();
        reject(new Error('Body too large'));
      }
    });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (err) {
        reject(err);
      }
    });
  });
}

// Send JSON Response
function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Cache-Control': 'no-cache'
  });
  res.end(JSON.stringify(data));
}

// Broadcast SSE Event to all clients in a room
function broadcastToRoom(room, eventName, data) {
  const payload = `event: ${eventName}\ndata: ${JSON.stringify(data)}\n\n`;
  room.clients.forEach(client => {
    try {
      client.res.write(payload);
    } catch (e) {
      console.warn('Failed to send SSE to a client:', e.message);
    }
  });
}

// Create Room Helper
function createRoom(hostName = 'เหมียวซ่า') {
  const roomCode = generateRoomCode();
  const engine = new BattleEngine();

  const room = {
    code: roomCode,
    createdAt: Date.now(),
    lastActivity: Date.now(),
    hostPlayerId: 'cat',
    players: {
      cat: { id: 'cat', name: hostName || 'เจ้าเหมียวซ่า', avatar: '🐱', connected: false, ready: false },
      dog: { id: 'dog', name: 'รอผู้เล่นเข้าร่วม...', avatar: '🐶', connected: false, ready: false }
    },
    engine,
    clients: [], // SSE connections
    status: 'lobby' // 'lobby', 'playing', 'finished'
  };

  rooms.set(roomCode, room);
  return room;
}

// HTTP Server
const server = http.createServer(async (req, res) => {
  // CORS Preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    });
    return res.end();
  }

  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = parsedUrl.pathname;

  // ========================================================================
  // API Routes
  // ========================================================================

  // 1. LAN Info
  if (pathname === '/api/info') {
    return sendJson(res, 200, {
      lanIp: getLanIp(),
      port: PORT,
      lanUrl: `http://${getLanIp()}:${PORT}`,
      activeRooms: rooms.size
    });
  }

  // 2. List Public Rooms
  if (pathname === '/api/rooms' && req.method === 'GET') {
    const list = [];
    rooms.forEach(r => {
      list.push({
        code: r.code,
        hostName: r.players.cat.name,
        guestName: r.players.dog.connected ? r.players.dog.name : null,
        playerCount: (r.players.cat.connected ? 1 : 0) + (r.players.dog.connected ? 1 : 0),
        status: r.status
      });
    });
    return sendJson(res, 200, { rooms: list });
  }

  // 3. Create Room (Host creates room)
  if (pathname === '/api/room/create' && req.method === 'POST') {
    try {
      const body = await readJson(req);
      const hostName = (body.hostName || body.playerName || 'เจ้าเหมียวซ่า').trim();
      const room = createRoom(hostName);
      return sendJson(res, 200, {
        success: true,
        roomCode: room.code,
        assignedPlayerId: 'cat',
        playerName: room.players.cat.name,
        roomState: {
          code: room.code,
          status: room.status,
          players: room.players,
          battle: room.engine.getState()
        }
      });
    } catch (err) {
      return sendJson(res, 400, { success: false, error: err.message });
    }
  }

  // 4. Join Room (Guest joins room)
  if (pathname === '/api/room/join' && req.method === 'POST') {
    try {
      const body = await readJson(req);
      const roomCode = (body.roomCode || '').toUpperCase().trim();
      const guestName = (body.guestName || body.playerName || 'เจ้าตูบแสบ').trim();
      const room = rooms.get(roomCode);

      if (!room) {
        return sendJson(res, 404, { success: false, error: 'ไม่พบห้องนี้ กรุณาตรวจสอบรหัสห้อง' });
      }

      let assignedPlayerId = 'dog';
      if (!room.players.cat.connected) {
        assignedPlayerId = 'cat';
        room.players.cat.name = guestName;
        room.players.cat.ready = false;
      } else if (!room.players.dog.connected) {
        assignedPlayerId = 'dog';
        room.players.dog.name = guestName;
        room.players.dog.ready = false;
      } else {
        return sendJson(res, 400, { success: false, error: 'ห้องนี้เต็มแล้ว (ครบ 2 คน)' });
      }

      room.lastActivity = Date.now();

      // Notify others in room
      broadcastToRoom(room, 'player_joined', {
        joinedPlayerId: assignedPlayerId,
        playerName: room.players[assignedPlayerId].name,
        roomState: {
          code: room.code,
          status: room.status,
          players: room.players,
          battle: room.engine.getState()
        }
      });

      return sendJson(res, 200, {
        success: true,
        roomCode: room.code,
        assignedPlayerId,
        playerName: room.players[assignedPlayerId].name,
        roomState: {
          code: room.code,
          status: room.status,
          players: room.players,
          battle: room.engine.getState()
        }
      });
    } catch (err) {
      return sendJson(res, 400, { success: false, error: err.message });
    }
  }

  // 5. Ready Check Toggle (Player ready status)
  const readyMatch = pathname.match(/^\/api\/room\/([A-Z0-9-]+)\/ready$/);
  if (readyMatch && req.method === 'POST') {
    try {
      const roomCode = readyMatch[1];
      const room = rooms.get(roomCode);
      if (!room) return sendJson(res, 404, { success: false, error: 'ไม่พบห้อง' });

      const body = await readJson(req);
      const playerId = body.playerId;
      if (!room.players[playerId]) return sendJson(res, 400, { success: false, error: 'ผู้เล่นไม่ถูกต้อง' });

      room.players[playerId].ready = !!body.ready;
      room.lastActivity = Date.now();

      const bothReady = (room.players.cat.ready && room.players.dog.ready);

      broadcastToRoom(room, 'ready_changed', {
        playerId,
        ready: room.players[playerId].ready,
        players: room.players,
        bothReady
      });

      return sendJson(res, 200, {
        success: true,
        playerId,
        ready: room.players[playerId].ready,
        players: room.players,
        bothReady
      });
    } catch (err) {
      return sendJson(res, 400, { success: false, error: err.message });
    }
  }

  // 6. Start Game (Host presses Start Game when both are ready)
  const startMatch = pathname.match(/^\/api\/room\/([A-Z0-9-]+)\/start$/);
  if (startMatch && req.method === 'POST') {
    try {
      const roomCode = startMatch[1];
      const room = rooms.get(roomCode);
      if (!room) return sendJson(res, 404, { success: false, error: 'ไม่พบห้อง' });

      const body = await readJson(req);
      if (body.playerId !== 'cat') {
        return sendJson(res, 403, { success: false, error: 'เฉพาะผู้เปิดห้อง (Host) เท่านั้นที่สามารถกดเริ่มเกมได้' });
      }

      if (!room.players.cat.ready || !room.players.dog.ready) {
        return sendJson(res, 400, { success: false, error: 'ผู้เล่นทั้ง 2 ฝ่ายต้องกดพร้อมก่อนเริ่มเกม' });
      }

      room.status = 'playing';
      room.engine.reset();
      room.engine.players.cat.name = room.players.cat.name;
      room.engine.players.dog.name = room.players.dog.name;
      room.lastActivity = Date.now();

      broadcastToRoom(room, 'game_started', {
        roomState: {
          code: room.code,
          status: room.status,
          players: room.players,
          battle: room.engine.getState()
        }
      });

      return sendJson(res, 200, { success: true });
    } catch (err) {
      return sendJson(res, 400, { success: false, error: err.message });
    }
  }

  // 7. Leave Room
  const leaveMatch = pathname.match(/^\/api\/room\/([A-Z0-9-]+)\/leave$/);
  if (leaveMatch && req.method === 'POST') {
    try {
      const roomCode = leaveMatch[1];
      const room = rooms.get(roomCode);
      if (!room) return sendJson(res, 404, { success: false, error: 'ไม่พบห้อง' });

      const body = await readJson(req);
      const playerId = body.playerId;
      if (room.players[playerId]) {
        room.players[playerId].connected = false;
        room.players[playerId].ready = false;
        if (playerId === 'dog') {
          room.players.dog.name = 'รอผู้เล่นเข้าร่วม...';
        }
      }

      broadcastToRoom(room, 'player_left', {
        playerId,
        players: room.players
      });

      return sendJson(res, 200, { success: true });
    } catch (err) {
      return sendJson(res, 400, { success: false, error: err.message });
    }
  }

  // 8. SSE Real-time Events Stream
  const sseMatch = pathname.match(/^\/api\/room\/([A-Z0-9-]+)\/events$/);
  if (sseMatch && req.method === 'GET') {
    const roomCode = sseMatch[1];
    const room = rooms.get(roomCode);

    if (!room) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      return res.end('Room not found');
    }

    const playerId = parsedUrl.searchParams.get('playerId') || 'cat';

    // Set SSE headers
    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*'
    });

    const client = { id: Date.now() + Math.random(), res, playerId };
    room.clients.push(client);

    if (room.players[playerId]) {
      room.players[playerId].connected = true;
    }

    // Send initial sync event
    const bothReady = (room.players.cat.connected && room.players.dog.connected &&
                       room.players.cat.ready && room.players.dog.ready);

    res.write(`event: room_sync\ndata: ${JSON.stringify({
      code: room.code,
      status: room.status,
      players: room.players,
      battle: room.engine.getState(),
      bothReady
    })}\n\n`);

    // Notify room of connected status
    broadcastToRoom(room, 'status_change', {
      status: room.status,
      players: room.players,
      bothReady
    });

    // Keep-alive heartbeat every 15s
    const heartbeat = setInterval(() => {
      try {
        res.write(': keepalive\n\n');
      } catch (e) {
        clearInterval(heartbeat);
      }
    }, 15000);

    // On client disconnect
    req.on('close', () => {
      clearInterval(heartbeat);
      room.clients = room.clients.filter(c => c !== client);
      if (room.players[playerId]) {
        room.players[playerId].connected = false;
        room.players[playerId].ready = false;
      }
      broadcastToRoom(room, 'player_disconnected', {
        playerId,
        players: room.players
      });

      if (room.clients.length === 0) {
        room.lastActivity = Date.now();
      }
    });

    return;
  }

  // 9. Action (Roll & Use Item)
  const actionMatch = pathname.match(/^\/api\/room\/([A-Z0-9-]+)\/action$/);
  if (actionMatch && req.method === 'POST') {
    try {
      const roomCode = actionMatch[1];
      const room = rooms.get(roomCode);
      if (!room) return sendJson(res, 404, { success: false, error: 'ไม่พบห้อง' });

      const body = await readJson(req);
      const actorId = body.playerId;

      if (room.status !== 'playing') {
        return sendJson(res, 400, { success: false, error: 'เกมยังไม่เริ่มต้น หรือจบลงแล้ว' });
      }

      if (room.engine.currentTurn !== actorId) {
        return sendJson(res, 400, { success: false, error: 'ยังไม่ถึงเทิร์นของคุณ' });
      }

      // Roll Gacha Item on Server
      const gachaResult = rollGachaItem();
      const rolledItem = gachaResult.item;

      // Execute Combat Action
      const actionResult = room.engine.executeAction(actorId, rolledItem);

      if (!actionResult) {
        return sendJson(res, 400, { success: false, error: 'ไม่สามารถทำแอ็กชันได้' });
      }

      actionResult.gacha = gachaResult;
      room.lastActivity = Date.now();

      if (actionResult.isGameOver) {
        room.status = 'finished';
      }

      // Broadcast Turn Action Result to both players
      broadcastToRoom(room, 'turn_action', {
        actionResult,
        roomState: {
          code: room.code,
          status: room.status,
          players: room.players,
          battle: room.engine.getState()
        }
      });

      return sendJson(res, 200, { success: true, actionResult });
    } catch (err) {
      return sendJson(res, 400, { success: false, error: err.message });
    }
  }

  // 10. Restart Match (Rematch)
  const restartMatch = pathname.match(/^\/api\/room\/([A-Z0-9-]+)\/restart$/);
  if (restartMatch && req.method === 'POST') {
    try {
      const roomCode = restartMatch[1];
      const room = rooms.get(roomCode);
      if (!room) return sendJson(res, 404, { success: false, error: 'ไม่พบห้อง' });

      room.engine.reset();
      room.engine.players.cat.name = room.players.cat.name;
      room.engine.players.dog.name = room.players.dog.name;
      room.status = 'playing';
      room.lastActivity = Date.now();

      broadcastToRoom(room, 'match_restarted', {
        roomState: {
          code: room.code,
          status: room.status,
          players: room.players,
          battle: room.engine.getState()
        }
      });

      return sendJson(res, 200, { success: true });
    } catch (err) {
      return sendJson(res, 400, { success: false, error: err.message });
    }
  }

  // ========================================================================
  // Static Files Server
  // ========================================================================
  let filePath = path.join(PUBLIC_DIR, pathname === '/' ? 'index.html' : pathname);

  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403, { 'Content-Type': 'text/plain' });
    return res.end('Access Denied');
  }

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('404 Not Found - CatDog Arena');
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    res.writeHead(200, {
      'Content-Type': contentType,
      'Cache-Control': 'no-cache'
    });

    const stream = fs.createReadStream(filePath);
    stream.pipe(res);
  });
});

// Periodic cleanup of stale rooms (> 1 hour inactive)
setInterval(() => {
  const now = Date.now();
  rooms.forEach((room, code) => {
    if (now - room.lastActivity > 3600000 && room.clients.length === 0) {
      rooms.delete(code);
      console.log(`Cleaned up stale room: ${code}`);
    }
  });
}, 300000);

// Start Server
server.listen(PORT, '0.0.0.0', () => {
  const lanIp = getLanIp();
  console.log('====================================================');
  console.log('🐾 CatDog: Battle of Paws - Server Online! 🐾');
  console.log('====================================================');
  console.log(`📡 Local Access : http://localhost:${PORT}`);
  console.log(`🌐 LAN Network  : http://${lanIp}:${PORT}`);
  console.log('====================================================');
});
