// ==========================================================================
// Chill Island Board Game - Local & Online Multiplayer Server
// Zero External Dependencies (Pure Node.js http, fs, os, path)
// ==========================================================================

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');

const PORT = process.env.PORT || 8080;
const PUBLIC_DIR = __dirname;

// MIME types dictionary
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.wav': 'audio/wav',
  '.mp3': 'audio/mpeg'
};

// In-Memory Online Multiplayer Rooms
const rooms = new Map();

// Helper to get local network IP
function getNetworkIp() {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const net of interfaces[name]) {
      if (net.family === 'IPv4' && !net.internal && !net.address.startsWith('169.254')) {
        return net.address;
      }
    }
  }
  return '127.0.0.1';
}

// Generate friendly 4-digit room code
function generateRoomCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 4; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `CHILL-${code}`;
}

// Read JSON request body helper
function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
      if (body.length > 1e6) {
        req.connection.destroy();
        reject(new Error('Payload too large'));
      }
    });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (err) {
        reject(err);
      }
    });
  });
}

// Broadcast SSE message to all clients in a room
function broadcastToRoom(roomId, eventName, data, excludePlayerId = null) {
  const room = rooms.get(roomId);
  if (!room) return;

  const payload = `event: ${eventName}\ndata: ${JSON.stringify(data)}\n\n`;
  room.clients.forEach(client => {
    if (excludePlayerId === null || client.playerId !== excludePlayerId) {
      try {
        client.res.write(payload);
      } catch (e) {
        // Disconnected
      }
    }
  });
}

// Cleanup inactive rooms (> 3 hours)
setInterval(() => {
  const now = Date.now();
  for (const [roomId, room] of rooms.entries()) {
    if (now - room.lastActive > 3 * 60 * 60 * 1000) {
      rooms.delete(roomId);
    }
  }
}, 10 * 60 * 1000);

const server = http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const reqUrl = new URL(req.url, `http://${req.headers.host}`);
  const pathname = reqUrl.pathname;

  // Status Info
  if (pathname === '/api/info') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      status: 'online',
      localIp: getNetworkIp(),
      port: PORT,
      activeRooms: rooms.size
    }));
    return;
  }

  // Create Room
  if (pathname === '/api/room/create' && req.method === 'POST') {
    try {
      const data = await readJsonBody(req);
      const roomId = generateRoomCode();
      const hostPlayer = {
        id: 0,
        name: data.name || 'คุณเอก',
        avatar: data.avatar || '🐱',
        color: '#0284c7',
        isHost: true
      };

      rooms.set(roomId, {
        roomId,
        players: [hostPlayer],
        clients: [],
        gameState: null,
        lastActive: Date.now()
      });

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: true,
        roomId,
        player: hostPlayer
      }));
    } catch (err) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: err.message }));
    }
    return;
  }

  // Join Room
  if (pathname === '/api/room/join' && req.method === 'POST') {
    try {
      const data = await readJsonBody(req);
      const roomId = (data.roomId || '').toUpperCase().trim();
      const room = rooms.get(roomId);

      if (!room) {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'ไม่พบห้องที่ระบุ กรุณาตรวจสอบรหัสห้องอีกครั้ง' }));
        return;
      }

      if (room.players.length >= 4) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'ห้องนี้มีผู้เล่นเต็มแล้ว (สูงสุด 4 คน)' }));
        return;
      }

      const colors = ['#0284c7', '#d97706', '#059669', '#7c3aed'];
      const playerIndex = room.players.length;
      const newPlayer = {
        id: playerIndex,
        name: data.name || `เพื่อนร่วมเกาะ ${playerIndex + 1}`,
        avatar: data.avatar || (playerIndex === 1 ? '🦊' : playerIndex === 2 ? '🐶' : '🐼'),
        color: colors[playerIndex % colors.length],
        isHost: false
      };

      room.players.push(newPlayer);
      room.lastActive = Date.now();

      broadcastToRoom(roomId, 'player_joined', {
        player: newPlayer,
        allPlayers: room.players
      });

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: true,
        roomId,
        player: newPlayer,
        allPlayers: room.players
      }));
    } catch (err) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: err.message }));
    }
    return;
  }

  // Room Info
  if (pathname === '/api/room/info' && req.method === 'GET') {
    const roomId = (reqUrl.searchParams.get('roomId') || '').toUpperCase();
    const room = rooms.get(roomId);
    if (!room) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'ไม่พบห้องนี้' }));
      return;
    }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      roomId: room.roomId,
      players: room.players,
      hasStarted: !!room.gameState
    }));
    return;
  }

  // SSE Stream for Real-time event updates
  if (pathname === '/api/room/stream' && req.method === 'GET') {
    const roomId = (reqUrl.searchParams.get('roomId') || '').toUpperCase();
    const playerId = parseInt(reqUrl.searchParams.get('playerId'), 10);
    const room = rooms.get(roomId);

    if (!room) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Room not found');
      return;
    }

    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive',
      'X-Accel-Buffering': 'no'
    });

    const clientObj = { playerId, res };
    room.clients.push(clientObj);

    res.write(`event: connected\ndata: ${JSON.stringify({ roomId, players: room.players })}\n\n`);

    const pingInterval = setInterval(() => {
      res.write(': ping\n\n');
    }, 15000);

    req.on('close', () => {
      clearInterval(pingInterval);
      const idx = room.clients.indexOf(clientObj);
      if (idx !== -1) room.clients.splice(idx, 1);
    });
    return;
  }

  // Action Dispatcher (Sync turns, rolls, purchases, takeovers, and chat)
  if (pathname === '/api/room/action' && req.method === 'POST') {
    try {
      const data = await readJsonBody(req);
      const roomId = (data.roomId || '').toUpperCase();
      const room = rooms.get(roomId);

      if (!room) {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'ไม่พบห้องนี้' }));
        return;
      }

      room.lastActive = Date.now();

      if (data.action && data.action.type === 'START_GAME') {
        room.gameState = data.action.state;
      }

      broadcastToRoom(roomId, 'game_action', {
        fromPlayerId: data.playerId,
        action: data.action
      });

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true }));
    } catch (err) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: err.message }));
    }
    return;
  }

  // Static File Serving
  let sanitizedPath = path.normalize(pathname).replace(/^(\.\.[\/\\])+/, '');
  if (sanitizedPath === '/' || sanitizedPath === '\\') {
    sanitizedPath = '/index.html';
  }

  const filePath = path.join(PUBLIC_DIR, sanitizedPath);

  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403, { 'Content-Type': 'text/plain' });
    res.end('403 Forbidden');
    return;
  }

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end('<h1>404 Not Found</h1><p>ไม่พบหน้าที่เรียก กรุณากลับสู่หน้าหลัก</p>');
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    res.writeHead(200, {
      'Content-Type': contentType,
      'Cache-Control': 'no-cache'
    });

    const stream = fs.createReadStream(filePath);
    stream.pipe(res);
  });
});

server.listen(PORT, '0.0.0.0', () => {
  const localIp = getNetworkIp();
  console.log('====================================================');
  console.log('🏝️  ชิวโพลี: เซิร์ฟเวอร์เกมกระดานออนไลน์เริ่มทำงานแล้ว!');
  console.log('====================================================');
  console.log(`👉 เครื่องนี้ (Localhost): http://localhost:${PORT}`);
  console.log(`👉 อุปกรณ์อื่นใน Wi-Fi:   http://${localIp}:${PORT}`);
  console.log('====================================================');
});
