// ==========================================================================
// Chill Island Board Data - Tiles, Groups, Cards, and Events
// ==========================================================================

const COLOR_GROUPS = {
  cafe: {
    id: 'cafe',
    name: 'โซนคาเฟ่อบอุ่น',
    color: '#d97706',
    badgeBg: '#fef3c7',
    badgeText: '#92400e',
    icon: '☕'
  },
  beach: {
    id: 'beach',
    name: 'โซนชายหาดชิวๆ',
    color: '#0284c7',
    badgeBg: '#e0f2fe',
    badgeText: '#0369a1',
    icon: '🏖️'
  },
  nature: {
    id: 'nature',
    name: 'โซนธรรมชาติบริสุทธิ์',
    color: '#059669',
    badgeBg: '#d1fae5',
    badgeText: '#065f46',
    icon: '🌲'
  },
  resort: {
    id: 'resort',
    name: 'โซนรีสอร์ตหรูหรา',
    color: '#7c3aed',
    badgeBg: '#ede9fe',
    badgeText: '#5b21b6',
    icon: '✨'
  },
  wonders: {
    id: 'wonders',
    name: '🌟 8 สิ่งมหัศจรรย์แห่งเกาะ (ครอบครองครบชนะทันที!)',
    color: '#f59e0b',
    badgeBg: '#fef3c7',
    badgeText: '#92400e',
    icon: '👑'
  }
};

const BOARD_TILES = [
  // Top Row (0 to 8, left to right)
  {
    id: 0,
    row: 0,
    col: 0,
    type: 'start',
    name: 'ท่าเรือชิวๆ (Start)',
    subtitle: 'รับงบพักผ่อน 2,000 เหรียญ',
    icon: '🚢',
    desc: 'จุดเริ่มต้นการพักผ่อน ทุกครั้งที่เดินผ่านหรือลงช่องนี้จะได้รับเงิน 2,000 เหรียญ'
  },
  {
    id: 1,
    row: 0,
    col: 1,
    type: 'property',
    name: 'กาแฟ Slow Bar',
    group: 'cafe',
    icon: '☕',
    price: 600,
    baseRent: 150,
    rentLv2: 380,
    rentLv3: 850,
    upgradeCost: 400,
    desc: 'ร้านกาแฟดริปแบบช้าๆ หอมกรุ่นด้วยเมล็ดกาแฟคั่วสด'
  },
  {
    id: 2,
    row: 0,
    col: 2,
    type: 'property',
    isWonder: true,
    name: 'ศาลเจ้าโบราณ',
    group: 'wonders',
    icon: '⛩️',
    price: 1500,
    baseRent: 400,
    desc: 'สิ่งมหัศจรรย์แห่งเกาะ สร้างได้แค่ครั้งเดียว หากสะสมครบ 8 แห่งชนะทันที!'
  },
  {
    id: 3,
    row: 0,
    col: 3,
    type: 'card',
    name: 'การ์ดลมหายใจเกาะ',
    subtitle: 'เปิดรับดวงชิวๆ',
    icon: '💌',
    desc: 'จั่วการ์ดสุ่มโชคชะตาสุดปั่นและอบอุ่นใจ'
  },
  {
    id: 4,
    row: 0,
    col: 4,
    type: 'property',
    name: 'เบเกอรี่อบอุ่น',
    group: 'cafe',
    icon: '🥐',
    price: 800,
    baseRent: 200,
    rentLv2: 500,
    rentLv3: 1100,
    upgradeCost: 500,
    desc: 'ครัวซองต์เนยฝรั่งเศสสดใหม่จากเตาทุกเช้า'
  },
  {
    id: 5,
    row: 0,
    col: 5,
    type: 'property',
    isWonder: true,
    name: 'รูปปั้นโมอายริมผา',
    group: 'wonders',
    icon: '🗿',
    price: 1600,
    baseRent: 420,
    desc: 'สิ่งมหัศจรรย์แห่งเกาะ สร้างได้แค่ครั้งเดียว หากสะสมครบ 8 แห่งชนะทันที!'
  },
  {
    id: 6,
    row: 0,
    col: 6,
    type: 'property',
    name: 'สวนดอกไม้ลอยฟ้า',
    group: 'cafe',
    icon: '🌸',
    price: 1000,
    baseRent: 250,
    rentLv2: 650,
    rentLv3: 1400,
    upgradeCost: 600,
    desc: 'จุดจิบชาชมวิวทุ่งดอกไม้หลากสีสันสุดตระการตา'
  },
  {
    id: 7,
    row: 0,
    col: 7,
    type: 'minigame',
    name: 'ตู้สุ่มกาชาปอง',
    subtitle: 'ลุ้นรางวัล/ระวังโจร!',
    icon: '🎁',
    desc: 'หมุนกาชาปองนำโชค ลุ้นรับของรางวัล แต่ระวังโจรฉกเงินและหนี้สิน!'
  },
  {
    id: 8,
    row: 0,
    col: 8,
    type: 'rest',
    name: 'วิลล่านอนเพลิน',
    subtitle: 'พักผ่อน 1 เทิร์น',
    icon: '🛏️',
    desc: 'เตียงนุ่มจนลุกไม่ขึ้น! ต้องพักผ่อน 1 เทิร์น หรือจ่ายค่ากาแฟปลุก 300 เหรียญ'
  },

  // Right Column (9 to 15, top to bottom)
  {
    id: 9,
    row: 1,
    col: 8,
    type: 'property',
    name: 'คาเฟ่แมวเหมียว',
    group: 'beach',
    icon: '🐱',
    price: 1200,
    baseRent: 300,
    rentLv2: 780,
    rentLv3: 1650,
    upgradeCost: 700,
    desc: 'ฮีลใจไปกับเหล่าน้องแมวขี้อ้อนริมหาดทรายขาว'
  },
  {
    id: 10,
    row: 2,
    col: 8,
    type: 'property',
    isWonder: true,
    name: 'ถ้ำคริสตัลเรืองแสง',
    group: 'wonders',
    icon: '💎',
    price: 1700,
    baseRent: 450,
    desc: 'สิ่งมหัศจรรย์แห่งเกาะ สร้างได้แค่ครั้งเดียว หากสะสมครบ 8 แห่งชนะทันที!'
  },
  {
    id: 11,
    row: 3,
    col: 8,
    type: 'card',
    name: 'การ์ดลมหายใจเกาะ',
    subtitle: 'เปิดรับดวงชิวๆ',
    icon: '💌',
    desc: 'จั่วการ์ดสุ่มโชคชะตาสุดปั่นและอบอุ่นใจ'
  },
  {
    id: 12,
    row: 4,
    col: 8,
    type: 'property',
    name: 'บาร์ค็อกเทลริมหาด',
    group: 'beach',
    icon: '🍹',
    price: 1400,
    baseRent: 350,
    rentLv2: 900,
    rentLv3: 1900,
    upgradeCost: 800,
    desc: 'ดื่มด่ำกับม็อกเทลผลไม้สดและเสียงคลื่นซัดสาด'
  },
  {
    id: 13,
    row: 5,
    col: 8,
    type: 'property',
    isWonder: true,
    name: 'ต้นไม้ศักดิ์สิทธิ์พันปี',
    group: 'wonders',
    icon: '🌲',
    price: 1800,
    baseRent: 480,
    desc: 'สิ่งมหัศจรรย์แห่งเกาะ สร้างได้แค่ครั้งเดียว หากสะสมครบ 8 แห่งชนะทันที!'
  },
  {
    id: 14,
    row: 6,
    col: 8,
    type: 'property',
    name: 'ร้านหนังสือโบราณ',
    group: 'beach',
    icon: '📚',
    price: 1600,
    baseRent: 400,
    rentLv2: 1050,
    rentLv3: 2200,
    upgradeCost: 900,
    desc: 'ขุมทรัพย์วรรณกรรมคลาสสิกและมุมอ่านหนังสือใต้ร่มไม้'
  },
  {
    id: 15,
    row: 7,
    col: 8,
    type: 'transit',
    name: 'ท่าสปีดโบ๊ทวาร์ป',
    subtitle: 'ข้ามไปอีกฟากเกาะ',
    icon: '🚤',
    targetTile: 31,
    desc: 'นั่งเรือสปีดโบ๊ทลัดฟ้าไปยังทางลัดจักรยานฝั่งตรงข้ามทันที!'
  },

  // Bottom Row (16 to 24, right to left)
  {
    id: 16,
    row: 8,
    col: 8,
    type: 'oasis',
    name: 'สวนสมาธิเซน',
    subtitle: 'รับฟรี 500 เหรียญ',
    icon: '🧘',
    desc: 'นั่งสมาธิใต้ต้นไผ่ จิตใจผ่องใส รับพลังบวก 500 เหรียญฟรี!'
  },
  {
    id: 17,
    row: 8,
    col: 7,
    type: 'property',
    name: 'สวนผลไม้ออร์แกนิก',
    group: 'nature',
    icon: '🍓',
    price: 1800,
    baseRent: 450,
    rentLv2: 1180,
    rentLv3: 2450,
    upgradeCost: 1000,
    desc: 'เก็บสตรอว์เบอร์รีและอะโวคาโดสดๆ จากต้นปลอดสารพิษ'
  },
  {
    id: 18,
    row: 8,
    col: 6,
    type: 'property',
    isWonder: true,
    name: 'หอประภาคารแห่งความหวัง',
    group: 'wonders',
    icon: '🏛️',
    price: 1900,
    baseRent: 500,
    desc: 'สิ่งมหัศจรรย์แห่งเกาะ สร้างได้แค่ครั้งเดียว หากสะสมครบ 8 แห่งชนะทันที!'
  },
  {
    id: 19,
    row: 8,
    col: 5,
    type: 'minigame',
    name: 'วงล้อเสี่ยงทาย',
    subtitle: 'หมุนวงล้อลุ้นโชค',
    icon: '🎡',
    desc: 'หมุนวงล้อมหาสนุก ลุ้นรับโบนัสเงินรางวัล หรือระวังติดหนี้และโจรขโมยเงิน!'
  },
  {
    id: 20,
    row: 8,
    col: 4,
    type: 'property',
    name: 'ออนเซ็นกลางหุบเขา',
    group: 'nature',
    icon: '♨️',
    price: 2000,
    baseRent: 500,
    rentLv2: 1300,
    rentLv3: 2700,
    upgradeCost: 1100,
    desc: 'แช่น้ำแร่ธรรมชาติคลายความเมื่อยล้าท่ามกลางขุนเขา'
  },
  {
    id: 21,
    row: 8,
    col: 3,
    type: 'property',
    isWonder: true,
    name: 'น้ำพุแห่งความเยาว์วัย',
    group: 'wonders',
    icon: '⛲',
    price: 2000,
    baseRent: 520,
    desc: 'สิ่งมหัศจรรย์แห่งเกาะ สร้างได้แค่ครั้งเดียว หากสะสมครบ 8 แห่งชนะทันที!'
  },
  {
    id: 22,
    row: 8,
    col: 2,
    type: 'card',
    name: 'การ์ดลมหายใจเกาะ',
    subtitle: 'เปิดรับดวงชิวๆ',
    icon: '💌',
    desc: 'จั่วการ์ดสุ่มโชคชะตาสุดปั่นและอบอุ่นใจ'
  },
  {
    id: 23,
    row: 8,
    col: 1,
    type: 'property',
    name: 'แกลเลอรีริมทะเล',
    group: 'nature',
    icon: '🎨',
    price: 2200,
    baseRent: 550,
    rentLv2: 1450,
    rentLv3: 3000,
    upgradeCost: 1200,
    desc: 'พื้นที่จัดแสดงภาพวาดสีน้ำและงานประติมากรรมเปลือกหอย'
  },
  {
    id: 24,
    row: 8,
    col: 0,
    type: 'rest',
    name: 'กระท่อมฝนตก',
    subtitle: 'พักจิบโกโก้ 1 เทิร์น',
    icon: '🌧️',
    desc: 'ฝนตกพรำๆ บรรยากาศน่านอน จิบช็อกโกแลตร้อนและพักผ่อน 1 เทิร์น'
  },

  // Left Column (25 to 31, bottom to top)
  {
    id: 25,
    row: 7,
    col: 0,
    type: 'property',
    name: 'จุดชมพระอาทิตย์ตก',
    group: 'resort',
    icon: '🌅',
    price: 2400,
    baseRent: 600,
    rentLv2: 1600,
    rentLv3: 3300,
    upgradeCost: 1300,
    desc: 'จุดชมวิวแสงทไวไลท์สีทองสะท้อนผืนน้ำที่งดงามที่สุดบนเกาะ'
  },
  {
    id: 26,
    row: 6,
    col: 0,
    type: 'property',
    isWonder: true,
    name: 'ลานดูดาวจักรวาล',
    group: 'wonders',
    icon: '🌌',
    price: 2100,
    baseRent: 550,
    desc: 'สิ่งมหัศจรรย์แห่งเกาะ สร้างได้แค่ครั้งเดียว หากสะสมครบ 8 แห่งชนะทันที!'
  },
  {
    id: 27,
    row: 5,
    col: 0,
    type: 'property',
    name: 'ลานกางเต็นท์ดูดาว',
    group: 'resort',
    icon: '⛺',
    price: 2600,
    baseRent: 650,
    rentLv2: 1750,
    rentLv3: 3600,
    upgradeCost: 1400,
    desc: 'นอนมองดาวประกายระยิบระยับกับกองไฟแคมป์ปิ้งแสนอบอุ่น'
  },
  {
    id: 28,
    row: 4,
    col: 0,
    type: 'minigame',
    name: 'ตู้สุ่มกาชาปอง',
    subtitle: 'ลุ้นรางวัล/ระวังโจร!',
    icon: '🎁',
    desc: 'หมุนกาชาปองนำโชค ลุ้นรับของรางวัล แต่ระวังโจรฉกเงินและหนี้สิน!'
  },
  {
    id: 29,
    row: 3,
    col: 0,
    type: 'property',
    isWonder: true,
    name: 'มหาวิหารทองคำ',
    group: 'wonders',
    icon: '👑',
    price: 2200,
    baseRent: 600,
    desc: 'สิ่งมหัศจรรย์แห่งเกาะ สร้างได้แค่ครั้งเดียว หากสะสมครบ 8 แห่งชนะทันที!'
  },
  {
    id: 30,
    row: 2,
    col: 0,
    type: 'property',
    name: 'รีสอร์ตหรูริมผา',
    group: 'resort',
    icon: '🏰',
    price: 3000,
    baseRent: 750,
    rentLv2: 2000,
    rentLv3: 4200,
    upgradeCost: 1600,
    desc: 'พูลวิลล่าส่วนตัวระดับ 5 ดาว วิวพาโนรามา 360 องศา'
  },
  {
    id: 31,
    row: 1,
    col: 0,
    type: 'bonus_move',
    name: 'ทางลัดปั่นจักรยาน',
    subtitle: 'ปั่นพุ่งหน้า 2 ช่องฟรี',
    icon: '🚲',
    steps: 2,
    desc: 'เช่าจักรยานวินเทจ ปั่นชิวรับลมพุ่งไปข้างหน้าอีก 2 ช่องทันที!'
  }
];

const FORTUNE_CARDS = [
  {
    title: '🦹‍♂️ โดนโจรขโมยเงิน!',
    desc: 'โจรแอบย่องเบาขโมยเงินสดจากกระเป๋าไป 600 เหรียญ! ต้องระมัดระวังตัวให้มากขึ้น',
    type: 'pay_money',
    amount: 600,
    icon: '🦹'
  },
  {
    title: '💸 โดนเจ้าหนี้ตามทวงเงิน!',
    desc: 'มีใบแจ้งหนี้ตกค้างส่งตรงถึงเกาะ ต้องชำระหนี้สินทันที 1,000 เหรียญ!',
    type: 'pay_money',
    amount: 1000,
    icon: '💸'
  },
  {
    title: 'กาแฟดริปพิเศษ',
    desc: 'ค้นพบเมล็ดกาแฟเกอิชาหายาก รสชาตินุ่มละมุน ได้รับโบนัสการขาย 800 เหรียญ!',
    type: 'gain_money',
    amount: 800,
    icon: '☕'
  },
  {
    title: 'น้องแมวส้มมานอนตัก',
    desc: 'น้องแมวอ้วนกลมมานอนซุกตัก ขยับไปไหนไม่ได้ ต้องพักผ่อนชิวๆ 1 เทิร์น แต่ได้รับทิปค่าอาหารแมว 500 เหรียญ!',
    type: 'sleep_and_gain',
    amount: 500,
    icon: '🐱'
  },
  {
    title: '🦹‍♂️ แก๊งโจรดักปล้นริมหาด',
    desc: 'โดนแก๊งโจรเจ้าถิ่นล้อมขอส่วนแบ่ง เสียเงิน 800 เหรียญ!',
    type: 'pay_money',
    amount: 800,
    icon: '🦹'
  },
  {
    title: 'ถูกสลากออมสิน',
    desc: 'เงินออมเพื่อการพักผ่อนผลงอกงาม ถูกรางวัลสลากงวดพิเศษ รับเงินสดทันที 1,000 เหรียญ!',
    type: 'gain_money',
    amount: 1000,
    icon: '🎟️'
  },
  {
    title: '💸 ดอกเบี้ยหนี้สินพอกพูน',
    desc: 'ดอกเบี้ยเงินกู้ครบกำหนดชำระ เสียเงิน 500 เหรียญ!',
    type: 'pay_money',
    amount: 500,
    icon: '💸'
  },
  {
    title: 'บัตรอัปเกรดฟรีวีไอพี',
    desc: 'ได้รับบัตรกำนัลสถาปนิกเกาะ สามารถอัปเกรดที่ดินของตนเองฟรี 1 ขั้นทันที!',
    type: 'free_upgrade',
    icon: '🔨'
  },
  {
    title: 'ลมพัดหมวกปลิว',
    desc: 'ลมทะเลพัดแรงจนหมวกใบโปรดปลิว ต้องเดินถอยหลัง 2 ช่องเพื่อไปเก็บหมวก',
    type: 'move_back',
    steps: 2,
    icon: '👒'
  },
  {
    title: 'สายลมเกื้อหนุน',
    desc: 'ลมเย็นสดชื่นพัดส่งพลังบวก เดินหน้าต่อไปอีก 3 ช่องทันที!',
    type: 'move_forward',
    steps: 3,
    icon: '🍃'
  },
  {
    title: 'เงินปันผลสหกรณ์เกาะ',
    desc: 'การท่องเที่ยวบนเกาะคึกคัก ได้รับเงินปันผลรายไตรมาส 1,200 เหรียญ!',
    type: 'gain_money',
    amount: 1200,
    icon: '💰'
  }
];

const WHEEL_SEGMENTS = [
  { label: '💸 โดนติดหนี้ -1,000', type: 'debt', value: -1000, color: '#dc2626' },
  { label: '🦹 โจรปล้น -600', type: 'thief', value: -600, color: '#475569' },
  { label: 'โชคใหญ่ +1,000', type: 'money', value: 1000, color: '#10b981' },
  { label: '💸 ดอกเบี้ยหนี้ -400', type: 'debt', value: -400, color: '#b91c1c' },
  { label: '+800 เหรียญ', type: 'money', value: 800, color: '#3b82f6' },
  { label: '🦹 โจรฉกเงิน -500', type: 'thief', value: -500, color: '#64748b' },
  { label: 'แจ็กพอต +1,500', type: 'money', value: 1500, color: '#8b5cf6' },
  { label: 'อัปเกรดฟรี 1 ขั้น', type: 'free_upgrade', value: 0, color: '#f59e0b' }
];

window.GAME_DATA = {
  COLOR_GROUPS,
  BOARD_TILES,
  FORTUNE_CARDS,
  WHEEL_SEGMENTS
};
