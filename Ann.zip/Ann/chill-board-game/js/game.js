// ==========================================================================
// Chill Island Game Engine - Rules, Movement, Economy, and Turns
// ==========================================================================

class ChillGame {
  constructor() {
    this.players = [];
    this.currentPlayerIndex = 0;
    this.propertyOwners = {}; // tileId -> playerId
    this.propertyLevels = {}; // tileId -> 1, 2, 3
    this.turnCount = 1;
    this.isRolling = false;
    this.isGameOver = false;
    this.speedMode = false;
    this.logs = [];

    this.botController = new BotController(this);
  }

  // Initialize a new game with selected players
  init(playerConfigs) {
    this.players = playerConfigs.map((cfg, idx) => ({
      id: idx,
      name: cfg.name,
      avatar: cfg.avatar,
      color: cfg.color,
      money: 4000,
      position: 0,
      sleepTurns: 0,
      laps: 0,
      isAi: cfg.isAi || false,
      bankrupt: false
    }));

    this.currentPlayerIndex = 0;
    this.propertyOwners = {};
    this.propertyLevels = {};
    this.turnCount = 1;
    this.isRolling = false;
    this.isGameOver = false;
    this.logs = [];

    this.log(`🏝️ ยินดีต้อนรับสู่ "เกาะพักผ่อนชิวโพลี (Chill Island)"! เริ่มต้นการเดินทางพร้อมงบคนละ 4,000 เหรียญ`, 'system');
    this.log(`🎯 กติกาการชนะ: ทำให้คู่แข่งล้มละลาย หรือ ครอบครอง 8 สิ่งมหัศจรรย์แห่งเกาะครบทั้งหมด!`, 'system');
    this.log(`🚩 กติกาพิเศษ: เดินครบทุก 10 รอบ ค่าผ่านทางบ้านทุกหลังจะเพิ่มขึ้น +10% อัตโนมัติ!`, 'system');

    this.renderBoard();
    this.updateUI();

    // If first player is AI
    const firstPlayer = this.getCurrentPlayer();
    if (firstPlayer.isAi) {
      this.botController.handleTurn(firstPlayer);
    }
  }

  getCurrentPlayer() {
    return this.players[this.currentPlayerIndex];
  }

  // Calculate net worth (cash + full value of properties + upgrades)
  calculateNetWorth(player) {
    let worth = player.money;
    BOARD_TILES.forEach(tile => {
      if ((tile.type === 'property' || tile.isWonder) && this.propertyOwners[tile.id] === player.id) {
        worth += tile.price;
        const level = this.propertyLevels[tile.id] || 1;
        if (level >= 2) worth += tile.upgradeCost || 0;
        if (level >= 3) worth += tile.upgradeCost || 0;
      }
    });
    return worth;
  }

  // Check if player owns all properties of a color group
  ownsFullGroup(playerId, groupId) {
    const groupTiles = BOARD_TILES.filter(t => t.group === groupId);
    if (groupTiles.length === 0) return false;
    return groupTiles.every(t => this.propertyOwners[t.id] === playerId);
  }

  // Calculate current rent for a property tile
  getRent(tile) {
    const level = this.propertyLevels[tile.id] || 1;
    let rent = tile.baseRent || 300;
    if (level === 2 && tile.rentLv2) rent = tile.rentLv2;
    if (level === 3 && tile.rentLv3) rent = tile.rentLv3;

    // Double rent if owner possesses the full color set (except wonders)
    const ownerId = this.propertyOwners[tile.id];
    if (ownerId !== undefined && tile.group && tile.group !== 'wonders' && this.ownsFullGroup(ownerId, tile.group)) {
      rent *= 2;
    }

    // 🌟 หากเดินครบ 10 รอบ ให้เพิ่มราคาเข้าไปในแต่ละหลังที่ต้องจ่ายค่าผ่านทาง 10%
    if (ownerId !== undefined) {
      const owner = this.players[ownerId];
      if (owner && owner.laps >= 10) {
        const lapBonusFactor = 1 + (Math.floor(owner.laps / 10) * 0.10);
        rent = Math.round(rent * lapBonusFactor);
      }
    }

    return rent;
  }

  // Log messages to activity ticker
  log(message, type = 'info') {
    const time = new Date().toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    this.logs.unshift({ message, type, time });
    if (this.logs.length > 50) this.logs.pop();

    if (window.renderLogs) {
      window.renderLogs();
    }
  }

  // Check if player is the local controller of this turn
  isLocalPlayer(player) {
    if (window.onlineManager && window.onlineManager.isOnline) {
      return player.id === window.onlineManager.myPlayerId;
    }
    return !player.isAi;
  }

  // Roll dice action
  rollDice() {
    if (this.isRolling || this.isGameOver) return;

    if (window.onlineManager && window.onlineManager.isOnline) {
      if (this.currentPlayerIndex !== window.onlineManager.myPlayerId) {
        return; // It's not my turn in online room
      }
    }

    const player = this.getCurrentPlayer();

    // Check if player is sleeping/resting
    if (player.sleepTurns > 0) {
      this.promptSleepWake(player);
      return;
    }

    this.isRolling = true;
    window.soundManager.playDiceRoll();

    // Roll two dice (1-6 each)
    const dice1 = Math.floor(Math.random() * 6) + 1;
    const dice2 = Math.floor(Math.random() * 6) + 1;
    const totalSteps = dice1 + dice2;

    if (window.onlineManager && window.onlineManager.isOnline) {
      window.onlineManager.sendAction({
        type: 'ROLL_DICE',
        playerId: player.id,
        dice1,
        dice2,
        totalSteps
      });
    }

    if (window.animateDiceRoll) {
      window.animateDiceRoll(dice1, dice2, () => {
        this.log(`${player.avatar} ${player.name} ทอยเต๋าได้ ${dice1} + ${dice2} = [ ${totalSteps} แต้ม ]`, 'roll');
        this.movePlayerStepByStep(player, totalSteps);
      });
    } else {
      this.movePlayerStepByStep(player, totalSteps);
    }
  }

  // Prompt sleep wake option for human player
  promptSleepWake(player) {
    if (player.isAi) {
      this.botController.handleTurn(player);
      return;
    }

    // Only prompt popup for the player controlling this machine
    if (!this.isLocalPlayer(player)) {
      this.log(`⏳ รอให้ ${player.avatar} ${player.name} จัดการสถานะพักผ่อน...`, 'chill');
      return;
    }

    window.modalManager.showConfirm({
      title: '🛏️ กำลังพักผ่อนสบายใจ',
      text: `${player.avatar} ${player.name} อยู่ในช่วงพักผ่อน (เหลืออีก ${player.sleepTurns} เทิร์น)\nต้องการจ่ายค่ากาแฟปลุก 300 เหรียญ เพื่อตื่นมาเดินเที่ยวต่อทันทีหรือไม่?`,
      confirmText: '☕ จ่าย 300 เหรียญและเดินต่อ',
      cancelText: '😴 นอนพักต่ออีกเทิร์น',
      onConfirm: () => {
        if (player.money >= 300) {
          player.money -= 300;
          player.sleepTurns = 0;
          this.log(`${player.avatar} ${player.name} จิบกาแฟเอสเพรสโซ่ตื่นตัว จ่าย 300 เหรียญ พร้อมเดินต่อ!`, 'event');
          if (window.onlineManager && window.onlineManager.isOnline) {
            window.onlineManager.sendAction({
              type: 'SLEEP_ACTION',
              playerId: player.id,
              paid: true
            });
          }
          this.updateUI();
          this.rollDice();
        } else {
          this.log(`${player.avatar} ${player.name} เงินไม่พอจ่ายค่ากาแฟ นอนพักผ่อนต่ออีก 1 เทิร์น`, 'chill');
          player.sleepTurns--;
          if (window.onlineManager && window.onlineManager.isOnline) {
            window.onlineManager.sendAction({
              type: 'SLEEP_ACTION',
              playerId: player.id,
              paid: false
            });
          }
          this.updateUI();
          this.nextTurn();
        }
      },
      onCancel: () => {
        this.log(`${player.avatar} ${player.name} เลือกนอนพักผ่อนจิบชาต่ออย่างสบายอารมณ์ zZZ`, 'chill');
        player.sleepTurns--;
        if (window.onlineManager && window.onlineManager.isOnline) {
          window.onlineManager.sendAction({
            type: 'SLEEP_ACTION',
            playerId: player.id,
            paid: false
          });
        }
        this.updateUI();
        this.nextTurn();
      }
    });
  }

  // Smooth step-by-step movement animation
  movePlayerStepByStep(player, steps, onComplete = null) {
    let remainingSteps = steps;
    const stepDuration = this.speedMode ? 120 : 260;

    const stepInterval = setInterval(() => {
      const prevPos = player.position;
      player.position = (player.position + 1) % BOARD_TILES.length;
      remainingSteps--;

      // Check if passed Start (tile 0)
      if (player.position === 0 && prevPos !== 0) {
        player.laps = (player.laps || 0) + 1;
        player.money += 2000;
        window.soundManager.playBuy();
        this.log(`🚢 ${player.avatar} ${player.name} ผ่านจุดเริ่มต้นท่าเรือ (รอบที่ ${player.laps}) ได้รับงบพักผ่อน 2,000 เหรียญ!`, 'cash');

        if (player.laps === 10) {
          this.log(`🔥 [ฉลองครบ 10 รอบ!] ${player.avatar} ${player.name} เดินทางครบ 10 รอบแล้ว! อสังหาริมทรัพย์และสิ่งปลูกสร้างทั้งหมดของ ${player.name} เพิ่มค่าผ่านทาง +10%!`, 'event');
        } else if (player.laps > 10 && player.laps % 10 === 0) {
          const totalPct = Math.floor(player.laps / 10) * 10;
          this.log(`🔥 [ฉลองครบ ${player.laps} รอบ!] ${player.avatar} ${player.name} ค่าผ่านทางเพิ่มเป็น +${totalPct}%!`, 'event');
        }
      }

      window.soundManager.playHop(player.position);
      this.updatePlayerTokens();

      if (remainingSteps <= 0) {
        clearInterval(stepInterval);
        this.isRolling = false;

        const landedTile = BOARD_TILES[player.position];
        this.log(`${player.avatar} ${player.name} เดินมาถึง [ ${landedTile.icon} ${landedTile.name} ]`, 'info');

        if (onComplete) {
          onComplete();
        } else {
          this.handleTileLanding(player, landedTile);
        }
      }
    }, stepDuration);
  }

  // Handle actions after landing on a tile
  handleTileLanding(player, tile) {
    this.updateUI();

    switch (tile.type) {
      case 'start':
        player.money += 1000;
        window.soundManager.playBuy();
        this.log(`🎉 ${player.avatar} ${player.name} หยุดพักที่ท่าเรือใหญ่พอดี ได้รับโบนัสต้อนรับเพิ่มอีก 1,000 เหรียญ!`, 'cash');
        this.checkWinOrNextTurn();
        break;

      case 'property':
        this.handlePropertyTile(player, tile);
        break;

      case 'card':
        this.handleCardTile(player);
        break;

      case 'minigame':
        this.handleMinigameTile(player);
        break;

      case 'oasis':
        player.money += 500;
        window.soundManager.playBuy();
        this.log(`🧘 ${player.avatar} ${player.name} นั่งสมาธิที่สวนเซน จิตใจเบิกบาน รับพลังบวก 500 เหรียญฟรี!`, 'cash');
        this.checkWinOrNextTurn();
        break;

      case 'rest':
        player.sleepTurns = 1;
        this.log(`🌧️ ${player.avatar} ${player.name} แวะพักผ่อนชิวๆ ที่ ${tile.name} จะได้พักผ่อน 1 เทิร์น`, 'chill');
        this.checkWinOrNextTurn();
        break;

      case 'transit':
        this.log(`🚤 ${player.avatar} ${player.name} ขึ้นเรือสปีดโบ๊ท วาร์ปข้ามเกาะไปยัง [ ${BOARD_TILES[tile.targetTile].name} ] ทันที!`, 'event');
        player.position = tile.targetTile;
        this.updatePlayerTokens();
        setTimeout(() => {
          this.handleTileLanding(player, BOARD_TILES[tile.targetTile]);
        }, 600);
        break;

      case 'bonus_move':
        this.log(`🚲 ${player.avatar} ${player.name} ปั่นจักรยานรับลม พุ่งต่อไปข้างหน้าอีก ${tile.steps} ช่องฟรี!`, 'event');
        setTimeout(() => {
          this.movePlayerStepByStep(player, tile.steps);
        }, 500);
        break;

      default:
        this.checkWinOrNextTurn();
    }
  }

  // Handle Property tile interaction
  handlePropertyTile(player, tile) {
    const ownerId = this.propertyOwners[tile.id];
    const isOnline = window.onlineManager && window.onlineManager.isOnline;
    const isLocal = this.isLocalPlayer(player);

    // 🌟 Special Wonder Tiles (ช่องพิเศษ 8 ช่อง ที่สร้างได้แค่ครั้งเดียว ครบ 8 ชนะทันที)
    if (tile.isWonder) {
      if (ownerId === undefined) {
        if (player.isAi) {
          const wantsToBuy = this.botController.decideBuyProperty(player, tile);
          if (wantsToBuy && player.money >= tile.price) {
            this.buyProperty(player, tile);
          } else {
            this.log(`${player.avatar} ${player.name} ตัดสินใจเดินผ่านสิ่งมหัศจรรย์ ${tile.name}`, 'chill');
          }
          setTimeout(() => this.checkWinOrNextTurn(), 800);
        } else if (isLocal) {
          window.modalManager.showBuyProperty(player, tile, (confirmed) => {
            if (confirmed) {
              this.buyProperty(player, tile);
            } else {
              this.log(`${player.avatar} ${player.name} เลือกที่จะยังไม่สร้างสิ่งมหัศจรรย์ ${tile.name}`, 'chill');
              if (isOnline) {
                window.onlineManager.sendAction({
                  type: 'SKIP_PROPERTY',
                  playerId: player.id,
                  tileId: tile.id
                });
              }
            }
            this.checkWinOrNextTurn();
          });
        } else {
          this.log(`⏳ รอให้ ${player.avatar} ${player.name} ตัดสินใจสร้างสิ่งมหัศจรรย์...`, 'chill');
        }
      } else if (ownerId === player.id) {
        // Already owned by self - CANNOT BE UPGRADED (สร้างได้แค่ครั้งเดียว)
        const ownedWonders = BOARD_TILES.filter(t => t.isWonder && this.propertyOwners[t.id] === player.id);
        this.log(`👑 [สิ่งมหัศจรรย์] ${player.avatar} ${player.name} แวะพักที่ [ ${tile.icon} ${tile.name} ] ของตนเอง (สร้างได้แค่ครั้งเดียว ไม่ต้องอัปเกรด) ตอนนี้ถือครองอยู่ ${ownedWonders.length}/8 แห่ง!`, 'event');
        this.checkWinOrNextTurn();
      } else {
        // Owned by rival!
        const owner = this.players[ownerId];
        const rent = this.getRent(tile);
        const ownerLapBonus = (owner.laps && owner.laps >= 10) ? ` (รวมโบนัสเดินครบ 10 รอบ +${Math.floor(owner.laps / 10) * 10}%!)` : '';

        window.soundManager.playRent();
        this.log(`💸 ${player.avatar} ${player.name} แวะเยี่ยมชมสิ่งมหัศจรรย์ [ ${tile.icon} ${tile.name} ] ของ ${owner.avatar} ${owner.name}! จ่ายค่าผ่านทาง ${rent.toLocaleString()} เหรียญ${ownerLapBonus}`, 'rent');

        player.money -= rent;
        owner.money += rent;

        if (player.money < 0) {
          this.handleBankruptcy(player, owner);
          this.updateUI();
          setTimeout(() => this.checkWinOrNextTurn(), 1000);
          return;
        }

        this.updateUI();

        // Wonder takeover (1.5x price)
        const takeoverCost = Math.round((tile.price * 1.5) / 50) * 50;
        if (player.isAi) {
          const wantsTakeover = this.botController.decideTakeoverProperty(player, owner, tile, takeoverCost);
          if (wantsTakeover && player.money >= takeoverCost) {
            setTimeout(() => {
              this.takeoverProperty(player, owner, tile, takeoverCost);
              setTimeout(() => this.checkWinOrNextTurn(), 800);
            }, 600);
          } else {
            setTimeout(() => this.checkWinOrNextTurn(), 800);
          }
        } else if (isLocal) {
          setTimeout(() => {
            window.modalManager.showTakeoverProperty(player, owner, tile, takeoverCost, 1, (confirmed) => {
              if (confirmed && player.money >= takeoverCost) {
                this.takeoverProperty(player, owner, tile, takeoverCost);
              } else {
                this.log(`${player.avatar} ${player.name} เลือกที่จะยังไม่แย่งชิงสิ่งมหัศจรรย์ ${tile.name}`, 'chill');
                if (isOnline) {
                  window.onlineManager.sendAction({
                    type: 'SKIP_PROPERTY',
                    playerId: player.id,
                    tileId: tile.id
                  });
                }
              }
              this.checkWinOrNextTurn();
            });
          }, 600);
        } else {
          this.log(`⏳ รอให้ ${player.avatar} ${player.name} ตัดสินใจเรื่องแย่งชิงสิ่งมหัศจรรย์...`, 'chill');
        }
      }
      return;
    }

    if (ownerId === undefined) {
      if (player.isAi) {
        const wantsToBuy = this.botController.decideBuyProperty(player, tile);
        if (wantsToBuy && player.money >= tile.price) {
          this.buyProperty(player, tile);
        } else {
          this.log(`${player.avatar} ${player.name} ตัดสินใจเดินผ่าน ${tile.name} เพื่อเก็บเงินสำรอง`, 'chill');
        }
        setTimeout(() => this.checkWinOrNextTurn(), 800);
      } else if (isLocal) {
        window.modalManager.showBuyProperty(player, tile, (confirmed) => {
          if (confirmed) {
            this.buyProperty(player, tile);
          } else {
            this.log(`${player.avatar} ${player.name} เลือกที่จะยังไม่ซื้อ ${tile.name}`, 'chill');
            if (isOnline) {
              window.onlineManager.sendAction({
                type: 'SKIP_PROPERTY',
                playerId: player.id,
                tileId: tile.id
              });
            }
          }
          this.checkWinOrNextTurn();
        });
      } else {
        this.log(`⏳ รอให้ ${player.avatar} ${player.name} ตัดสินใจเลือกซื้อที่ดิน...`, 'chill');
      }
    } else if (ownerId === player.id) {
      const currentLevel = this.propertyLevels[tile.id] || 1;
      if (currentLevel < 3) {
        if (player.isAi) {
          const wantsUpgrade = this.botController.decideUpgradeProperty(player, tile);
          if (wantsUpgrade && player.money >= tile.upgradeCost) {
            this.upgradeProperty(player, tile);
          } else {
            this.log(`${player.avatar} ${player.name} ยังไม่ต้องการอัปเกรด ${tile.name} ในรอบนี้`, 'chill');
          }
          setTimeout(() => this.checkWinOrNextTurn(), 800);
        } else if (isLocal) {
          window.modalManager.showUpgradeProperty(player, tile, currentLevel, (confirmed) => {
            if (confirmed) {
              this.upgradeProperty(player, tile);
            } else {
              this.log(`${player.avatar} ${player.name} เลือกเก็บเงินไว้ ยังไม่อัปเกรด ${tile.name}`, 'chill');
              if (isOnline) {
                window.onlineManager.sendAction({
                  type: 'SKIP_PROPERTY',
                  playerId: player.id,
                  tileId: tile.id
                });
              }
            }
            this.checkWinOrNextTurn();
          });
        } else {
          this.log(`⏳ รอให้ ${player.avatar} ${player.name} ตัดสินใจอัปเกรดที่ดิน...`, 'chill');
        }
      } else {
        this.log(`🏰 [แลนด์มาร์ก] ${tile.name} ของ ${player.avatar} ${player.name} ตันที่เลเวล 3 แล้ว! (ระดับสูงสุด)`, 'chill');
        this.checkWinOrNextTurn();
      }
    } else {
      const owner = this.players[ownerId];
      const rent = this.getRent(tile);
      const isSet = this.ownsFullGroup(owner.id, tile.group);
      const ownerLapBonus = (owner.laps && owner.laps >= 10) ? ` (รวมโบนัสเดินครบ 10 รอบ +${Math.floor(owner.laps / 10) * 10}%!)` : '';

      window.soundManager.playRent();
      this.log(`💸 ${player.avatar} ${player.name} แวะพักที่ [ ${tile.icon} ${tile.name} ] ของ ${owner.avatar} ${owner.name}! จ่ายค่าบริการ ${rent.toLocaleString()} เหรียญ ${isSet ? '(โบนัสคุมโซนครบเซ็ต x2!)' : ''}${ownerLapBonus}`, 'rent');

      player.money -= rent;
      owner.money += rent;

      if (player.money < 0) {
        this.handleBankruptcy(player, owner);
        this.updateUI();
        setTimeout(() => this.checkWinOrNextTurn(), 1000);
        return;
      }

      this.updateUI();

      // Check if property can be bought from owner (if not capped at Level 3)
      const currentLevel = this.propertyLevels[tile.id] || 1;
      if (currentLevel < 3) {
        const totalInvested = tile.price + (currentLevel - 1) * tile.upgradeCost;
        const takeoverCost = Math.round((totalInvested * 1.5) / 50) * 50;

        if (player.isAi) {
          const wantsTakeover = this.botController.decideTakeoverProperty(player, owner, tile, takeoverCost);
          if (wantsTakeover && player.money >= takeoverCost) {
            setTimeout(() => {
              this.takeoverProperty(player, owner, tile, takeoverCost);
              setTimeout(() => this.checkWinOrNextTurn(), 800);
            }, 600);
          } else {
            setTimeout(() => this.checkWinOrNextTurn(), 800);
          }
        } else if (isLocal) {
          setTimeout(() => {
            window.modalManager.showTakeoverProperty(player, owner, tile, takeoverCost, currentLevel, (confirmed) => {
              if (confirmed && player.money >= takeoverCost) {
                this.takeoverProperty(player, owner, tile, takeoverCost);
              } else {
                this.log(`${player.avatar} ${player.name} เลือกที่จะยังไม่เทคโอเวอร์ ${tile.name}`, 'chill');
                if (isOnline) {
                  window.onlineManager.sendAction({
                    type: 'SKIP_PROPERTY',
                    playerId: player.id,
                    tileId: tile.id
                  });
                }
              }
              this.checkWinOrNextTurn();
            });
          }, 600);
        } else {
          this.log(`⏳ รอให้ ${player.avatar} ${player.name} ตัดสินใจเรื่องซื้อต่อกิจการ...`, 'chill');
        }
      } else {
        this.log(`🏰 [แลนด์มาร์ก] [ ${tile.name} ] ของ ${owner.avatar} ${owner.name} ตันที่เลเวล 3 แล้ว ไม่สามารถซื้อต่อได้!`, 'info');
        setTimeout(() => this.checkWinOrNextTurn(), 1000);
      }
    }
  }

  takeoverProperty(buyer, previousOwner, tile, takeoverCost, isRemote = false) {
    buyer.money -= takeoverCost;
    previousOwner.money += takeoverCost;
    this.propertyOwners[tile.id] = buyer.id;
    const currentLevel = this.propertyLevels[tile.id] || 1;
    window.soundManager.playBuy();

    if (tile.isWonder) {
      const ownedWonders = BOARD_TILES.filter(t => t.isWonder && this.propertyOwners[t.id] === buyer.id);
      this.log(`👑💥 [แย่งชิงสิ่งมหัศจรรย์!] ${buyer.avatar} ${buyer.name} ทุ่มเงิน ${takeoverCost.toLocaleString()} เหรียญ ซื้อต่อ [ ${tile.icon} ${tile.name} ] จาก ${previousOwner.avatar} ${previousOwner.name} สำเร็จ! (สะสมแล้ว ${ownedWonders.length}/8 แห่ง)`, 'cash');
      if (ownedWonders.length === 8) {
        this.renderBoard();
        this.updateUI();
        this.triggerVictory(buyer, '🌟 ปาฏิหาริย์แห่งเกาะชิว! ครอบครองสิ่งมหัศจรรย์ครบทั้ง 8 แห่ง ชนะการแข่งขันทันที!');
        return;
      }
    } else {
      this.log(`🏨💥 [ซื้อต่อกิจการ!] ${buyer.avatar} ${buyer.name} ทุ่มเงิน ${takeoverCost.toLocaleString()} เหรียญ ซื้อต่อ [ ${tile.icon} ${tile.name} ] (Lv.${currentLevel}) จาก ${previousOwner.avatar} ${previousOwner.name} สำเร็จ!`, 'cash');
      if (this.ownsFullGroup(buyer.id, tile.group)) {
        this.log(`🌟 สุดยอด! ${buyer.avatar} ${buyer.name} ยึดครองโซน ${COLOR_GROUPS[tile.group].name} ครบทุกแห่งแล้ว! ค่าบริการเพิ่มเป็น 2 เท่า!`, 'event');
      }
    }

    if (!isRemote && window.onlineManager && window.onlineManager.isOnline) {
      window.onlineManager.sendAction({
        type: 'TAKEOVER_PROPERTY',
        buyerId: buyer.id,
        prevOwnerId: previousOwner.id,
        tileId: tile.id,
        cost: takeoverCost
      });
    }

    this.renderBoard();
    this.updateUI();
  }

  buyProperty(player, tile, isRemote = false) {
    player.money -= tile.price;
    this.propertyOwners[tile.id] = player.id;
    this.propertyLevels[tile.id] = 1;
    window.soundManager.playBuy();

    if (tile.isWonder) {
      const ownedWonders = BOARD_TILES.filter(t => t.isWonder && this.propertyOwners[t.id] === player.id);
      this.log(`👑✨ [สร้างสิ่งมหัศจรรย์!] ${player.avatar} ${player.name} ครอบครอง [ ${tile.icon} ${tile.name} ] ในราคา ${tile.price.toLocaleString()} เหรียญ! (สะสมแล้ว ${ownedWonders.length}/8 แห่ง)`, 'event');
      if (ownedWonders.length === 8) {
        this.renderBoard();
        this.updateUI();
        this.triggerVictory(player, '🌟 ปาฏิหาริย์แห่งเกาะชิว! ครอบครองสิ่งมหัศจรรย์ครบทั้ง 8 แห่ง ชนะการแข่งขันทันที!');
        return;
      }
    } else {
      this.log(`✨ ${player.avatar} ${player.name} ซื้อกรรมสิทธิ์ [ ${tile.icon} ${tile.name} ] ในราคา ${tile.price.toLocaleString()} เหรียญ!`, 'cash');
      if (this.ownsFullGroup(player.id, tile.group)) {
        this.log(`🌟 สุดยอด! ${player.avatar} ${player.name} ครอบครองอสังหาฯ ใน ${COLOR_GROUPS[tile.group].name} ครบทุกแห่งแล้ว! ค่าเช่าจะเพิ่มเป็น 2 เท่า!`, 'event');
      }
    }

    if (!isRemote && window.onlineManager && window.onlineManager.isOnline) {
      window.onlineManager.sendAction({
        type: 'BUY_PROPERTY',
        playerId: player.id,
        tileId: tile.id
      });
    }

    this.renderBoard();
    this.updateUI();
  }

  upgradeProperty(player, tile, isRemote = false) {
    player.money -= tile.upgradeCost;
    const newLevel = (this.propertyLevels[tile.id] || 1) + 1;
    this.propertyLevels[tile.id] = newLevel;
    window.soundManager.playBuy();

    const lvTitle = newLevel === 2 ? 'ระดับดีลักซ์ (★ 2 ดาว)' : 'รีสอร์ตแลนด์มาร์ก (★★★ 3 ดาว)';
    this.log(`🔨 ${player.avatar} ${player.name} อัปเกรด [ ${tile.icon} ${tile.name} ] เป็น ${lvTitle}! ค่าบริการเพิ่มขึ้น!`, 'cash');

    if (!isRemote && window.onlineManager && window.onlineManager.isOnline) {
      window.onlineManager.sendAction({
        type: 'UPGRADE_PROPERTY',
        playerId: player.id,
        tileId: tile.id
      });
    }

    this.renderBoard();
    this.updateUI();
  }

  handleCardTile(player, cardIndex = null) {
    const cards = GAME_DATA.FORTUNE_CARDS;
    const isOnline = window.onlineManager && window.onlineManager.isOnline;

    if (isOnline && !this.isLocalPlayer(player) && cardIndex === null) {
      this.log(`⏳ รอให้ ${player.avatar} ${player.name} เปิดการ์ด...`, 'chill');
      return;
    }

    let card;
    if (cardIndex !== null && cardIndex !== undefined) {
      card = cards[cardIndex];
    } else {
      const idx = Math.floor(Math.random() * cards.length);
      card = cards[idx];
      if (isOnline && this.isLocalPlayer(player)) {
        window.onlineManager.sendAction({
          type: 'DRAW_CARD',
          playerId: player.id,
          cardIndex: idx
        });
      }
    }

    window.soundManager.playCard();

    const applyCardEffect = () => {
      this.log(`💌 [การ์ดลมหายใจเกาะ] ${player.avatar} ${player.name} ได้รับ: "${card.title}" - ${card.desc}`, 'event');

      switch (card.type) {
        case 'gain_money':
          player.money += card.amount;
          window.soundManager.playBuy();
          break;
        case 'pay_money':
          player.money -= card.amount;
          window.soundManager.playRent();
          if (player.money < 0) this.handleBankruptcy(player, null);
          break;
        case 'sleep_and_gain':
          player.sleepTurns = 1;
          player.money += card.amount;
          window.soundManager.playBuy();
          break;
        case 'free_upgrade':
          const ownTiles = BOARD_TILES.filter(t => t.type === 'property' && this.propertyOwners[t.id] === player.id && (this.propertyLevels[t.id] || 1) < 3);
          if (ownTiles.length > 0) {
            const targetTile = ownTiles[0];
            this.propertyLevels[targetTile.id] = (this.propertyLevels[targetTile.id] || 1) + 1;
            this.log(`🔨 สถาปนิกอัปเกรด [ ${targetTile.name} ] ของ ${player.name} ให้ฟรี 1 ขั้น!`, 'cash');
            this.renderBoard();
          } else {
            player.money += 500;
            this.log(`${player.name} ยังไม่มีที่ดินให้อัปเกรด เปลี่ยนเป็นรับเงินสด 500 เหรียญแทน!`, 'cash');
          }
          break;
        case 'move_forward':
          setTimeout(() => {
            this.movePlayerStepByStep(player, card.steps);
          }, 400);
          return;
        case 'move_back':
          player.position = (player.position - card.steps + BOARD_TILES.length) % BOARD_TILES.length;
          this.updatePlayerTokens();
          break;
      }

      this.updateUI();
      setTimeout(() => this.checkWinOrNextTurn(), 800);
    };

    if (player.isAi) {
      this.log(`${player.avatar} ${player.name} จั่วได้การ์ด: "${card.title}"`, 'event');
      setTimeout(applyCardEffect, 1200);
    } else if (this.isLocalPlayer(player)) {
      window.modalManager.showCard(card, applyCardEffect);
    } else {
      setTimeout(applyCardEffect, 800);
    }
  }

  handleMinigameTile(player, prizeIndex = null) {
    const segments = GAME_DATA.WHEEL_SEGMENTS;
    const isOnline = window.onlineManager && window.onlineManager.isOnline;

    if (isOnline && !this.isLocalPlayer(player) && prizeIndex === null) {
      this.log(`⏳ รอให้ ${player.avatar} ${player.name} หมุนวงล้อเสี่ยงทาย...`, 'chill');
      return;
    }

    const applyPrize = (prize) => {
      this.log(`🎡 [วงล้อเสี่ยงทาย] ${player.avatar} ${player.name} หมุนได้: "${prize.label}"!`, 'event');

      if (prize.type === 'money') {
        player.money += prize.value;
        if (prize.value > 0) window.soundManager.playBuy();
      } else if (prize.type === 'debt') {
        player.money += prize.value;
        window.soundManager.playRent();
        this.log(`💸 ${player.avatar} ${player.name} โดนใบแจ้งหนี้ตกค้าง! ชำระเงิน ${Math.abs(prize.value).toLocaleString()} เหรียญ`, 'rent');
        if (player.money < 0) {
          this.handleBankruptcy(player, null);
          this.updateUI();
          setTimeout(() => this.checkWinOrNextTurn(), 1000);
          return;
        }
      } else if (prize.type === 'thief') {
        player.money += prize.value;
        window.soundManager.playRent();
        this.log(`🦹‍♂️ ${player.avatar} ${player.name} โดนโจรขโมยเงินไป ${Math.abs(prize.value).toLocaleString()} เหรียญ!`, 'rent');
        if (player.money < 0) {
          this.handleBankruptcy(player, null);
          this.updateUI();
          setTimeout(() => this.checkWinOrNextTurn(), 1000);
          return;
        }
      } else if (prize.type === 'free_upgrade') {
        const ownTiles = BOARD_TILES.filter(t => t.type === 'property' && !t.isWonder && this.propertyOwners[t.id] === player.id && (this.propertyLevels[t.id] || 1) < 3);
        if (ownTiles.length > 0) {
          const targetTile = ownTiles[0];
          this.propertyLevels[targetTile.id] = (this.propertyLevels[targetTile.id] || 1) + 1;
          this.renderBoard();
        } else {
          player.money += 800;
        }
        window.soundManager.playBuy();
      }

      this.updateUI();
      this.checkWinOrNextTurn();
    };

    if (player.isAi) {
      const idx = Math.floor(Math.random() * segments.length);
      const prize = segments[idx];
      setTimeout(() => applyPrize(prize), 1200);
    } else if (this.isLocalPlayer(player)) {
      window.modalManager.showLuckyWheel(player, (prize, winIdx) => {
        if (isOnline) {
          window.onlineManager.sendAction({
            type: 'LUCKY_WHEEL_RESULT',
            playerId: player.id,
            prizeIndex: winIdx
          });
        }
        applyPrize(prize);
      });
    } else {
      const prize = segments[prizeIndex] || segments[0];
      setTimeout(() => applyPrize(prize), 800);
    }
  }

  handleBankruptcy(player, creditor) {
    player.bankrupt = true;
    player.money = 0;
    this.log(`💀 ${player.avatar} ${player.name} เงินหมดกระเป๋า ต้องออกจากการเดินทางบนเกาะ!`, 'rent');

    BOARD_TILES.forEach(tile => {
      if (this.propertyOwners[tile.id] === player.id) {
        if (creditor) {
          this.propertyOwners[tile.id] = creditor.id;
        } else {
          delete this.propertyOwners[tile.id];
          delete this.propertyLevels[tile.id];
        }
      }
    });

    this.renderBoard();
    this.updateUI();
  }

  checkWinOrNextTurn() {
    this.updateUI();

    const activePlayers = this.players.filter(p => !p.bankrupt);
    if (activePlayers.length === 1) {
      this.triggerVictory(activePlayers[0], 'ทำให้คู่แข่งทุกคนล้มละลายหมดตัว เป็นผู้ชนะสูงสุดบนเกาะพักผ่อน!');
      return;
    }

    this.nextTurn();
  }

  triggerVictory(winner, reason) {
    this.isGameOver = true;
    window.soundManager.playWin();
    this.log(`🏆🎉 ชัยชนะเป็นของ ${winner.avatar} ${winner.name}! ${reason}`, 'event');

    if (window.modalManager) {
      window.modalManager.showVictory(winner, reason, this.calculateNetWorth(winner));
    }
  }

  nextTurn() {
    if (this.isGameOver) return;

    let attempts = 0;
    do {
      this.currentPlayerIndex = (this.currentPlayerIndex + 1) % this.players.length;
      attempts++;
    } while (this.getCurrentPlayer().bankrupt && attempts < this.players.length);

    this.turnCount++;
    this.updateUI();

    const nextP = this.getCurrentPlayer();
    this.log(`👉 ตาของ ${nextP.avatar} ${nextP.name} [ เทิร์นที่ ${this.turnCount} ]`, 'info');

    if (nextP.isAi) {
      this.botController.handleTurn(nextP);
    }
  }

  renderBoard() {
    if (window.renderBoardTiles) {
      window.renderBoardTiles();
    }
  }

  updatePlayerTokens() {
    if (window.renderPlayerTokens) {
      window.renderPlayerTokens();
    }
  }

  updateUI() {
    if (window.renderUI) {
      window.renderUI();
    }
  }
}

window.chillGame = new ChillGame();
