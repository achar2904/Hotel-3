// ==========================================================================
// Main UI Controller - DOM Bindings, Modals, Dice Animation & Canvas Wheel
// ==========================================================================

// Confetti Particle Engine
class ConfettiCannon {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.particles = [];
    this.animationFrame = null;
    this.resize();
    window.addEventListener('resize', () => this.resize());
  }

  resize() {
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;
  }

  burst(x = window.innerWidth / 2, y = window.innerHeight / 2, count = 100) {
    const colors = ['#f59e0b', '#10b981', '#3b82f6', '#ec4899', '#8b5cf6', '#eab308'];
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 4 + Math.random() * 8;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 3,
        size: 6 + Math.random() * 6,
        color: colors[Math.floor(Math.random() * colors.length)],
        rotation: Math.random() * 360,
        rotSpeed: (Math.random() - 0.5) * 12,
        life: 1,
        decay: 0.008 + Math.random() * 0.012
      });
    }

    if (!this.animationFrame) {
      this.loop();
    }
  }

  loop() {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.18;
      p.rotation += p.rotSpeed;
      p.life -= p.decay;

      if (p.life <= 0) {
        this.particles.splice(i, 1);
        continue;
      }

      this.ctx.save();
      this.ctx.translate(p.x, p.y);
      this.ctx.rotate((p.rotation * Math.PI) / 180);
      this.ctx.globalAlpha = p.life;
      this.ctx.fillStyle = p.color;
      this.ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
      this.ctx.restore();
    }

    if (this.particles.length > 0) {
      this.animationFrame = requestAnimationFrame(() => this.loop());
    } else {
      this.animationFrame = null;
    }
  }
}

// Modal Manager
class ModalManager {
  constructor() {
    this.overlay = document.getElementById('modalOverlay');
    this.modalContent = document.getElementById('modalContainer');
    this.activeCallback = null;
  }

  show(htmlContent) {
    this.modalContent.innerHTML = htmlContent;
    this.overlay.classList.remove('hidden');
    this.overlay.classList.add('active');
  }

  hide() {
    this.overlay.classList.remove('active');
    setTimeout(() => {
      this.overlay.classList.add('hidden');
      this.modalContent.innerHTML = '';
    }, 200);
  }

  showConfirm({ title, text, confirmText, cancelText, onConfirm, onCancel }) {
    const html = `
      <div class="modal-card">
        <h2 class="modal-title">${title}</h2>
        <p class="modal-desc" style="white-space: pre-line;">${text}</p>
        <div class="modal-actions">
          <button id="modalConfirmBtn" class="btn btn-primary">${confirmText || 'ตกลง'}</button>
          <button id="modalCancelBtn" class="btn btn-secondary">${cancelText || 'ยกเลิก'}</button>
        </div>
      </div>
    `;
    this.show(html);

    document.getElementById('modalConfirmBtn').onclick = () => {
      this.hide();
      if (onConfirm) onConfirm();
    };
    document.getElementById('modalCancelBtn').onclick = () => {
      this.hide();
      if (onCancel) onCancel();
    };
  }

  showBuyProperty(player, tile, callback) {
    const group = GAME_DATA.COLOR_GROUPS[tile.group];
    const canAfford = player.money >= tile.price;

    let detailsHtml = '';
    if (tile.isWonder) {
      detailsHtml = `
        <div class="property-details" style="background: #fffbeb; border: 1px solid #fde68a;">
          <div class="detail-row">
            <span>ราคาครอบครอง:</span>
            <strong class="cost-text" style="color: #b45309;">${tile.price.toLocaleString()} เหรียญ</strong>
          </div>
          <div class="detail-row">
            <span>ค่าผ่านทาง:</span>
            <span>${tile.baseRent.toLocaleString()} เหรียญ</span>
          </div>
          <div class="set-bonus-hint" style="background: #fef3c7; color: #92400e; font-weight: 700; border: 1px solid #fde68a;">
            👑 <strong>กติกาพิเศษสิ่งมหัศจรรย์:</strong> สร้างได้แค่ครั้งเดียว (ไม่มีการอัปเกรด) หากสะสมครบทั้ง 8 แห่งบนเกาะ <strong>จะชนะการแข่งขันทันที!</strong>
          </div>
        </div>
      `;
    } else {
      detailsHtml = `
        <div class="property-details">
          <div class="detail-row">
            <span>ราคาซื้อกรรมสิทธิ์:</span>
            <strong class="cost-text">${tile.price.toLocaleString()} เหรียญ</strong>
          </div>
          <div class="detail-row">
            <span>ค่าบริการพื้นฐาน (Lv 1):</span>
            <span>${tile.baseRent.toLocaleString()} เหรียญ</span>
          </div>
          <div class="detail-row">
            <span>ค่าบริการดีลักซ์ (Lv 2):</span>
            <span>${tile.rentLv2.toLocaleString()} เหรียญ</span>
          </div>
          <div class="detail-row">
            <span>ค่าบริการรีสอร์ตหรู (Lv 3):</span>
            <span>${tile.rentLv3.toLocaleString()} เหรียญ</span>
          </div>
          <div class="set-bonus-hint">
            🌟 สะสมครบทั้ง 3 แห่งในโซนนี้: ค่าบริการเพิ่มขึ้น <strong>2 เท่า</strong>!
          </div>
        </div>
      `;
    }

    const html = `
      <div class="modal-card property-card" style="border-top: 8px solid ${group.color};">
        <div class="property-badge" style="background: ${group.badgeBg}; color: ${group.badgeText};">
          ${group.icon} ${group.name}
        </div>
        <div class="property-header">
          <div class="property-icon">${tile.icon}</div>
          <h2 class="property-name">${tile.isWonder ? '👑 สร้างสิ่งมหัศจรรย์แห่งเกาะ' : tile.name}</h2>
          <p class="property-sub">${tile.desc}</p>
        </div>

        ${detailsHtml}

        <div class="player-balance-info">
          เงินในกระเป๋าของคุณ: <strong>${player.money.toLocaleString()} เหรียญ</strong>
          ${!canAfford ? '<span class="insufficient-alert">(เงินไม่พอซื้อ)</span>' : ''}
        </div>

        <div class="modal-actions">
          <button id="buyBtn" class="btn btn-primary" ${!canAfford ? 'disabled' : ''}>
            🛒 ซื้อกรรมสิทธิ์ (${tile.price.toLocaleString()} เหรียญ)
          </button>
          <button id="skipBtn" class="btn btn-secondary">
            ข้ามไปก่อน
          </button>
        </div>
      </div>
    `;
    this.show(html);

    const buyBtn = document.getElementById('buyBtn');
    if (buyBtn && canAfford) {
      buyBtn.onclick = () => {
        this.hide();
        callback(true);
      };
    }
    document.getElementById('skipBtn').onclick = () => {
      this.hide();
      callback(false);
    };
  }

  showUpgradeProperty(player, tile, currentLevel, callback) {
    const nextLevel = currentLevel + 1;
    const canAfford = player.money >= tile.upgradeCost;
    const nextRent = nextLevel === 2 ? tile.rentLv2 : tile.rentLv3;
    const nextTitle = nextLevel === 2 ? 'ระดับดีลักซ์ (★★)' : 'รีสอร์ตแลนด์มาร์ก (★★★)';

    const html = `
      <div class="modal-card property-card">
        <div class="property-header">
          <div class="property-icon">${tile.icon}</div>
          <h2 class="property-name">อัปเกรด ${tile.name}</h2>
          <p class="property-sub">ยกระดับเป็น ${nextTitle} เพิ่มความฟินและค่าบริการ!</p>
        </div>

        <div class="property-details">
          <div class="detail-row">
            <span>ค่าอัปเกรด:</span>
            <strong class="cost-text">${tile.upgradeCost.toLocaleString()} เหรียญ</strong>
          </div>
          <div class="detail-row">
            <span>ค่าบริการใหม่หลังอัปเกรด:</span>
            <strong style="color: #059669;">${nextRent.toLocaleString()} เหรียญ / ครั้ง</strong>
          </div>
        </div>

        <div class="player-balance-info">
          เงินของคุณ: <strong>${player.money.toLocaleString()} เหรียญ</strong>
          ${!canAfford ? '<span class="insufficient-alert">(เงินไม่พออัปเกรด)</span>' : ''}
        </div>

        <div class="modal-actions">
          <button id="upgradeBtn" class="btn btn-primary" ${!canAfford ? 'disabled' : ''}>
            🔨 อัปเกรดทันที (${tile.upgradeCost.toLocaleString()} เหรียญ)
          </button>
          <button id="skipUpgradeBtn" class="btn btn-secondary">
            ไว้คราวหน้า
          </button>
        </div>
      </div>
    `;
    this.show(html);

    const upBtn = document.getElementById('upgradeBtn');
    if (upBtn && canAfford) {
      upBtn.onclick = () => {
        this.hide();
        callback(true);
      };
    }
    document.getElementById('skipUpgradeBtn').onclick = () => {
      this.hide();
      callback(false);
    };
  }

  showTakeoverProperty(player, owner, tile, takeoverCost, currentLevel, callback) {
    const group = GAME_DATA.COLOR_GROUPS[tile.group];
    const canAfford = player.money >= takeoverCost;
    const stars = '★'.repeat(currentLevel);
    const rent = window.chillGame.getRent(tile);

    const html = `
      <div class="modal-card property-card" style="border-top: 8px solid ${group.color};">
        <div class="property-badge" style="background: ${group.badgeBg}; color: ${group.badgeText};">
          ${group.icon} ${group.name}
        </div>
        <div class="property-header">
          <div class="property-icon">${tile.icon}</div>
          <h2 class="property-name">${tile.isWonder ? '👑 แย่งชิงสิ่งมหัศจรรย์ (Takeover)' : '🏨 ยื่นซื้อต่อกิจการ (Takeover)'}</h2>
          <p class="property-sub">${tile.isWonder ? `สิ่งมหัศจรรย์ [ <strong>${tile.name}</strong> ] ปัจจุบันครอบครองโดย ${owner.avatar} ${owner.name}` : `อสังหาฯ [ <strong>${tile.name}</strong> ] ปัจจุบันเป็นของ ${owner.avatar} ${owner.name} (${stars} ระดับ ${currentLevel}/3)`}</p>
        </div>

        <div class="property-details">
          <div class="detail-row">
            <span>ราคาซื้อต่อ (1.5x ของทุนสร้าง):</span>
            <strong class="cost-text" style="color: #dc2626;">${takeoverCost.toLocaleString()} เหรียญ</strong>
          </div>
          <div class="detail-row">
            <span>ค่าบริการที่จะได้รับต่อครั้ง:</span>
            <strong style="color: #059669;">${rent.toLocaleString()} เหรียญ</strong>
          </div>
          ${tile.isWonder ? '' : `
          <div class="detail-row">
            <span>ระดับอาคาร:</span>
            <span>ระดับ ${currentLevel} จาก 3 (สามารถอัปเกรดต่อได้เมื่อเดินมาลงอีก)</span>
          </div>`}
          <div class="set-bonus-hint" style="background: ${tile.isWonder ? '#fef3c7' : '#e0f2fe'}; color: ${tile.isWonder ? '#92400e' : '#0369a1'}; border: 1px solid ${tile.isWonder ? '#fde68a' : '#bae6fd'};">
            ${tile.isWonder ? '👑 <strong>กติกาพิเศษ:</strong> แย่งชิงสิ่งมหัศจรรย์นี้มาครอง! หากสะสมครบ 8 แห่งบนเกาะ <strong>จะชนะการแข่งขันทันที!</strong>' : `💡 หากซื้อต่อสำเร็จ เงินค่าซื้อต่อจะมอบให้กับ ${owner.avatar} ${owner.name} ทันที!`}
          </div>
        </div>

        <div class="player-balance-info">
          เงินในกระเป๋าของคุณ: <strong>${player.money.toLocaleString()} เหรียญ</strong>
          ${!canAfford ? '<span class="insufficient-alert">(เงินไม่พอซื้อต่อกิจการ)</span>' : ''}
        </div>

        <div class="modal-actions">
          <button id="takeoverConfirmBtn" class="btn btn-primary" ${!canAfford ? 'disabled' : ''} style="background: linear-gradient(135deg, #059669, #047857);">
            💰 ซื้อต่อกิจการทันที (${takeoverCost.toLocaleString()} เหรียญ)
          </button>
          <button id="takeoverSkipBtn" class="btn btn-secondary">
            ไม่ซื้อต่อ / ข้ามไป
          </button>
        </div>
      </div>
    `;
    this.show(html);

    const confirmBtn = document.getElementById('takeoverConfirmBtn');
    if (confirmBtn && canAfford) {
      confirmBtn.onclick = () => {
        this.hide();
        callback(true);
      };
    }
    document.getElementById('takeoverSkipBtn').onclick = () => {
      this.hide();
      callback(false);
    };
  }

  showCard(card, callback) {
    const html = `
      <div class="modal-card card-popup">
        <div class="card-icon-big">${card.icon}</div>
        <span class="card-tag">💌 การ์ดลมหายใจเกาะ</span>
        <h2 class="card-title">${card.title}</h2>
        <p class="card-text">${card.desc}</p>
        <div class="modal-actions">
          <button id="cardOkBtn" class="btn btn-primary">รับทราบและดำเนินการ ✨</button>
        </div>
      </div>
    `;
    this.show(html);

    document.getElementById('cardOkBtn').onclick = () => {
      this.hide();
      if (callback) callback();
    };
  }

  showLuckyWheel(player, callback) {
    const segments = GAME_DATA.WHEEL_SEGMENTS;
    const html = `
      <div class="modal-card wheel-modal">
        <h2>🎡 วงล้อเสี่ยงทายมหาสนุก</h2>
        <p class="modal-desc">หมุนวงล้อลุ้นรับรางวัลชิวๆ ประจำวัน!</p>
        
        <div class="wheel-wrapper">
          <div class="wheel-pointer">▼</div>
          <canvas id="wheelCanvas" width="300" height="300"></canvas>
        </div>

        <div class="modal-actions">
          <button id="spinWheelBtn" class="btn btn-primary btn-large">
            🎯 กดหมุนวงล้อ!
          </button>
        </div>
      </div>
    `;
    this.show(html);

    const canvas = document.getElementById('wheelCanvas');
    const ctx = canvas.getContext('2d');
    const center = canvas.width / 2;
    const radius = center - 10;
    const arc = (2 * Math.PI) / segments.length;

    let currentAngle = 0;
    const drawWheel = (angle) => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      segments.forEach((seg, i) => {
        const segAngle = angle + i * arc;
        ctx.beginPath();
        ctx.fillStyle = seg.color;
        ctx.moveTo(center, center);
        ctx.arc(center, center, radius, segAngle, segAngle + arc);
        ctx.lineTo(center, center);
        ctx.fill();
        ctx.stroke();

        ctx.save();
        ctx.translate(center, center);
        ctx.rotate(segAngle + arc / 2);
        ctx.textAlign = 'right';
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 13px Sarabun, sans-serif';
        ctx.shadowColor = 'rgba(0,0,0,0.5)';
        ctx.shadowBlur = 4;
        ctx.fillText(seg.label, radius - 15, 5);
        ctx.restore();
      });

      ctx.beginPath();
      ctx.arc(center, center, 24, 0, 2 * Math.PI);
      ctx.fillStyle = '#1e293b';
      ctx.fill();
      ctx.lineWidth = 3;
      ctx.strokeStyle = '#ffffff';
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.font = '16px Sarabun';
      ctx.textAlign = 'center';
      ctx.fillText('🎁', center, center + 6);
    };

    drawWheel(0);

    const spinBtn = document.getElementById('spinWheelBtn');
    spinBtn.onclick = () => {
      spinBtn.disabled = true;
      spinBtn.innerText = 'กำลังหมุน...';

      const winIndex = Math.floor(Math.random() * segments.length);
      const chosenPrize = segments[winIndex];

      const fullRotations = 5 + Math.floor(Math.random() * 3);
      const targetSegmentCenter = winIndex * arc + arc / 2;
      const targetAngle = (fullRotations * 2 * Math.PI) + (1.5 * Math.PI - targetSegmentCenter);

      const duration = 3200;
      const start = performance.now();
      let lastTickAngle = 0;

      const animateWheel = (now) => {
        const elapsed = now - start;
        const progress = Math.min(elapsed / duration, 1);
        const easeOut = 1 - Math.pow(1 - progress, 3);
        currentAngle = easeOut * targetAngle;

        drawWheel(currentAngle);

        if (Math.abs(currentAngle - lastTickAngle) > arc) {
          window.soundManager.playWheelTick();
          lastTickAngle = currentAngle;
        }

        if (progress < 1) {
          requestAnimationFrame(animateWheel);
        } else {
          window.soundManager.playWheelWin();
          spinBtn.innerText = `ยินดีด้วย! ได้รับ: ${chosenPrize.label}`;
          setTimeout(() => {
            this.hide();
            callback(chosenPrize, winIndex);
          }, 1200);
        }
      };

      requestAnimationFrame(animateWheel);
    };
  }

  showVictory(winner, reason, netWorth) {
    if (window.confetti) {
      window.confetti.burst(window.innerWidth / 2, window.innerHeight / 2, 160);
      setTimeout(() => window.confetti.burst(window.innerWidth / 3, window.innerHeight / 3, 100), 400);
      setTimeout(() => window.confetti.burst((window.innerWidth * 2) / 3, window.innerHeight / 3, 100), 700);
    }

    const html = `
      <div class="modal-card victory-card">
        <div class="victory-trophy">🏆</div>
        <h1 class="victory-title">ยินดีด้วยกับชัยชนะ!</h1>
        <div class="winner-avatar-big">${winner.avatar}</div>
        <h2 class="winner-name">${winner.name}</h2>
        <p class="victory-reason">${reason}</p>
        
        <div class="victory-stats">
          <div>มูลค่าทรัพย์สินสุทธิ: <strong>${netWorth.toLocaleString()} เหรียญ</strong></div>
          <div>เงินสดคงเหลือ: <strong>${winner.money.toLocaleString()} เหรียญ</strong></div>
        </div>

        <div class="modal-actions" style="margin-top: 24px;">
          <button id="playAgainBtn" class="btn btn-primary btn-large">
            🔄 เริ่มเล่นใหม่อีกครั้ง
          </button>
        </div>
      </div>
    `;
    this.show(html);

    document.getElementById('playAgainBtn').onclick = () => {
      this.hide();
      openNewGameModal();
    };
  }
}

// UI Render Helpers
function renderBoardTiles() {
  const boardEl = document.getElementById('tilesContainer');
  if (!boardEl) return;
  boardEl.innerHTML = '';

  GAME_DATA.BOARD_TILES.forEach(tile => {
    const tileEl = document.createElement('div');
    tileEl.id = `tile-${tile.id}`;
    tileEl.className = `board-tile tile-${tile.type}`;
    tileEl.style.gridRow = `${tile.row + 1}`;
    tileEl.style.gridColumn = `${tile.col + 1}`;

    let headerHtml = '';
    let contentHtml = '';
    let badgeHtml = '';

    if (tile.isWonder) {
      tileEl.className = `board-tile tile-property tile-wonder`;
      const ownerId = window.chillGame.propertyOwners[tile.id];

      headerHtml = `<div class="tile-color-bar wonder-bar"></div>`;

      if (ownerId !== undefined) {
        const owner = window.chillGame.players[ownerId];
        badgeHtml = `
          <div class="owner-badge wonder-owner-badge" style="background: ${owner.color};" title="ผู้ครอบครอง: ${owner.name}">
            ${owner.avatar} <span class="stars">👑</span>
          </div>
        `;
      }

      contentHtml = `
        <div class="tile-icon">${tile.icon}</div>
        <div class="tile-name special">${tile.name}</div>
        <div class="tile-price wonder-price">${tile.price.toLocaleString()} ฿</div>
        <div class="tile-subtitle wonder-tag">🌟 สิ่งมหัศจรรย์</div>
      `;
    } else if (tile.type === 'property') {
      const group = GAME_DATA.COLOR_GROUPS[tile.group];
      const ownerId = window.chillGame.propertyOwners[tile.id];
      const level = window.chillGame.propertyLevels[tile.id] || 0;

      headerHtml = `<div class="tile-color-bar" style="background: ${group.color};"></div>`;

      if (ownerId !== undefined) {
        const owner = window.chillGame.players[ownerId];
        const stars = '★'.repeat(level);
        badgeHtml = `
          <div class="owner-badge" style="background: ${owner.color};" title="เจ้าของ: ${owner.name} (${stars})">
            ${owner.avatar} <span class="stars">${stars}</span>
          </div>
        `;
      }

      contentHtml = `
        <div class="tile-icon">${tile.icon}</div>
        <div class="tile-name">${tile.name}</div>
        <div class="tile-price">${tile.price.toLocaleString()} ฿</div>
      `;
    } else {
      contentHtml = `
        <div class="tile-icon-special">${tile.icon}</div>
        <div class="tile-name special">${tile.name}</div>
        ${tile.subtitle ? `<div class="tile-subtitle">${tile.subtitle}</div>` : ''}
      `;
    }

    tileEl.innerHTML = `
      ${headerHtml}
      ${badgeHtml}
      <div class="tile-content">
        ${contentHtml}
      </div>
      <div class="token-container" id="tile-tokens-${tile.id}"></div>
    `;

    boardEl.appendChild(tileEl);
  });

  renderPlayerTokens();
}

function renderPlayerTokens() {
  document.querySelectorAll('.token-container').forEach(c => (c.innerHTML = ''));

  window.chillGame.players.forEach(player => {
    if (player.bankrupt) return;
    const tokenContainer = document.getElementById(`tile-tokens-${player.position}`);
    if (tokenContainer) {
      const token = document.createElement('div');
      token.className = `player-token ${window.chillGame.getCurrentPlayer().id === player.id ? 'active-token' : ''}`;
      token.style.borderColor = player.color;
      token.innerHTML = `<span class="token-emoji">${player.avatar}</span>`;
      token.title = `${player.name} (${player.money.toLocaleString()} ฿)`;
      tokenContainer.appendChild(token);
    }
  });
}

function renderUI() {
  const game = window.chillGame;
  const currentP = game.getCurrentPlayer();

  const turnBanner = document.getElementById('turnBanner');
  if (turnBanner && currentP) {
    turnBanner.innerHTML = `
      <div class="banner-avatar">${currentP.avatar}</div>
      <div class="banner-text">
        <span class="banner-sub">เทิร์นที่ ${game.turnCount}</span>
        <h3 class="banner-title" style="color: ${currentP.color};">
          ${currentP.isAi ? `รอบของ ${currentP.name} (AI)` : `ถึงตาของคุณเอก (${currentP.name})`}
        </h3>
      </div>
    `;
  }

  const rollBtn = document.getElementById('rollDiceBtn');
  if (rollBtn) {
    if (game.isRolling) {
      rollBtn.disabled = true;
      rollBtn.classList.add('disabled');
      rollBtn.innerText = currentP.isAi ? '🤖 น้องบอทกำลังเล่น...' : '🎲 กำลังทอยเต๋า...';
    } else {
      rollBtn.disabled = false;
      rollBtn.classList.remove('disabled');
      rollBtn.innerText = currentP.sleepTurns > 0 ? '☕ จัดการสถานะพักผ่อน' : '🎲 ทอยลูกเต๋า (Spacebar)';
    }
  }

  const playersList = document.getElementById('playersList');
  if (playersList) {
    playersList.innerHTML = game.players
      .map(p => {
        const isCurrent = p.id === currentP.id && !game.isGameOver;
        const netWorth = game.calculateNetWorth(p);
        const ownedProperties = GAME_DATA.BOARD_TILES.filter(t => !t.isWonder && game.propertyOwners[t.id] === p.id);
        const ownedWonders = GAME_DATA.BOARD_TILES.filter(t => t.isWonder && game.propertyOwners[t.id] === p.id);
        const lapBonusPct = Math.floor((p.laps || 0) / 10) * 10;

        return `
          <div class="player-card ${isCurrent ? 'current-player-card' : ''} ${p.bankrupt ? 'bankrupt' : ''}" style="border-left: 6px solid ${p.color};">
            <div class="player-card-header">
              <span class="player-avatar-mini">${p.avatar}</span>
              <div class="player-identity">
                <span class="player-name">${p.name} ${p.isAi ? '<small class="bot-badge">AI</small>' : ''}</span>
                <span class="player-status ${p.sleepTurns > 0 ? 'status-sleep' : ''}">
                  ${p.bankrupt ? '💀 หมดตัว' : p.sleepTurns > 0 ? `🛏️ พักผ่อน (${p.sleepTurns})` : '✨ พร้อมลุย'}
                </span>
              </div>
            </div>

            <div class="player-finances">
              <div class="finance-item">
                <span class="fin-label">เงินสด:</span>
                <span class="fin-val cash">${p.money.toLocaleString()} ฿</span>
              </div>
              <div class="finance-item">
                <span class="fin-label">ทรัพย์สินรวม:</span>
                <span class="fin-val worth">${netWorth.toLocaleString()} ฿</span>
              </div>
            </div>

            <div class="player-properties-preview">
              <span class="prop-count">ถือครองบ้าน ${ownedProperties.length} แห่ง:</span>
              <div class="prop-dots">
                ${ownedProperties
                  .map(t => `<span class="prop-dot" style="background: ${GAME_DATA.COLOR_GROUPS[t.group].color};" title="${t.name}"></span>`)
                  .join('')}
              </div>
            </div>

            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 6px; padding: 4px 8px; background: #fffbeb; border-radius: 6px; border: 1px solid #fef08a; font-size: 0.73rem;">
              <span style="color: #b45309; font-weight: 700;">👑 สิ่งมหัศจรรย์:</span>
              <span style="font-weight: 800; color: #d97706;">${ownedWonders.length} / 8 แห่ง ${ownedWonders.length >= 8 ? '🏆' : ''}</span>
            </div>

            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 4px; font-size: 0.73rem; color: #475569; padding: 0 4px;">
              <span>🏁 เดินสะสม:</span>
              <span><strong>${p.laps || 0} รอบ</strong> ${lapBonusPct > 0 ? `<span style="color:#dc2626; font-weight:800; font-size:0.7rem;">(+${lapBonusPct}% ค่าผ่านทาง)</span>` : ''}</span>
            </div>
          </div>
        `;
      })
      .join('');
  }

  const diceArena = document.getElementById('diceArena');
  const badgeText = document.getElementById('diceResultText');
  const isOnline = window.onlineManager && window.onlineManager.isOnline;
  const isMyOnlineTurn = isOnline ? (window.onlineManager.myPlayerId === game.currentPlayerIndex) : true;
  const canRoll = !currentP.isAi && !game.isRolling && !game.isGameOver && isMyOnlineTurn;

  if (rollBtn) {
    if (currentP.isAi || game.isRolling || game.isGameOver || (isOnline && !isMyOnlineTurn)) {
      rollBtn.disabled = true;
      rollBtn.classList.add('disabled');
      if (game.isRolling) {
        rollBtn.innerText = '🎲 กำลังทอยเต๋า...';
      } else if (currentP.isAi) {
        rollBtn.innerText = '🤖 น้องบอทกำลังเล่น...';
      } else if (isOnline && !isMyOnlineTurn) {
        rollBtn.innerText = `⏳ รอตาของ ${currentP.name}...`;
      }
    } else {
      rollBtn.disabled = false;
      rollBtn.classList.remove('disabled');
      rollBtn.innerText = currentP.sleepTurns > 0 ? '☕ จัดการสถานะพักผ่อน' : '🎲 ทอยลูกเต๋า (Spacebar)';
    }
  }

  if (diceArena) {
    if (canRoll) {
      diceArena.classList.add('ready-to-roll');
      if (badgeText && !game.isRolling) {
        badgeText.innerHTML = currentP.sleepTurns > 0 ? '☕ แตะเพื่อจัดการสถานะพักผ่อน' : '🎲 กดที่ลูกเต๋าเพื่อทอย! (Spacebar)';
      }
    } else {
      diceArena.classList.remove('ready-to-roll');
      if (badgeText && !game.isRolling) {
        if (isOnline && !isMyOnlineTurn) {
          badgeText.innerHTML = `🌐 ตาของ ${currentP.name} (ออนไลน์)...`;
        } else if (currentP && currentP.isAi) {
          badgeText.innerHTML = `🤖 ${currentP.name} กำลังคิดวางแผน...`;
        }
      }
    }
  }
}

function renderLogs() {
  const logContainer = document.getElementById('activityLog');
  if (!logContainer) return;
  const game = window.chillGame;

  logContainer.innerHTML = game.logs
    .map(log => `
      <div class="log-entry log-${log.type}">
        <span class="log-time">${log.time}</span>
        <span class="log-msg">${log.message}</span>
      </div>
    `)
    .join('');
}

// 2D Dice Animation & Combined Score Display
function animateDiceRoll(d1, d2, callback) {
  const cube1 = document.getElementById('diceCube1');
  const cube2 = document.getElementById('diceCube2');
  const totalBox = document.getElementById('diceTotalBox');
  const totalVal = document.getElementById('diceTotalVal');
  const totalDetail = document.getElementById('diceTotalDetail');
  const badge = document.getElementById('diceResultBadge');
  const badgeText = document.getElementById('diceResultText');

  if (!cube1 || !cube2) {
    if (callback) callback();
    return;
  }

  const isFast = window.chillGame && window.chillGame.speedMode;
  const rollDuration = isFast ? 350 : 650;

  // Add 2D rolling animation
  cube1.classList.add('rolling');
  cube2.classList.add('rolling');
  if (totalBox) totalBox.classList.remove('highlight');
  if (badge) badge.classList.remove('highlight');
  if (badgeText) badgeText.innerText = '🎲 กำลังทอยลูกเต๋า...';

  // Rapidly shuffle 2D face numbers while rolling
  const shuffleTimer = setInterval(() => {
    const r1 = Math.floor(Math.random() * 6) + 1;
    const r2 = Math.floor(Math.random() * 6) + 1;
    cube1.setAttribute('data-val', r1);
    cube2.setAttribute('data-val', r2);
    if (totalVal) totalVal.innerText = r1 + r2;
    if (totalDetail) totalDetail.innerText = `(${r1} + ${r2})`;
  }, 60);

  setTimeout(() => {
    clearInterval(shuffleTimer);
    cube1.classList.remove('rolling');
    cube2.classList.remove('rolling');

    // Set actual rolled values
    cube1.setAttribute('data-val', d1);
    cube2.setAttribute('data-val', d2);

    const sum = d1 + d2;
    if (totalVal) totalVal.innerText = sum;
    if (totalDetail) totalDetail.innerText = `(${d1} + ${d2})`;
    if (totalBox) totalBox.classList.add('highlight');

    // Announce result badge
    if (badge && badgeText) {
      badge.classList.add('highlight');
      badgeText.innerHTML = `🎲 ได้แต้มรวม: <strong>${sum} แต้ม (${d1} + ${d2})</strong>`;
    }

    const postDelay = isFast ? 100 : 250;
    setTimeout(() => {
      if (callback) callback();
    }, postDelay);
  }, rollDuration);
}

function openNewGameModal() {
  const html = `
    <div class="modal-card new-game-card">
      <h2 class="modal-title">🏝️ เริ่มต้นการเดินทางบนเกาะใหม่</h2>
      <p class="modal-desc">เลือกโหมดการเล่นที่ต้องการเพื่อความเพลิดเพลิน:</p>

      <div class="game-mode-options">
        <label class="mode-radio">
          <input type="radio" name="gameMode" value="vs_bot" checked>
          <div class="mode-box">
            <span class="mode-icon">🤖</span>
            <strong>เล่นคนเดียวกับ AI</strong>
            <small>คุณเอก 🐱 ปะทะ น้องส้ม 🦊 (AI แสนฉลาด)</small>
          </div>
        </label>

        <label class="mode-radio">
          <input type="radio" name="gameMode" value="2p_local">
          <div class="mode-box">
            <span class="mode-icon">👥</span>
            <strong>เล่นด้วยกัน 2 คน (Pass & Play)</strong>
            <small>คุณเอก 🐱 ปะทะ เพื่อนรู้ใจ 🐶</small>
          </div>
        </label>

        <label class="mode-radio">
          <input type="radio" name="gameMode" value="3p_bot">
          <div class="mode-box">
            <span class="mode-icon">🏝️</span>
            <strong>แก๊งค์ 3 คนสุดคึกคัก</strong>
            <small>คุณเอก + น้องส้ม (AI) + น้องหมอก (AI)</small>
          </div>
        </label>

        <label class="mode-radio">
          <input type="radio" name="gameMode" value="online_room">
          <div class="mode-box" style="border-color: #3b82f6;">
            <span class="mode-icon">🌐</span>
            <strong style="color: #1d4ed8;">เล่นออนไลน์กับเพื่อน (Online Room)</strong>
            <small>สร้างห้องและแชร์รหัสให้เพื่อนเข้าเล่นผ่านมือถือ/คอมฯ</small>
          </div>
        </label>
      </div>

      <div class="modal-actions" style="margin-top: 24px;">
        <button id="startGameBtn" class="btn btn-primary btn-large">
          🚀 เริ่มเล่นเลย!
        </button>
      </div>
    </div>
  `;
  window.modalManager.show(html);

  document.getElementById('startGameBtn').onclick = () => {
    const selectedMode = document.querySelector('input[name="gameMode"]:checked').value;
    window.modalManager.hide();

    if (selectedMode === 'online_room') {
      window.onlineManager.openLobbyModal();
      return;
    }

    // If starting a local game, ensure online mode is disconnected
    if (window.onlineManager) {
      window.onlineManager.disconnect();
    }

    let configs = [];
    if (selectedMode === 'vs_bot') {
      configs = [
        { name: 'คุณเอก', avatar: '🐱', color: '#0284c7', isAi: false },
        { name: 'น้องส้ม', avatar: '🦊', color: '#d97706', isAi: true }
      ];
    } else if (selectedMode === '2p_local') {
      configs = [
        { name: 'คุณเอก', avatar: '🐱', color: '#0284c7', isAi: false },
        { name: 'เพื่อนชิวๆ', avatar: '🐶', color: '#059669', isAi: false }
      ];
    } else if (selectedMode === '3p_bot') {
      configs = [
        { name: 'คุณเอก', avatar: '🐱', color: '#0284c7', isAi: false },
        { name: 'น้องส้ม', avatar: '🦊', color: '#d97706', isAi: true },
        { name: 'น้องหมอก', avatar: '🐼', color: '#7c3aed', isAi: true }
      ];
    }

    window.chillGame.init(configs);
  };
}

function openHelpModal() {
  const html = `
    <div class="modal-card rules-card">
      <h2 class="modal-title">📖 กติกาและคู่มือท่องเที่ยวเกาะ</h2>
      <div class="rules-content">
        <h4>🎯 เงื่อนไขการชนะเกม (Win Conditions):</h4>
        <ul>
          <li><strong>1. ล้มละลายคู่แข่ง:</strong> ทำให้คู่แข่งทุกคนเงินหมดกระเป๋าจนล้มละลาย!</li>
          <li><strong>2. 👑 มหาครอบครอง 8 สิ่งมหัศจรรย์:</strong> ครอบครองสิ่งมหัศจรรย์แห่งเกาะครบทั้ง 8 แห่งพร้อมกัน <strong>จะชนะการแข่งขันทันที!</strong></li>
        </ul>

        <h4>👑 สิ่งมหัศจรรย์ 8 แห่งบนเกาะ:</h4>
        <p>ช่องพิเศษสีทอง 8 ช่องทั่วเกาะ <strong>สร้างได้แค่ครั้งเดียว (ไม่มีการอัปเกรด)</strong> หากเดินตกของคนอื่น สามารถทุ่มเงินซื้อต่อได้ (1.5x) เพื่อแย่งชิงมาสะสมให้ครบ 8 แห่งเพื่อคว้าชัยชนะทันที!</p>

        <h4>🔥 กฎความเดือดเมื่อเดินครบ 10 รอบ (+10% ค่าผ่านทาง):</h4>
        <p>เมื่อผู้เล่นคนใดเดินวนรอบเกาะครบทุก <strong>10 รอบ</strong> ค่าผ่านทางของอสังหาริมทรัพย์ทุกแห่งของผู้เล่นคนนั้นจะได้รับโบนัส <strong>เพิ่มขึ้น +10% อัตโนมัติ</strong> ยิ่งเกมนาน ค่าผ่านทางยิ่งโหด!</p>

        <h4>🎲 การทอยลูกเต๋า 2 มิติ & แต้มรวม:</h4>
        <p>ลูกเต๋า 2 มิติ 2 ลูกอยู่ใจกลางกระดาน พร้อมกรอบแสดง <strong>แต้มรวมขนาดใหญ่</strong> สามารถแตะที่ลูกเต๋าตรงกลางกระดาน หรือกดปุ่มทอยเต๋า หรือกด <strong>Spacebar</strong> ในเทิร์นตนเองเพื่อทอยได้ทันที!</p>

        <h4>🏰 การอัปเกรดและซื้อต่อบ้านทั่วไป:</h4>
        <ul>
          <li><strong>อัปเกรดได้สูงสุด 3 ระดับ:</strong> เริ่มจาก ระดับ 1 (★) ➔ ระดับ 2 ดีลักซ์ (★★) ➔ ระดับ 3 รีสอร์ตแลนด์มาร์ก (★★★) ค่าผ่านทางจะเพิ่มขึ้นเรื่อยๆ</li>
          <li><strong>ซื้อต่อกิจการได้:</strong> หากเดินไปตกช่องบ้านของคนอื่น (ที่ยังไม่ตันเลเวล 3) สามารถยื่นซื้อต่อกิจการได้ในราคา 1.5 เท่าของทุนสร้าง</li>
          <li><strong>โบนัสคุมโซนครบสี:</strong> ครอบครองอสังหาฯ ครบทั้ง 3 แห่งในโซนสีเดียวกัน ค่าผ่านทางเพิ่มเป็น 2 เท่า!</li>
        </ul>

        <h4>🏝️ ช่องพิเศษอื่นๆ บนเกาะ:</h4>
        <ul>
          <li><strong>🚢 ท่าเรือชิวๆ (Start):</strong> เดินผ่านรับงบพักผ่อน 2,000 เหรียญ (ถ้าลงตรงช่องพอดี รับโบนัสเพิ่ม 1,000 เหรียญ!)</li>
          <li><strong>🎡 วงล้อเสี่ยงทาย & ตู้กาชาปอง:</strong> ลุ้นรับเงินรางวัลใหญ่ หรือระวัง <strong>โดนติดหนี้</strong> และ <strong>โดนโจรขโมยเงิน</strong>!</li>
          <li><strong>💌 การ์ดลมหายใจเกาะ:</strong> จั่วการ์ดสุ่มโชคชะตา มีทั้งเงินปันผล โดนปล้น วาร์ป และเหตุการณ์สนุกๆ</li>
          <li><strong>🧘 สวนสมาธิเซน:</strong> รับเงินพลังบวก 500 เหรียญฟรี</li>
          <li><strong>🚤 ท่าสปีดโบ๊ท:</strong> วาร์ปข้ามไปยังทางลัดจักรยานอีกฟากเกาะทันที</li>
          <li><strong>🛏️ วิลล่านอนเพลิน & กระท่อมฝนตก:</strong> พักผ่อน 1 เทิร์น (หรือจ่ายค่ากาแฟ 300 เหรียญเพื่อตื่นทันที)</li>
        </ul>
      </div>
      <div class="modal-actions">
        <button id="closeRulesBtn" class="btn btn-primary">เข้าใจแล้ว ลุยเลย! 🏖️</button>
      </div>
    </div>
  `;
  window.modalManager.show(html);
  document.getElementById('closeRulesBtn').onclick = () => window.modalManager.hide();
}

// Initialize Application
document.addEventListener('DOMContentLoaded', () => {
  window.confetti = new ConfettiCannon(document.getElementById('confettiCanvas'));
  window.modalManager = new ModalManager();

  window.renderBoardTiles = renderBoardTiles;
  window.renderPlayerTokens = renderPlayerTokens;
  window.renderUI = renderUI;
  window.renderLogs = renderLogs;
  window.animateDiceRoll = animateDiceRoll;

  const soundBtn = document.getElementById('soundToggleBtn');
  if (soundBtn) {
    soundBtn.onclick = () => {
      const active = window.soundManager.toggleSound();
      soundBtn.innerHTML = active ? '🔊 เอฟเฟกต์เสียง: เปิด' : '🔇 เอฟเฟกต์เสียง: ปิด';
    };
  }

  const bgmBtn = document.getElementById('bgmToggleBtn');
  if (bgmBtn) {
    bgmBtn.onclick = () => {
      const active = window.soundManager.toggleBgm();
      bgmBtn.innerHTML = active ? '🎵 เพลง Lo-Fi: เปิด' : '🎵 เพลง Lo-Fi: ปิด';
      bgmBtn.classList.toggle('active-bgm', active);
    };
  }

  const speedBtn = document.getElementById('speedToggleBtn');
  if (speedBtn) {
    speedBtn.onclick = () => {
      window.chillGame.speedMode = !window.chillGame.speedMode;
      speedBtn.innerHTML = window.chillGame.speedMode ? '⚡ สปีด: เร็ว' : '🐢 สปีด: ชิวๆ';
    };
  }

  const triggerRollIfAllowed = () => {
    const isOnline = window.onlineManager && window.onlineManager.isOnline;
    const isMyOnlineTurn = isOnline ? (window.onlineManager.myPlayerId === window.chillGame.currentPlayerIndex) : true;
    const currentP = window.chillGame.getCurrentPlayer();
    if (currentP && !currentP.isAi && !window.chillGame.isRolling && !window.chillGame.isGameOver && isMyOnlineTurn) {
      window.chillGame.rollDice();
    }
  };

  const rollBtn = document.getElementById('rollDiceBtn');
  if (rollBtn) {
    rollBtn.onclick = triggerRollIfAllowed;
  }

  // Allow clicking anywhere inside the Dice Arena or directly on the 3D dice cubes to roll
  const diceArena = document.getElementById('diceArena');
  if (diceArena) {
    diceArena.onclick = triggerRollIfAllowed;
  }
  const cube1 = document.getElementById('diceCube1');
  if (cube1) cube1.onclick = triggerRollIfAllowed;
  const cube2 = document.getElementById('diceCube2');
  if (cube2) cube2.onclick = triggerRollIfAllowed;

  window.addEventListener('keydown', (e) => {
    if (e.code === 'Space' && !window.modalManager.overlay.classList.contains('active')) {
      e.preventDefault();
      triggerRollIfAllowed();
    }
  });

  const onlineLobbyBtn = document.getElementById('onlineLobbyBtn');
  if (onlineLobbyBtn) {
    onlineLobbyBtn.onclick = () => window.onlineManager.openLobbyModal();
  }

  document.getElementById('newGameBtn').onclick = openNewGameModal;
  document.getElementById('rulesBtn').onclick = openHelpModal;

  // Auto-open lobby if ?room=... param is present
  const urlParams = new URLSearchParams(window.location.search);
  const roomParam = urlParams.get('room');
  if (roomParam) {
    setTimeout(() => {
      window.onlineManager.openLobbyModal(roomParam.toUpperCase());
    }, 400);
  }

  // Start Default Game: คุณเอก vs น้องส้ม (AI)
  window.chillGame.init([
    { name: 'คุณเอก', avatar: '🐱', color: '#0284c7', isAi: false },
    { name: 'น้องส้ม', avatar: '🦊', color: '#d97706', isAi: true }
  ]);
});
