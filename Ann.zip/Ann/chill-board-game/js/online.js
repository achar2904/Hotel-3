// ==========================================================================
// Online Multiplayer Controller - Rooms, SSE Real-time Sync & Actions
// ==========================================================================

class OnlineManager {
  constructor() {
    this.isOnline = false;
    this.roomId = null;
    this.myPlayerId = 0; // 0 for host, 1 for guest
    this.eventSource = null;
    this.isHost = false;
    this.serverUrl = window.location.origin;
  }

  // Create a new online room
  async createRoom(hostName = 'คุณเอก', avatar = '🐱') {
    try {
      const res = await fetch(`${this.serverUrl}/api/room/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: hostName, avatar })
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.error || 'สร้างห้องไม่สำเร็จ');

      this.isOnline = true;
      this.roomId = data.roomId;
      this.myPlayerId = 0;
      this.isHost = true;

      this.connectStream(this.roomId, 0);
      this.showWaitingModal(this.roomId);

      return data;
    } catch (err) {
      alert(`เกิดข้อผิดพลาดในการสร้างห้อง: ${err.message}`);
      throw err;
    }
  }

  // Join an existing room
  async joinRoom(roomId, playerName = 'เพื่อนชิวๆ', avatar = '🐶') {
    try {
      const res = await fetch(`${this.serverUrl}/api/room/join`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ roomId, name: playerName, avatar })
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.error || 'เข้าร่วมห้องไม่สำเร็จ');

      this.isOnline = true;
      this.roomId = data.roomId;
      this.myPlayerId = data.player.id;
      this.isHost = false;

      this.connectStream(this.roomId, this.myPlayerId);

      // Start game on guest device with all joined players
      window.modalManager.hide();
      window.chillGame.init(data.allPlayers);
      window.chillGame.log(`🌐 [ระบบออนไลน์] คุณเข้าร่วมห้อง [ ${this.roomId} ] สำเร็จแล้ว!`, 'system');

      return data;
    } catch (err) {
      alert(`ไม่สามารถเข้าร่วมห้องได้: ${err.message}`);
      throw err;
    }
  }

  // Connect to SSE stream
  connectStream(roomId, playerId) {
    if (this.eventSource) {
      this.eventSource.close();
    }

    this.eventSource = new EventSource(`${this.serverUrl}/api/room/stream?roomId=${roomId}&playerId=${playerId}`);

    this.eventSource.addEventListener('player_joined', (e) => {
      const data = JSON.parse(e.data);
      if (this.isHost) {
        window.modalManager.hide();
        // Start game on host device
        window.chillGame.init(data.allPlayers);
        window.chillGame.log(`🎉 [ระบบออนไลน์] ${data.player.avatar} ${data.player.name} เข้าร่วมห้องแล้ว! เริ่มต้นการแข่งขันได้!`, 'event');

        // Broadcast START_GAME to guest
        this.sendAction({
          type: 'START_GAME',
          players: data.allPlayers
        });
      }
    });

    this.eventSource.addEventListener('game_action', (e) => {
      const payload = JSON.parse(e.data);
      if (payload.fromPlayerId !== this.myPlayerId) {
        this.handleRemoteAction(payload.action);
      }
    });

    this.eventSource.onerror = () => {
      // Reconnection handled automatically by EventSource
    };
  }

  // Broadcast action to server
  async sendAction(action) {
    if (!this.isOnline || !this.roomId) return;
    try {
      await fetch(`${this.serverUrl}/api/room/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          roomId: this.roomId,
          playerId: this.myPlayerId,
          action
        })
      });
    } catch (err) {
      console.error('Send action failed:', err);
    }
  }

  // Execute remote action on this client
  handleRemoteAction(action) {
    const game = window.chillGame;
    if (!game) return;

    switch (action.type) {
      case 'START_GAME':
        window.modalManager.hide();
        game.init(action.players);
        game.log(`🌐 [ระบบออนไลน์] เริ่มเกมพร้อมกันเรียบร้อย!`, 'system');
        break;

      case 'ROLL_DICE':
        game.isRolling = true;
        window.soundManager.playDiceRoll();
        if (window.animateDiceRoll) {
          window.animateDiceRoll(action.dice1, action.dice2, () => {
            const player = game.players[action.playerId];
            game.log(`${player.avatar} ${player.name} ทอยเต๋าได้ ${action.dice1} + ${action.dice2} = [ ${action.totalSteps} แต้ม ]`, 'roll');
            game.movePlayerStepByStep(player, action.totalSteps);
          });
        }
        break;

      case 'BUY_PROPERTY': {
        const p = game.players[action.playerId];
        const tile = GAME_DATA.BOARD_TILES[action.tileId];
        game.buyProperty(p, tile, true);
        game.checkWinOrNextTurn();
        break;
      }

      case 'UPGRADE_PROPERTY': {
        const p = game.players[action.playerId];
        const tile = GAME_DATA.BOARD_TILES[action.tileId];
        game.upgradeProperty(p, tile, true);
        game.checkWinOrNextTurn();
        break;
      }

      case 'TAKEOVER_PROPERTY': {
        const buyer = game.players[action.buyerId];
        const prevOwner = game.players[action.prevOwnerId];
        const tile = GAME_DATA.BOARD_TILES[action.tileId];
        game.takeoverProperty(buyer, prevOwner, tile, action.cost, true);
        game.checkWinOrNextTurn();
        break;
      }

      case 'SKIP_PROPERTY': {
        const p = game.players[action.playerId];
        const tile = GAME_DATA.BOARD_TILES[action.tileId];
        game.log(`${p.avatar} ${p.name} เลือกที่จะข้าม ไม่ดำเนินการกับ ${tile ? tile.name : 'ที่ดิน'}`, 'chill');
        game.checkWinOrNextTurn();
        break;
      }

      case 'DRAW_CARD': {
        const p = game.players[action.playerId];
        game.handleCardTile(p, action.cardIndex);
        break;
      }

      case 'LUCKY_WHEEL_RESULT': {
        const p = game.players[action.playerId];
        game.handleMinigameTile(p, action.prizeIndex);
        break;
      }

      case 'SLEEP_ACTION': {
        const p = game.players[action.playerId];
        if (action.paid) {
          p.money -= 300;
          p.sleepTurns = 0;
          game.log(`☕ ${p.avatar} ${p.name} จ่าย 300 เหรียญค่ากาแฟตื่นตัว พร้อมเดินต่อ!`, 'event');
        } else {
          p.sleepTurns--;
          game.log(`😴 ${p.avatar} ${p.name} นอนพักผ่อนต่ออีก 1 เทิร์น`, 'chill');
          game.nextTurn();
        }
        game.updateUI();
        break;
      }
    }
  }

  // Display waiting popup with room code & shareable link
  showWaitingModal(roomId) {
    const shareUrl = `${window.location.origin}${window.location.pathname}?room=${roomId}`;
    const html = `
      <div class="modal-card online-room-card" style="text-align: center;">
        <div style="font-size: 2.8rem; margin-bottom: 6px;">🌐</div>
        <h2 class="modal-title">ห้องออนไลน์สร้างสำเร็จแล้ว!</h2>
        <p class="modal-desc">แชร์รหัสห้องหรือส่งลิงก์ให้เพื่อนเพื่อเข้าเล่นด้วยกัน:</p>

        <div style="background: #f0fdf4; border: 2px dashed #059669; border-radius: 12px; padding: 14px; margin: 16px 0;">
          <span style="font-size: 0.8rem; color: #065f46; font-weight: 600; text-transform: uppercase;">รหัสห้องของคุณ (Room Code)</span>
          <div style="font-size: 2.2rem; font-weight: 800; letter-spacing: 3px; color: #0284c7; margin: 4px 0;" id="roomCodeDisplay">
            ${roomId}
          </div>
          <button id="copyRoomCodeBtn" class="btn btn-secondary" style="font-size: 0.8rem; padding: 4px 12px; margin-top: 4px;">
            📋 คัดลอกรหัสห้อง
          </button>
        </div>

        <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 8px 12px; margin-bottom: 16px; word-break: break-all; font-size: 0.75rem; color: #64748b;">
          <strong>ลิงก์เชิญเพื่อน:</strong><br>
          <span id="shareUrlText">${shareUrl}</span>
        </div>

        <div style="display: flex; align-items: center; justify-content: center; gap: 8px; color: #d97706; font-size: 0.88rem;">
          <span class="loading-spinner" style="display: inline-block; animation: spin 1.5s linear infinite;">⏳</span>
          <span>กำลังรอให้เพื่อนกดเข้าร่วมห้อง...</span>
        </div>

        <div class="modal-actions" style="margin-top: 20px;">
          <button id="cancelRoomBtn" class="btn btn-secondary">
            ยกเลิกและกลับสู่หน้าหลัก
          </button>
        </div>
      </div>
    `;

    window.modalManager.show(html);

    document.getElementById('copyRoomCodeBtn').onclick = () => {
      navigator.clipboard.writeText(roomId).then(() => {
        document.getElementById('copyRoomCodeBtn').innerText = '✅ คัดลอกแล้ว!';
        setTimeout(() => {
          const btn = document.getElementById('copyRoomCodeBtn');
          if (btn) btn.innerText = '📋 คัดลอกรหัสห้อง';
        }, 2000);
      });
    };

    document.getElementById('cancelRoomBtn').onclick = () => {
      this.disconnect();
      window.modalManager.hide();
    };
  }

  // Open Room Selection / Join Modal
  openLobbyModal(prefillRoom = '') {
    const html = `
      <div class="modal-card online-lobby-card">
        <h2 class="modal-title">🌐 เล่นบอร์ดเกมออนไลน์</h2>
        <p class="modal-desc">เลือกสร้างห้องใหม่เพื่อเป็นเจ้าบ้าน หรือใส่รหัสเพื่อเข้าร่วมห้องของเพื่อน:</p>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin: 18px 0;">
          <!-- Create Room Column -->
          <div style="background: #f0fdf4; border: 2px solid #6ee7b7; border-radius: 12px; padding: 16px; text-align: center; display: flex; flex-direction: column; justify-content: space-between;">
            <div>
              <div style="font-size: 2rem;">👑</div>
              <h3 style="color: #065f46; font-size: 1rem; margin: 6px 0;">สร้างห้องใหม่</h3>
              <p style="font-size: 0.76rem; color: #047857;">สร้างห้องแล้วรับรหัส 4 หลัก ส่งให้เพื่อนเข้ามาเล่นด้วยกัน</p>
            </div>
            <button id="btnLobbyCreate" class="btn btn-primary" style="margin-top: 14px; width: 100%;">
              🚀 สร้างห้อง (Host)
            </button>
          </div>

          <!-- Join Room Column -->
          <div style="background: #eff6ff; border: 2px solid #93c5fd; border-radius: 12px; padding: 16px; text-align: center; display: flex; flex-direction: column; justify-content: space-between;">
            <div>
              <div style="font-size: 2rem;">🚪</div>
              <h3 style="color: #1e40af; font-size: 1rem; margin: 6px 0;">เข้าร่วมห้อง</h3>
              <p style="font-size: 0.76rem; color: #1d4ed8;">พิมพ์รหัสห้องที่เพื่อนส่งให้</p>
              <input type="text" id="joinRoomCodeInput" placeholder="เช่น CHILL-A8B9" value="${prefillRoom}" 
                style="width: 100%; padding: 8px 10px; font-size: 0.95rem; font-weight: 700; text-align: center; text-transform: uppercase; border: 2px solid #3b82f6; border-radius: 8px; margin-top: 8px;" />
            </div>
            <button id="btnLobbyJoin" class="btn btn-primary" style="margin-top: 14px; width: 100%; background: #2563eb;">
              🎮 เข้าร่วมห้อง (Join)
            </button>
          </div>
        </div>

        <div class="modal-actions">
          <button id="closeLobbyBtn" class="btn btn-secondary">ปิดหน้าต่าง</button>
        </div>
      </div>
    `;

    window.modalManager.show(html);

    document.getElementById('btnLobbyCreate').onclick = () => {
      this.createRoom('คุณเอก', '🐱');
    };

    document.getElementById('btnLobbyJoin').onclick = () => {
      const code = document.getElementById('joinRoomCodeInput').value.trim();
      if (!code) {
        alert('กรุณากรอกรหัสห้องก่อนกดเข้าร่วมค่ะ');
        return;
      }
      this.joinRoom(code, 'เพื่อนรู้ใจ', '🐶');
    };

    document.getElementById('closeLobbyBtn').onclick = () => {
      window.modalManager.hide();
    };
  }

  // Disconnect
  disconnect() {
    this.isOnline = false;
    this.roomId = null;
    if (this.eventSource) {
      this.eventSource.close();
      this.eventSource = null;
    }
  }
}

window.onlineManager = new OnlineManager();
