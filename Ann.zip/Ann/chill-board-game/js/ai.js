// ==========================================================================
// AI Controller - Smart, Friendly Bot Logic for Chill Island
// ==========================================================================

class BotController {
  constructor(game) {
    this.game = game;
  }

  // Handle AI turn automatically with human-like delays
  handleTurn(player) {
    if (!player.isAi || this.game.isGameOver) return;

    this.game.log(`${player.avatar} ${player.name} กำลังคิดวางแผนอย่างสบายอารมณ์...`, 'system');

    setTimeout(() => {
      if (this.game.isGameOver) return;

      // If player is sleeping / resting
      if (player.sleepTurns > 0) {
        if (player.money >= 1000) {
          this.game.log(`${player.avatar} ${player.name} ยอมจ่ายค่ากาแฟปลุก 300 เหรียญ เพื่อเดินเที่ยวต่อ!`, 'event');
          player.money -= 300;
          player.sleepTurns = 0;
          this.game.updateUI();
          setTimeout(() => this.game.rollDice(), 700);
        } else {
          this.game.log(`${player.avatar} ${player.name} เลือกนอนพักผ่อนจิบชาต่ออีก 1 เทิร์น zZZ`, 'chill');
          player.sleepTurns--;
          this.game.updateUI();
          setTimeout(() => this.game.nextTurn(), 1000);
        }
        return;
      }

      // Roll dice!
      this.game.rollDice();
    }, 900);
  }

  // Decision when landing on unowned property
  decideBuyProperty(player, tile) {
    const cost = tile.price;
    const safetyBuffer = 350;

    // Special Wonder Tiles: High priority because 8 wonders win the game!
    if (tile.isWonder) {
      return player.money >= cost;
    }

    // Check if buying completes a color set
    const groupProperties = BOARD_TILES.filter(t => t.group === tile.group);
    const ownedInGroup = groupProperties.filter(t => this.game.propertyOwners[t.id] === player.id);
    const willCompleteSet = (ownedInGroup.length + 1) === groupProperties.length;

    let shouldBuy = false;

    if (willCompleteSet && player.money >= cost) {
      shouldBuy = true;
    } else if (player.money >= cost + safetyBuffer) {
      shouldBuy = true;
    } else if (player.money >= cost && Math.random() < 0.6) {
      shouldBuy = true;
    }

    return shouldBuy;
  }

  // Decision to upgrade owned property
  decideUpgradeProperty(player, tile) {
    const currentLevel = this.game.propertyLevels[tile.id] || 1;
    if (currentLevel >= 3) return false;

    const cost = tile.upgradeCost;
    if (player.money >= cost + 600) {
      return true;
    }
    return false;
  }

  // Decision to takeover opponent property (only if level < 3)
  decideTakeoverProperty(player, owner, tile, takeoverCost) {
    if (player.money < takeoverCost) return false;

    // Special Wonder Tiles: High strategic value to block opponent or complete 8 wonders
    if (tile.isWonder) {
      const rivalWonders = BOARD_TILES.filter(t => t.isWonder && this.game.propertyOwners[t.id] === owner.id);
      if (rivalWonders.length >= 3) return true; // Block rival who has 3+ wonders!
      return player.money >= takeoverCost + 300;
    }

    // Strategic check: Does taking this over complete AI's set?
    const groupProperties = BOARD_TILES.filter(t => t.group === tile.group);
    const ownedInGroup = groupProperties.filter(t => this.game.propertyOwners[t.id] === player.id);
    const willCompleteSet = (ownedInGroup.length + 1) === groupProperties.length;

    if (willCompleteSet && player.money >= takeoverCost + 300) {
      return true;
    }

    // AI takes over if it has ample safety buffer (at least 700 coins left after purchase)
    if (player.money >= takeoverCost + 700) {
      return Math.random() < 0.7;
    }

    return false;
  }
}

window.BotController = BotController;
