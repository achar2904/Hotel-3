# Wise Inspired Design System Analysis

Design system details have been moved to: https://getdesign.md/wise/design-md

You can also view previews, dark mode examples, and download options on getdesign.md.
