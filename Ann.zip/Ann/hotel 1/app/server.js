// =============================================================================
// Hotel Case Reporting System — Express Backend Server
// The Regent Cha-am Beach Resort & VALA
// =============================================================================

require('dotenv').config();
const express = require('express');
const path = require('path');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 8080;
const HOST = '0.0.0.0';

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ทดสอบการเชื่อมต่อ MySQL เมื่อเริ่มเซิร์ฟเวอร์
db.testConnection();

// ฟังก์ชันรวม template แบบสด (Live Template Rendering)
function renderTemplates() {
  const layoutPath = path.join(__dirname, 'templates', 'layout.html');
  if (!fs.existsSync(layoutPath)) return null;

  let html = fs.readFileSync(layoutPath, 'utf8');
  const placeholderRegex = /<!--\s*\{\{([\w\-\.\/]+)\}\}\s*-->/g;

  html = html.replace(placeholderRegex, (match, relPath) => {
    const fullPath = path.join(__dirname, 'templates', relPath);
    if (fs.existsSync(fullPath)) {
      return fs.readFileSync(fullPath, 'utf8');
    }
    return `<!-- Missing: ${relPath} -->`;
  });

  try {
    fs.writeFileSync(path.join(__dirname, 'index.html'), html, 'utf8');
  } catch (e) {}

  return html;
}

// -----------------------------------------------------------------------------
// Real-time Event Stream (Server-Sent Events: SSE)
// -----------------------------------------------------------------------------
const sseClients = new Set();

function broadcastSSE(event, data) {
  const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const client of sseClients) {
    try {
      client.write(payload);
    } catch (e) {
      sseClients.delete(client);
    }
  }
}

app.get('/api/events', (req, res) => {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    'Connection': 'keep-alive',
    'X-Accel-Buffering': 'no'
  });

  res.write(`event: connected\ndata: ${JSON.stringify({ time: Date.now() })}\n\n`);
  sseClients.add(res);

  const keepAlive = setInterval(() => {
    try {
      res.write(': keep-alive\n\n');
    } catch (e) {
      clearInterval(keepAlive);
      sseClients.delete(res);
    }
  }, 20000);

  req.on('close', () => {
    clearInterval(keepAlive);
    sseClients.delete(res);
  });
});

// -----------------------------------------------------------------------------
// 1. Root & Live Template Route
// -----------------------------------------------------------------------------
app.get(['/', '/index.html'], (req, res) => {
  const renderedHtml = renderTemplates();
  if (renderedHtml) {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    return res.send(renderedHtml);
  }
  res.sendFile(path.join(__dirname, 'index.html'));
});

// -----------------------------------------------------------------------------
// 2. Health & DB Status Route
// -----------------------------------------------------------------------------
app.get('/api/db-status', (req, res) => {
  res.json({
    success: true,
    connected: db.isConnected(),
    database: process.env.DB_NAME || 'hotel_case_db',
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 3306,
    engine: 'MySQL / MariaDB'
  });
});

// -----------------------------------------------------------------------------
// 2.1 Database Viewer Routes (สำหรับดูโครงสร้างและข้อมูลตารางใน MySQL)
// -----------------------------------------------------------------------------
const ALLOWED_TABLES = [
  'users', 'departments', 'categories', 'rooms', 'cases',
  'case_timeline', 'case_attachments', 'case_counters',
  'room_logs', 'audit_logs', 'system_configs'
];

const TABLE_DESCRIPTIONS = {
  users: 'ผู้ใช้งาน, พนักงาน และสิทธิ์การเข้าถึง (Roles & Permissions)',
  departments: 'แผนกหลักในโรงแรม (IT, HK, ENG, FRONT, SECURITY)',
  categories: 'หมวดหมู่ปัญหาแยกตามแผนก',
  rooms: 'ข้อมูลห้องพัก 23 ห้อง และสถานะเปิด/ปิดขาย',
  cases: 'เคสแจ้งปัญหา/แจ้งซ่อม รายละเอียด และ SLA',
  case_timeline: 'ประวัติบันทึกการแชทและการเปลี่ยนสถานะในเคส',
  case_attachments: 'ไฟล์แนบและรูปถ่ายประกอบเคส',
  case_counters: 'ตัวนับเลขที่เคสประจำวันแบบ atomic lock',
  room_logs: 'ประวัติการสั่งเปิด-ปิดห้องพัก',
  audit_logs: 'บันทึก Audit การทำงานและความปลอดภัยในระบบ',
  system_configs: 'ค่าคอนฟิกและ SLA ของระบบ'
};

app.get('/api/database/tables', async (req, res) => {
  try {
    const rows = await db.query(`
      SELECT 
        TABLE_NAME as name,
        TABLE_ROWS as rowCount,
        ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024, 1) as sizeKb,
        CREATE_TIME as createdAt,
        UPDATE_TIME as updatedAt
      FROM information_schema.TABLES
      WHERE TABLE_SCHEMA = ?
      ORDER BY TABLE_NAME ASC
    `, [process.env.DB_NAME || 'hotel_case_db']);

    const tables = rows
      .filter(r => ALLOWED_TABLES.includes(r.name))
      .map(r => ({
        ...r,
        description: TABLE_DESCRIPTIONS[r.name] || ''
      }));

    res.json({ success: true, tables });
  } catch (err) {
    console.error('Fetch tables error:', err);
    res.status(500).json({ success: false, message: err.message });
  }
});

app.get('/api/database/table/:name', async (req, res) => {
  const tableName = req.params.name;
  if (!ALLOWED_TABLES.includes(tableName)) {
    return res.status(400).json({ success: false, message: 'ตารางที่ระบุไม่ถูกต้องหรือไม่ได้รับอนุญาต' });
  }

  try {
    const columns = await db.query(`
      SELECT 
        COLUMN_NAME as name,
        COLUMN_TYPE as type,
        IS_NULLABLE as nullable,
        COLUMN_KEY as columnKey,
        COLUMN_DEFAULT as defaultValue,
        EXTRA as extra,
        COLUMN_COMMENT as comment
      FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
      ORDER BY ORDINAL_POSITION ASC
    `, [process.env.DB_NAME || 'hotel_case_db', tableName]);

    const countRows = await db.query(`SELECT COUNT(*) as total FROM \`${tableName}\``);
    const total = countRows[0] ? countRows[0].total : 0;

    let selectFields = '*';
    if (tableName === 'users') {
      selectFields = 'id, username, email, full_name, nickname, department_id, role, phone, line_user_id, is_active, last_login_at, created_at, updated_at';
    }
    const dataRows = await db.query(`SELECT ${selectFields} FROM \`${tableName}\` ORDER BY 1 DESC LIMIT 100`);

    res.json({
      success: true,
      tableName,
      description: TABLE_DESCRIPTIONS[tableName] || '',
      columns,
      totalRows: total,
      rows: dataRows
    });
  } catch (err) {
    console.error(`Fetch table ${tableName} error:`, err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// 2.2 Database Row CRUD Routes (เพิ่ม, แก้ไข, ลบ แถวข้อมูลในตารางโดยตรง)
app.post('/api/database/table/:name/row', async (req, res) => {
  const tableName = req.params.name;
  if (!ALLOWED_TABLES.includes(tableName)) {
    return res.status(400).json({ success: false, message: 'ตารางที่ระบุไม่ถูกต้องหรือไม่ได้รับอนุญาต' });
  }

  try {
    const columns = await db.query(`
      SELECT COLUMN_NAME as name, DATA_TYPE as dataType, IS_NULLABLE as nullable, EXTRA as extra
      FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
    `, [process.env.DB_NAME || 'hotel_case_db', tableName]);

    const rowData = req.body;
    const fields = [];
    const values = [];
    const placeholders = [];

    columns.forEach(col => {
      if (col.extra && col.extra.includes('auto_increment')) return;
      if (['created_at', 'updated_at'].includes(col.name) && rowData[col.name] === undefined) return;

      if (rowData[col.name] !== undefined) {
        fields.push(`\`${col.name}\``);
        placeholders.push('?');
        let val = rowData[col.name];
        if (val === '' && col.nullable === 'YES') {
          val = null;
        }
        values.push(val);
      }
    });

    if (fields.length === 0) {
      return res.status(400).json({ success: false, message: 'ไม่มีข้อมูลคอลัมน์สำหรับเพิ่ม' });
    }

    const sql = `INSERT INTO \`${tableName}\` (${fields.join(', ')}) VALUES (${placeholders.join(', ')})`;
    const result = await db.query(sql, values);

    res.json({
      success: true,
      message: `เพิ่มข้อมูลในตาราง ${tableName} เรียบร้อยแล้ว`,
      insertId: result.insertId
    });
  } catch (err) {
    console.error(`Insert into ${tableName} error:`, err);
    res.status(500).json({ success: false, message: 'ไม่สามารถเพิ่มข้อมูลได้: ' + err.message });
  }
});

app.put('/api/database/table/:name/row/:id', async (req, res) => {
  const tableName = req.params.name;
  const rowId = req.params.id;
  if (!ALLOWED_TABLES.includes(tableName)) {
    return res.status(400).json({ success: false, message: 'ตารางที่ระบุไม่ถูกต้องหรือไม่ได้รับอนุญาต' });
  }

  try {
    const columns = await db.query(`
      SELECT COLUMN_NAME as name, DATA_TYPE as dataType, IS_NULLABLE as nullable, COLUMN_KEY as columnKey, EXTRA as extra
      FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
    `, [process.env.DB_NAME || 'hotel_case_db', tableName]);

    const pkCol = columns.find(c => c.columnKey === 'PRI')?.name || 'id';
    const rowData = req.body;
    const setClauses = [];
    const values = [];

    columns.forEach(col => {
      if (col.name === pkCol) return;
      if (col.extra && col.extra.includes('auto_increment')) return;
      if (col.name === 'updated_at') return;

      if (rowData[col.name] !== undefined) {
        setClauses.push(`\`${col.name}\` = ?`);
        let val = rowData[col.name];
        if (val === '' && col.nullable === 'YES') {
          val = null;
        }
        values.push(val);
      }
    });

    if (setClauses.length === 0) {
      return res.status(400).json({ success: false, message: 'ไม่มีฟิลด์ที่ต้องการแก้ไข' });
    }

    values.push(rowId);
    const sql = `UPDATE \`${tableName}\` SET ${setClauses.join(', ')} WHERE \`${pkCol}\` = ?`;
    await db.query(sql, values);

    res.json({
      success: true,
      message: `บันทึกการแก้ไขข้อมูลในตาราง ${tableName} เรียบร้อยแล้ว`
    });
  } catch (err) {
    console.error(`Update ${tableName} error:`, err);
    res.status(500).json({ success: false, message: 'ไม่สามารถอัปเดตข้อมูลได้: ' + err.message });
  }
});

app.delete('/api/database/table/:name/row/:id', async (req, res) => {
  const tableName = req.params.name;
  const rowId = req.params.id;
  if (!ALLOWED_TABLES.includes(tableName)) {
    return res.status(400).json({ success: false, message: 'ตารางที่ระบุไม่ถูกต้องหรือไม่ได้รับอนุญาต' });
  }

  if (tableName === 'users' && String(rowId) === '1') {
    return res.status(400).json({ success: false, message: 'ไม่อนุญาตให้ลบบัญชีผู้ดูแลระบบหลัก' });
  }

  try {
    const columns = await db.query(`
      SELECT COLUMN_NAME as name, COLUMN_KEY as columnKey
      FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
    `, [process.env.DB_NAME || 'hotel_case_db', tableName]);

    const pkCol = columns.find(c => c.columnKey === 'PRI')?.name || 'id';
    const sql = `DELETE FROM \`${tableName}\` WHERE \`${pkCol}\` = ?`;
    await db.query(sql, [rowId]);

    res.json({
      success: true,
      message: `ลบข้อมูลแถว (${pkCol}: ${rowId}) ออกจากตาราง ${tableName} เรียบร้อยแล้ว`
    });
  } catch (err) {
    console.error(`Delete from ${tableName} error:`, err);
    res.status(500).json({ success: false, message: 'ไม่สามารถลบข้อมูลได้: ' + err.message });
  }
});


// 3. Auth Routes (ระบบล็อกอินจริงด้วย MySQL)
// -----------------------------------------------------------------------------
app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ success: false, message: 'กรุณากรอกชื่อผู้ใช้และรหัสผ่าน' });
  }

  try {
    const users = await db.query(
      `SELECT u.id, u.username, u.email, u.password_hash, u.full_name, u.nickname,
              u.role, u.department_id, u.phone, u.line_user_id, u.is_active,
              d.code as department_code, d.name_th as department_name
       FROM users u
       LEFT JOIN departments d ON u.department_id = d.id
       WHERE (u.username = ? OR u.email = ?) AND u.is_active = 1`,
      [username.trim(), username.trim()]
    );

    if (users.length === 0) {
      return res.status(401).json({ success: false, message: 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง หรือบัญชีถูกระงับ' });
    }

    const user = users[0];
    // ตรวจสอบรหัสผ่าน (รองรับ plain text จาก seed หรือ bcrypt)
    if (user.password_hash !== password) {
      return res.status(401).json({ success: false, message: 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง' });
    }

    // อัปเดตเวลาล็อกอินล่าสุด
    await db.query('UPDATE users SET last_login_at = NOW() WHERE id = ?', [user.id]);

    delete user.password_hash;
    res.json({
      success: true,
      user
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ success: false, message: 'เกิดข้อผิดพลาดในการตรวจสอบสิทธิ์' });
  }
});

// -----------------------------------------------------------------------------
// 4. User Management Routes (ระบบจัดการผู้ใช้และสิทธิ์ของ Administrator)
// -----------------------------------------------------------------------------
app.get('/api/users', async (req, res) => {
  try {
    const users = await db.query(
      `SELECT u.id, u.username, u.email, u.full_name, u.nickname,
              u.role, u.department_id, u.phone, u.line_user_id, u.is_active,
              u.created_at, u.last_login_at,
              d.code as department_code, d.name_th as department_name
       FROM users u
       LEFT JOIN departments d ON u.department_id = d.id
       ORDER BY u.id ASC`
    );
    res.json({ success: true, users });
  } catch (err) {
    console.error('Fetch users error:', err);
    res.status(500).json({ success: false, message: 'ไม่สามารถดึงรายชื่อผู้ใช้ได้' });
  }
});

app.post('/api/users', async (req, res) => {
  const { username, password, full_name, nickname, email, department_id, role, phone } = req.body;
  if (!username || !password || !full_name || !email || !role) {
    return res.status(400).json({ success: false, message: 'กรุณากรอกข้อมูลที่จำเป็นให้ครบถ้วน' });
  }

  try {
    // เช็ค username หรือ email ซ้ำ
    const exist = await db.query('SELECT id FROM users WHERE username = ? OR email = ?', [username.trim(), email.trim()]);
    if (exist.length > 0) {
      return res.status(400).json({ success: false, message: 'ชื่อผู้ใช้หรืออีเมลนี้มีอยู่ในระบบแล้ว' });
    }

    const result = await db.query(
      `INSERT INTO users (username, password_hash, full_name, nickname, email, department_id, role, phone, is_active)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)`,
      [username.trim(), password, full_name.trim(), nickname || null, email.trim(), department_id || null, role, phone || null]
    );

    res.json({ success: true, message: 'สร้างผู้ใช้งานเรียบร้อยแล้ว', userId: result.insertId });
  } catch (err) {
    console.error('Create user error:', err);
    res.status(500).json({ success: false, message: 'ไม่สามารถสร้างผู้ใช้ได้: ' + err.message });
  }
});

app.put('/api/users/:id', async (req, res) => {
  const userId = parseInt(req.params.id, 10);
  const { full_name, nickname, email, department_id, role, phone, is_active, password } = req.body;

  try {
    if (password && password.trim()) {
      await db.query(
        `UPDATE users
         SET full_name = ?, nickname = ?, email = ?, department_id = ?, role = ?, phone = ?, is_active = ?, password_hash = ?
         WHERE id = ?`,
        [full_name, nickname || null, email, department_id || null, role, phone || null, is_active !== undefined ? is_active : 1, password, userId]
      );
    } else {
      await db.query(
        `UPDATE users
         SET full_name = ?, nickname = ?, email = ?, department_id = ?, role = ?, phone = ?, is_active = ?
         WHERE id = ?`,
        [full_name, nickname || null, email, department_id || null, role, phone || null, is_active !== undefined ? is_active : 1, userId]
      );
    }
    res.json({ success: true, message: 'อัปเดตข้อมูลผู้ใช้งานเรียบร้อยแล้ว' });
  } catch (err) {
    console.error('Update user error:', err);
    res.status(500).json({ success: false, message: 'ไม่สามารถอัปเดตผู้ใช้ได้: ' + err.message });
  }
});

app.delete('/api/users/:id', async (req, res) => {
  const userId = parseInt(req.params.id, 10);
  try {
    // ป้องกันการลบ Admin id 1
    if (userId === 1) {
      return res.status(400).json({ success: false, message: 'ไม่อนุญาตให้ลบบัญชีผู้ดูแลระบบหลัก' });
    }
    // ใช้ Soft delete เพื่อรักษาประวัติการแจ้งเคส
    await db.query('UPDATE users SET is_active = 0 WHERE id = ?', [userId]);
    res.json({ success: true, message: 'ระงับการใช้งานผู้ใช้งานเรียบร้อยแล้ว' });
  } catch (err) {
    console.error('Delete user error:', err);
    res.status(500).json({ success: false, message: 'ไม่สามารถลบผู้ใช้ได้' });
  }
});

// -----------------------------------------------------------------------------
// 5. Departments Route
// -----------------------------------------------------------------------------
app.get('/api/departments', async (req, res) => {
  try {
    const departments = await db.query('SELECT id, code, name_th, name_en, color_hex FROM departments WHERE is_active = 1');
    res.json({ success: true, departments });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// -----------------------------------------------------------------------------
// 6. Real MySQL Cases Routes
// -----------------------------------------------------------------------------
app.get('/api/cases', async (req, res) => {
  try {
    const cases = await db.query(
      `SELECT c.id, c.case_uid as caseUid, c.case_no as caseNo, c.subject, c.description,
              c.location_type as location, c.room_no as room, c.priority, c.status,
              c.reporter_name as reporter, c.assignee_name as assignee,
              c.sla_minutes as sla, c.due_at as due, c.affects_room_salability as affects,
              c.created_at as createdAt, c.reminders_count as reminders, c.escalated_at as escalatedAt,
              d.code as dept,
              cat.category_code as category
       FROM cases c
       LEFT JOIN departments d ON c.department_id = d.id
       LEFT JOIN categories cat ON c.category_id = cat.id
       WHERE c.is_deleted = 0
       ORDER BY c.id DESC`
    );
    res.json({ success: true, cases });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

app.post('/api/cases', async (req, res) => {
  const { subject, description, location, room, dept, category, priority, reporter_name, reporter_id, affects } = req.body;
  if (!subject || !description || !dept) {
    return res.status(400).json({ success: false, message: 'กรุณากรอกข้อมูลเคสให้ครบถ้วน' });
  }

  try {
    const caseNo = await db.getNextCaseNumber();
    const caseUid = crypto.randomUUID();

    // หา department_id
    const deptRows = await db.query('SELECT id FROM departments WHERE code = ?', [dept]);
    const deptId = deptRows.length ? deptRows[0].id : 1;

    // หา category_id
    let categoryId = null;
    if (category) {
      const catRows = await db.query('SELECT id FROM categories WHERE category_code = ?', [category]);
      if (catRows.length) categoryId = catRows[0].id;
    }

    // คำนวณ SLA
    const slaMin = priority === 'EMERGENCY' ? 20 : (priority === 'URGENT' ? 40 : 60);
    const dueAt = new Date(Date.now() + slaMin * 60000);

    // หา room_id
    let roomId = null;
    if (room) {
      const roomRows = await db.query('SELECT id FROM rooms WHERE room_no = ?', [room]);
      if (roomRows.length) roomId = roomRows[0].id;
    }

    const insertResult = await db.query(
      `INSERT INTO cases (case_uid, case_no, subject, description, location_type, room_id, room_no,
                          department_id, category_id, priority, status, reporter_id, reporter_name,
                          sla_minutes, due_at, affects_room_salability)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'NEW', ?, ?, ?, ?, ?)`,
      [caseUid, caseNo, subject, description, location || 'Guest Room', roomId, room || null,
       deptId, categoryId, priority || 'NORMAL', reporter_id || 1, reporter_name || 'Staff',
       slaMin, dueAt, affects ? 1 : 0]
    );

    const caseId = insertResult.insertId;

    // บันทึกข้อความแรกใน Timeline
    await db.query(
      `INSERT INTO case_timeline (case_id, sender_name, entry_type, message, created_at)
       VALUES (?, ?, 'USER', ?, NOW())`,
      [caseId, reporter_name || 'Staff', description]
    );

    // บันทึก Audit Log
    await db.query(
      `INSERT INTO audit_logs (case_id, event, actor_name, meta_data, created_at)
       VALUES (?, 'CASE_CREATED', ?, ?, NOW())`,
      [caseId, reporter_name || 'Staff', JSON.stringify({ caseNo, priority: priority || 'NORMAL', dept, room })]
    );

    // ถ้ามีผลต่อการขายห้อง ปิดห้องทันที
    if (affects && roomId) {
      await db.query("UPDATE rooms SET status = 'CLOSED', closed_reason = ? WHERE id = ?", ['เคส ' + caseNo + ': ' + subject, roomId]);
      await db.query("INSERT INTO room_logs (room_id, room_no, action, reason, actor_name, case_id, created_at) VALUES (?, ?, 'CLOSE_ROOM', ?, ?, ?, NOW())",
        [roomId, room, 'ปิดห้องอัตโนมัติจากเคส ' + caseNo, reporter_name || 'Staff', caseId]);
      broadcastSSE('room_status_changed', { roomNo: room, status: 'CLOSED', reason: 'เคส ' + caseNo + ': ' + subject, actor_name: reporter_name || 'Staff' });
    }

    // กระจายสัญญาณ Real-time SSE ไปยังทุกเครื่องที่เปิดเว็บอยู่
    broadcastSSE('case_created', { caseNo, caseUid, subject, priority: priority || 'NORMAL', dept, room, reporter_name });

    res.json({ success: true, caseNo, caseUid });
  } catch (err) {
    console.error('Create case error:', err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// อัปเดตสถานะเคส (Acknowledge, Assign, Transfer, Resolve, Close, Reopen, Cancel)
app.patch('/api/cases/:caseUid/status', async (req, res) => {
  const { caseUid } = req.params;
  const { status, actor_name, note, reason, assignee, dept } = req.body;

  try {
    const caseRows = await db.query('SELECT * FROM cases WHERE case_uid = ?', [caseUid]);
    if (caseRows.length === 0) return res.status(404).json({ success: false, message: 'ไม่พบเคส' });
    const c = caseRows[0];

    const updateFields = ['status = ?'];
    const updateVals = [status];

    if (assignee !== undefined) {
      updateFields.push('assignee_name = ?');
      updateVals.push(assignee);
    }
    if (dept !== undefined) {
      const deptRows = await db.query('SELECT id FROM departments WHERE code = ?', [dept]);
      if (deptRows.length) {
        updateFields.push('department_id = ?');
        updateVals.push(deptRows[0].id);
      }
    }
    if (status === 'ACKNOWLEDGED' && !c.acknowledged_at) {
      updateFields.push('acknowledged_at = NOW()');
    }
    if (status === 'RESOLVED') {
      updateFields.push('resolved_at = NOW()');
    }
    if (status === 'CLOSED') {
      updateFields.push('closed_at = NOW()');
    }
    if (status === 'REOPENED') {
      updateFields.push('closed_at = NULL', 'resolved_at = NULL');
    }

    updateVals.push(c.id);
    await db.query(`UPDATE cases SET ${updateFields.join(', ')} WHERE id = ?`, updateVals);

    // บันทึก Timeline ของระบบ
    let sysMsg = `เปลี่ยนสถานะเป็น ${status}`;
    if (note) sysMsg += ` — ${note}`;
    if (reason) sysMsg += ` — เหตุผล: ${reason}`;
    if (assignee) sysMsg += ` (ผู้รับผิดชอบ: ${assignee})`;

    await db.query(
      `INSERT INTO case_timeline (case_id, sender_name, entry_type, message, created_at)
       VALUES (?, ?, 'SYSTEM', ?, NOW())`,
      [c.id, actor_name || 'System', sysMsg]
    );

    // บันทึก Audit Log
    await db.query(
      `INSERT INTO audit_logs (case_id, event, actor_name, meta_data, created_at)
       VALUES (?, 'STATUS_CHANGED', ?, ?, NOW())`,
      [c.id, actor_name || 'Staff', JSON.stringify({ from: c.status, to: status, note, reason, assignee })]
    );

    // กระจายสัญญาณ Real-time SSE
    broadcastSSE('case_status_changed', {
      caseUid,
      status,
      assignee: assignee || c.assignee_name,
      dept,
      actor_name: actor_name || 'Staff',
      note,
      reason
    });

    res.json({ success: true, message: 'อัปเดตสถานะเคสเรียบร้อยแล้ว' });
  } catch (err) {
    console.error('Update case status error:', err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// ดึง Timeline ของเคส
app.get('/api/cases/:caseUid/timeline', async (req, res) => {
  try {
    const caseRows = await db.query('SELECT id FROM cases WHERE case_uid = ?', [req.params.caseUid]);
    if (!caseRows.length) return res.status(404).json({ success: false, message: 'ไม่พบเคส' });
    const caseId = caseRows[0].id;

    const timeline = await db.query(
      `SELECT id, sender_name as sender, sender_dept as dept, entry_type as type,
              message as text, attachment_name as attachmentName, attachment_url as dataUrl,
              created_at as createdAt
       FROM case_timeline
       WHERE case_id = ?
       ORDER BY id ASC`,
      [caseId]
    );
    res.json({ success: true, timeline });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ส่งข้อความ/ตอบกลับในเคส
app.post('/api/cases/:caseUid/timeline', async (req, res) => {
  const { sender_name, text, attachment } = req.body;
  try {
    const caseRows = await db.query('SELECT id FROM cases WHERE case_uid = ?', [req.params.caseUid]);
    if (!caseRows.length) return res.status(404).json({ success: false, message: 'ไม่พบเคส' });
    const caseId = caseRows[0].id;

    await db.query(
      `INSERT INTO case_timeline (case_id, sender_name, entry_type, message, attachment_name, attachment_url, created_at)
       VALUES (?, ?, 'USER', ?, ?, ?, NOW())`,
      [caseId, sender_name || 'Staff', text || '(ไฟล์แนบ)', attachment ? attachment.name : null, attachment ? (attachment.dataUrl || null) : null]
    );

    // กระจายสัญญาณ Real-time SSE
    broadcastSSE('new_comment', {
      caseUid: req.params.caseUid,
      sender_name: sender_name || 'Staff',
      text: text || '(ไฟล์แนบ)',
      attachment: attachment ? attachment.name : null,
      createdAt: new Date().toISOString()
    });

    res.json({ success: true, message: 'ส่งข้อความเรียบร้อย' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// -----------------------------------------------------------------------------
// 7. Rooms Routes
// -----------------------------------------------------------------------------
app.get('/api/rooms', async (req, res) => {
  try {
    const rooms = await db.query(`
      SELECT r.id, r.room_no as roomNo, r.building, r.floor, r.room_type as roomType,
             r.status, r.closed_reason as reason
      FROM rooms r
      ORDER BY r.room_no ASC
    `);

    // ตรวจสอบเคสที่ค้างของแต่ละห้อง
    const openCasesRows = await db.query(`
      SELECT room_no, case_uid
      FROM cases
      WHERE room_no IS NOT NULL AND status NOT IN ('CLOSED', 'CANCELLED', 'RESOLVED') AND is_deleted = 0
    `);

    const roomCasesMap = {};
    openCasesRows.forEach(row => {
      if (!roomCasesMap[row.room_no]) roomCasesMap[row.room_no] = [];
      roomCasesMap[row.room_no].push(row.case_uid);
    });

    const enrichedRooms = rooms.map(r => ({
      ...r,
      openCases: roomCasesMap[r.roomNo] || []
    }));

    res.json({ success: true, rooms: enrichedRooms });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// เปลี่ยนสถานะห้องพัก (AVAILABLE / CLOSED)
app.patch('/api/rooms/:roomNo/status', async (req, res) => {
  const { roomNo } = req.params;
  const { status, reason, actor_name } = req.body;
  if (!['AVAILABLE', 'CLOSED'].includes(status)) {
    return res.status(400).json({ success: false, message: 'สถานะห้องไม่ถูกต้อง' });
  }

  try {
    const roomRows = await db.query('SELECT id, room_no, status FROM rooms WHERE room_no = ?', [roomNo]);
    if (!roomRows.length) return res.status(404).json({ success: false, message: 'ไม่พบห้องพัก' });
    const room = roomRows[0];

    await db.query(
      'UPDATE rooms SET status = ?, closed_reason = ? WHERE id = ?',
      [status, status === 'CLOSED' ? (reason || 'ปิดห้อง') : null, room.id]
    );

    const action = status === 'CLOSED' ? 'CLOSE_ROOM' : 'OPEN_ROOM';
    await db.query(
      'INSERT INTO room_logs (room_id, room_no, action, reason, actor_name, created_at) VALUES (?, ?, ?, ?, ?, NOW())',
      [room.id, roomNo, action, reason || (status === 'AVAILABLE' ? 'เปิดขายห้อง' : 'ปิดห้อง'), actor_name || 'Staff']
    );

    await db.query(
      'INSERT INTO audit_logs (event, actor_name, meta_data, created_at) VALUES (?, ?, ?, NOW())',
      ['ROOM_STATUS_CHANGED', actor_name || 'Staff', JSON.stringify({ roomNo, from: room.status, to: status, reason })]
    );

    // กระจายสัญญาณ Real-time SSE
    broadcastSSE('room_status_changed', {
      roomNo,
      status,
      reason: reason || '',
      actor_name: actor_name || 'Staff'
    });

    res.json({ success: true, message: `อัปเดตสถานะห้อง ${roomNo} เป็น ${status} เรียบร้อยแล้ว` });
  } catch (err) {
    console.error('Update room status error:', err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// -----------------------------------------------------------------------------
// 8. Audit Logs Route
// -----------------------------------------------------------------------------
app.get('/api/audit', async (req, res) => {
  try {
    const logs = await db.query(
      `SELECT a.id, a.event, a.actor_name as actor, a.meta_data as meta,
              a.created_at as at, c.case_uid as caseUid, c.case_no as caseNo
       FROM audit_logs a
       LEFT JOIN cases c ON a.case_id = c.id
       ORDER BY a.id DESC LIMIT 200`
    );
    res.json({ success: true, logs });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Static Files Serving
app.use(express.static(__dirname));

// Start Server
app.listen(PORT, HOST, () => {
  const ipv4 = os.networkInterfaces();
  let localIp = '127.0.0.1';

  Object.keys(ipv4).forEach(iface => {
    ipv4[iface].forEach(addr => {
      if (addr.family === 'IPv4' && !addr.internal) {
        localIp = addr.address;
      }
    });
  });

  console.log('🚀 Hotel Case Reporting System — Express & MySQL Backend');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(`📍 Local:     http://localhost:${PORT}`);
  console.log(`🌐 Network:   http://${localIp}:${PORT}`);
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
});
