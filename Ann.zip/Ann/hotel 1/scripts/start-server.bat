@echo off
title Hotel Case Web Server
echo Starting Hotel Case Web Server...
cd /d "%~dp0..\app"
node server.js
pause
