@echo off
title Hotel Operations Demo
cd /d "%~dp0"
start "" "index.html"
